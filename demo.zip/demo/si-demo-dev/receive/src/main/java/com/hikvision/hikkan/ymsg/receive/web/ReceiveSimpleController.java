package com.hikvision.hikkan.ymsg.receive.web;

import com.hikvision.hikkan.ymsg.receive.bean.ObjectResult;
import com.hikvision.hikkan.ymsg.receive.util.AesUtil;
import com.hikvision.hikkan.ymsg.receive.util.LRUCache;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.util.Collection;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * @author heqian7
 */
@Slf4j
@RestController
@RequestMapping("/receive/simple")
public class ReceiveSimpleController {

    private LRUCache cache = new LRUCache(5);

    @PostMapping(value = "/alarm", produces = "application/json; charset=utf-8")
    public Mono<Object> alarm(@RequestParam String data) {
        return Mono.create(s -> {
            try {
                log.info("alarm aes: " + data + "\n");
                cache.put(data);
            } catch (Exception e) {
                e.printStackTrace();
            }
            s.success(ObjectResult.SUCCESS);
        }).subscribeOn(Schedulers.elastic());
    }

    @PostMapping(value = "/onoff", produces = "application/json; charset=utf-8")
    public Mono<Object> onoff(@RequestParam String data) {
        return Mono.create(s -> {
            try {
                log.info("onoff aes: " + data + "\n");
                cache.put(data);
            } catch (Exception e) {
                e.printStackTrace();
            }
            s.success(ObjectResult.SUCCESS);
        }).subscribeOn(Schedulers.elastic());
    }

    @PostMapping(value = "/event", produces = "application/json; charset=utf-8")
    public Mono<Object> event(@RequestParam String data) {
        return Mono.create(s -> {
            try {
                log.info("event aes: " + data + "\n");
                cache.put(data);
            } catch (Exception e) {
                e.printStackTrace();
            }
            s.success(ObjectResult.SUCCESS);
        }).subscribeOn(Schedulers.elastic());
    }

    @PostMapping(value = "/change", produces = "application/json; charset=utf-8")
    public Mono<Object> change(@RequestParam String data) {
        return Mono.create(s -> {
            try {
                log.info("change aes: " + data + "\n");
                cache.put(data);
            } catch (Exception e) {
                e.printStackTrace();
            }
            s.success(ObjectResult.SUCCESS);
        }).subscribeOn(Schedulers.elastic());
    }

    @PostMapping(value = "/ferry", produces = "application/json; charset=utf-8")
    public Mono<Object> ferry(@RequestParam String data) {
        return Mono.create(s -> {
            try {
                log.info("ferry aes: " + data + "\n");
                cache.put(data);
            } catch (Exception e) {
                e.printStackTrace();
            }
            s.success(ObjectResult.SUCCESS);
        }).subscribeOn(Schedulers.elastic());
    }

    @PostMapping(value = "/show", produces = "application/json; charset=utf-8")
    public Mono<Object> show() {
        return Mono.create(s -> {
            Collection values = cache.getCache().values();
            s.success(ObjectResult.success(values));
        }).subscribeOn(Schedulers.elastic());
    }
}
