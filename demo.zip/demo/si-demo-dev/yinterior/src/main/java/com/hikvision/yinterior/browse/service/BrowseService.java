package com.hikvision.yinterior.browse.service;

import com.hikvision.hikkan.kcommon.bean.ObjectResult;

public interface BrowseService {

    ObjectResult getBrowseCounts();

    ObjectResult getAvgBrowseCounts();

}
