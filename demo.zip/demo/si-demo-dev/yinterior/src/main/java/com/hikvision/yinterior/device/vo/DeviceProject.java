package com.hikvision.yinterior.device.vo;

import lombok.Data;

@Data
public class DeviceProject {

    //項目名
    private String key;

    //按項目下的設備總數
    private Integer value;



}
