package com.hikvision.yinterior.access.vo;


import lombok.Data;

@Data
public class AccessInfoVO {

    private Integer counts;

    private Integer increaseCounts;


    private String increaseRate;

    /**
     *  0 代表 正数  1 代表 负数
     */
    private Integer tag;


}
