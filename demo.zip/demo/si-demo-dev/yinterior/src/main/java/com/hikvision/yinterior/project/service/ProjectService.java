package com.hikvision.yinterior.project.service;

import com.hikvision.hikkan.kcommon.bean.ObjectResult;

public interface ProjectService {

    ObjectResult getProjectCounts();




}
