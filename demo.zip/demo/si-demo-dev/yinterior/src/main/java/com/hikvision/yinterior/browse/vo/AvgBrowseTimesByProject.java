package com.hikvision.yinterior.browse.vo;

import lombok.Data;

@Data
public class AvgBrowseTimesByProject {

    private Integer accessCounts;

    private String projectName;

    //总预览次数
    private Integer browseTimes;

    //平均预览次数
    private String avgBrowseTimes;
}
