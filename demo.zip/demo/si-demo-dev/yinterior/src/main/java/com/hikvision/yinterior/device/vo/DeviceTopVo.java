package com.hikvision.yinterior.device.vo;

import com.hikvision.yinterior.access.vo.AccessProject;
import com.hikvision.yinterior.device.dto.DeviceProjectMonthDTO;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;
@Data
public class DeviceTopVo {

    List<DeviceProjectMonthDTO> all = new ArrayList<>();


    List<DeviceProjectMonthDTO> increase = new ArrayList<>();


}
