package com.hikvision.yinterior.device.dto;

import lombok.Data;


@Data
public class DeviceProjectMonthInfoDTO {

    private String projectName;

    private Integer counts;

    private String appKey;

    public DeviceProjectMonthInfoDTO getInstance(){
        return this;
    }

}
