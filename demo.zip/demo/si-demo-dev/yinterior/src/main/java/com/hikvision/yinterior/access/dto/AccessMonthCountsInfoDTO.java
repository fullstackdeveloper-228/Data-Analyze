package com.hikvision.yinterior.access.dto;

import lombok.Data;

import java.util.Date;
@Data
public class AccessMonthCountsInfoDTO {

    //日期
    private Date createDate;

    //通道數
    private Integer accessNums;

}
