package com.hikvision.yinterior.device.service.impl;

import com.hikvision.hikkan.kcommon.bean.ObjectResult;
import com.hikvision.yinterior.access.vo.AccessInfoVO;
import com.hikvision.yinterior.access.vo.AccessProject;
import com.hikvision.yinterior.access.vo.AccessTopVo;
import com.hikvision.yinterior.device.dto.ActiveDeviceAccessDTO;
import com.hikvision.yinterior.device.dto.DeviceMonthCountsInfoDTO;
import com.hikvision.yinterior.device.dto.DeviceProjectMonthDTO;
import com.hikvision.yinterior.device.dto.DeviceProjectMonthInfoDTO;
import com.hikvision.yinterior.device.repository.DeviceMapper;
import com.hikvision.yinterior.device.service.DeviceService;
import com.hikvision.yinterior.device.vo.ActiveRate;
import com.hikvision.yinterior.device.vo.DeviceMonthInfo;
import com.hikvision.yinterior.device.vo.DeviceProject;
import com.hikvision.yinterior.device.vo.DeviceTopVo;
import com.hikvision.yinterior.util.TimeUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class DeviceServiceImpl implements DeviceService {


    @Autowired
    DeviceMapper deviceMapper;

    @Override
    public ObjectResult getDeviceCounts() {

        //获取本月月初
        Date beginMonth = TimeUtil.getDate(0, 1);

        //获取本月月末
        Date endMonth = TimeUtil.getDate(1, 0);

        //獲取本月的設備
        Integer counts = deviceMapper.getDeviceMonthCountsInfo(beginMonth,endMonth);

        //獲取上月的通道總數
        //获取上月月初
        beginMonth = TimeUtil.getDate(-1, 1);

        //获取本月月初
        endMonth = TimeUtil.getDate(0, 1);

        //獲取上月的通道數
        Integer countsLast = deviceMapper.getDeviceMonthCountsInfo(beginMonth,endMonth);


        //計算本月比上月增加的通道數
        Integer increaseCounts = counts - countsLast;

        //計算增長率
        Double increaseRate = increaseCounts / (counts - increaseCounts * 1.0) * 100;
        String increase = String.format("%.2f", Math.abs(increaseRate));
        //封裝
        DeviceMonthInfo deviceInfoVO = new DeviceMonthInfo();
        deviceInfoVO.setCounts(counts);

        if(increaseCounts < 0){
            deviceInfoVO.setTag(0);
        }else {
            deviceInfoVO.setTag(1);
        }

        deviceInfoVO.setIncreaseCounts(Math.abs(increaseCounts));
        deviceInfoVO.setIncreaseRate(increase);

        return ObjectResult.success(deviceInfoVO);
    }


    @Override
    public ObjectResult getActiveDeviceAccess() {

        //获取本月月初
        Date beginMonth = TimeUtil.getDate(0, 1);

        //获取本月月末
        Date endMonth = TimeUtil.getDate(1, 0);

        List<ActiveDeviceAccessDTO> activeDeviceAccessDTOS = deviceMapper.getActiveDeviceAccess(beginMonth,endMonth);

        List<ActiveRate> activeDeviceAccesses = new ArrayList<>();

        for (ActiveDeviceAccessDTO activeDeviceAccessDTO1 : activeDeviceAccessDTOS) {

            ActiveRate activeRate = new ActiveRate();

            Double accessNums = activeDeviceAccessDTO1.getAccessNums() * 1.0;

            Integer activeAccess = activeDeviceAccessDTO1.getActiveAccess();


            Double accessRate = accessNums == 0d ? 0d : activeAccess / accessNums * 100;


            if (accessRate <= 0d || accessRate > 100d) {
                continue;
            }

            activeRate.setAccessActiveRate(Double.parseDouble(String.format("%.2f",accessRate)));

            Double deviceNums = activeDeviceAccessDTO1.getDeviceNums() * 1.0;

            Integer activeDevice = activeDeviceAccessDTO1.getActiveDevice();

            Double deviceRate = deviceNums == 0d ? 0d : activeDevice / deviceNums * 100;


            if (deviceRate <= 0d || deviceRate > 100d) {
                continue;
            }


            activeRate.setDeviceActiveRate(Double.parseDouble(String.format("%.2f",deviceRate)));

            activeRate.setProjectName(activeDeviceAccessDTO1.getProjectName());

            activeDeviceAccesses.add(activeRate);

        }

        return ObjectResult.success(activeDeviceAccesses);
    }

    @Override
    public ObjectResult getDeviceMonthSort() {

        //获取上月月初
        Date beginMonth = TimeUtil.getDate(-1, 1);

        //获取本月月初
        Date endMonth = TimeUtil.getDate(0, 1);

        // 获取上月的通道数
        List<DeviceProjectMonthDTO> accessMonthIncreaseInfosLastMonth = deviceMapper.getDeviceMonthIncreaseInfo(beginMonth, endMonth);

        //获取本月月初
        Date beginMonthNow = TimeUtil.getDate(0, 1);

        //获取本月月末
        Date endMonthNow = TimeUtil.getDate(1, 0);

        // 获取本月的通道数
        List<DeviceProjectMonthDTO> accessMonthIncreaseInfosThisMonth = deviceMapper.getDeviceMonthIncreaseInfo(beginMonthNow, endMonthNow);

        //本月新增top
        List<DeviceProjectMonthDTO> accessMonthIncreaseInfosThisMonthIncrease = new ArrayList<>();

        //上月信息转为mapping
        Map<String, Integer> lastMapping = accessMonthIncreaseInfosLastMonth.stream().collect(Collectors.toMap(DeviceProjectMonthDTO::getKey, DeviceProjectMonthDTO::getValue));

        Iterator<DeviceProjectMonthDTO> iterator = accessMonthIncreaseInfosThisMonth.iterator();

        while (iterator.hasNext()) {

            DeviceProjectMonthDTO accessProject = iterator.next();

            String name = accessProject.getKey();

            if (lastMapping.containsKey(name)) {

                Integer countLast = lastMapping.get(name);

                Integer increase = accessProject.getValue() - countLast;

                if (increase > 0) {

                    DeviceProjectMonthDTO accessProject1 = new DeviceProjectMonthDTO();
                    accessProject1.setValue(increase);
                    accessProject1.setKey(accessProject.getKey());
                    accessProject1.setName(accessProject.getName());
                    accessMonthIncreaseInfosThisMonthIncrease.add(accessProject1);
                }

                if(accessProject.getValue() == 0){
                    iterator.remove();
                }

            }

        }


        accessMonthIncreaseInfosThisMonth.sort(new Comparator<DeviceProjectMonthDTO>() {

            @Override
            public int compare(DeviceProjectMonthDTO o1, DeviceProjectMonthDTO o2) {
                return o1.getValue() - o2.getValue() >= 0 ? -1 : 1;
            }
        });

        accessMonthIncreaseInfosThisMonthIncrease.sort(new Comparator<DeviceProjectMonthDTO>() {

            @Override
            public int compare(DeviceProjectMonthDTO o1, DeviceProjectMonthDTO o2) {
                return o1.getValue() - o2.getValue() >= 0 ? -1 : 1;
            }
        });

        accessMonthIncreaseInfosThisMonth = accessMonthIncreaseInfosThisMonth.subList(0, 10);
        accessMonthIncreaseInfosThisMonthIncrease = accessMonthIncreaseInfosThisMonthIncrease.subList(0, 10);

        DeviceTopVo deviceTopVo = new DeviceTopVo();
        deviceTopVo.setAll(accessMonthIncreaseInfosThisMonth);
        deviceTopVo.setIncrease(accessMonthIncreaseInfosThisMonthIncrease);

        return ObjectResult.success(deviceTopVo);
    }


}
