package com.hikvision.yinterior.access.controller;

import com.hikvision.yinterior.access.service.AccessService;

import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

@RestController
@RequestMapping("/access")
public class AccessController {

    @Autowired
    AccessService accessService;

    @PostMapping(value = "/allcounts", produces = "application/json; charset=utf-8")
    @ApiOperation(value = "统计通道数量", httpMethod = "POST", notes = "统计通道数量")
    public Mono<Object> statisticsDeviceCounts(){

        return Mono.create(s -> s.success(accessService.getAccessCounts())
        ).subscribeOn(Schedulers.elastic());

    }



    @PostMapping(value = "/top/increase", produces = "application/json; charset=utf-8")
    @ApiOperation(value = "统计top10的通道新增數", httpMethod = "POST", notes = "统计top10的设备新增數")
    public Mono<Object> statisticsTopDeviceIncrease() {

        return Mono.create(s -> s.success(accessService.getAccessMonthSort())
        ).subscribeOn(Schedulers.elastic());

    }





}
