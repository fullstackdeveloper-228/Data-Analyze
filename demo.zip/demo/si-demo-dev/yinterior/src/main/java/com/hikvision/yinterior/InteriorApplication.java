package com.hikvision.yinterior;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;



@EnableDiscoveryClient
@SpringBootApplication(scanBasePackages = "com.hikvision.yinterior")
@MapperScan(basePackages = {"com.hikvision.yinterior.access.repository","com.hikvision.yinterior.browse.repository","com.hikvision.yinterior.device.repository","com.hikvision.yinterior.export.repository","com.hikvision.yinterior.project.repository"})
public class InteriorApplication {

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(InteriorApplication.class);
        app.setWebApplicationType(WebApplicationType.SERVLET);
        app.run();
    }

}