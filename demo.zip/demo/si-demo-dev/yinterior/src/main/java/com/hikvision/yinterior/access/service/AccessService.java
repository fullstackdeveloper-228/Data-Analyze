package com.hikvision.yinterior.access.service;

import com.hikvision.hikkan.kcommon.bean.ObjectResult;
import org.springframework.stereotype.Service;


public interface AccessService {

    ObjectResult getAccessCounts();

    ObjectResult getAccessMonthSort();



}
