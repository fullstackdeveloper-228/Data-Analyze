package com.hikvision.yinterior.access.dto;

import lombok.Data;

@Data
public class AccessProjectMonthInfoDTO {

    private String projectName;

    private Integer counts;

    private String appKey;

    public AccessProjectMonthInfoDTO getInstance() {
        return this;
    }


}
