package com.hikvision.yinterior.access.service.impl;

import com.hikvision.hikkan.kcommon.bean.ObjectResult;
import com.hikvision.yinterior.access.vo.AccessTopVo;
import com.hikvision.yinterior.util.TimeUtil;
import com.hikvision.yinterior.access.dto.AccessMonthCountsInfoDTO;
import com.hikvision.yinterior.access.repository.AccessMapper;
import com.hikvision.yinterior.access.service.AccessService;
import com.hikvision.yinterior.access.vo.AccessInfoVO;
import com.hikvision.yinterior.access.vo.AccessProject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class AccessServiceImpl implements AccessService {


    @Autowired
    AccessMapper accessMapper;


    @Override
    public ObjectResult getAccessCounts() {

        //获取本月月初
        Date beginMonth = TimeUtil.getDate(0, 1);

        //获取本月月末
        Date endMonth = TimeUtil.getDate(1, 0);

        //獲取本月的通道數
        Integer counts = accessMapper.getAccessMonthCountsInfo(beginMonth, endMonth);

        //獲取上月的通道總數
        //获取上月月初
        beginMonth = TimeUtil.getDate(-1, 1);

        //获取本月月初
        endMonth = TimeUtil.getDate(0, 1);

        //獲取上月的通道數
        Integer countsLast = accessMapper.getAccessMonthCountsInfo(beginMonth, endMonth);

        //計算本月比上月增加的通道數
        Integer increaseCounts = counts - countsLast;

        //計算增長率
        Double increaseRate = increaseCounts / (counts - increaseCounts * 1.0) * 100;
        String increase = String.format("%.2f", Math.abs(increaseRate));


        //封裝
        AccessInfoVO accessInfoVO = new AccessInfoVO();
        accessInfoVO.setCounts(counts);

        if(increaseCounts < 0){
            accessInfoVO.setTag(0);
        }else {
            accessInfoVO.setTag(1);
        }

        accessInfoVO.setIncreaseCounts(Math.abs(increaseCounts));
        accessInfoVO.setIncreaseRate(increase);



        return ObjectResult.success(accessInfoVO);
    }


    @Override
    public ObjectResult getAccessMonthSort() {
        //获取上月月初
        Date beginMonth = TimeUtil.getDate(-1, 1);

        //获取本月月初
        Date endMonth = TimeUtil.getDate(0, 1);

        // 获取上月的通道数
        List<AccessProject> accessMonthIncreaseInfosLastMonth = accessMapper.getAccessMonthIncreaseInfo(beginMonth, endMonth);

        //获取本月月初
        Date beginMonthNow = TimeUtil.getDate(0, 1);

        //获取本月月末
        Date endMonthNow = TimeUtil.getDate(1, 0);

        // 获取本月的通道数
        List<AccessProject> accessMonthIncreaseInfosThisMonth = accessMapper.getAccessMonthIncreaseInfo(beginMonthNow, endMonthNow);

        //本月新增top
        List<AccessProject> accessMonthIncreaseInfosThisMonthIncrease = new ArrayList<>();

        //上月信息转为mapping
        Map<String, Integer> lastMapping = accessMonthIncreaseInfosLastMonth.stream().collect(Collectors.toMap(AccessProject::getKey, AccessProject::getValue));

        //总数
        Integer allcounts = 0;

        Integer increaseCounts = 0;

        Iterator<AccessProject> iterator = accessMonthIncreaseInfosThisMonth.iterator();

        while (iterator.hasNext()) {

            AccessProject accessProject = iterator.next();

            String name = accessProject.getKey();

            allcounts += accessProject.getValue();

            if (lastMapping.containsKey(name)) {

                Integer countLast = lastMapping.get(name);

                Integer increase = accessProject.getValue() - countLast;

                if (increase > 0) {
                    AccessProject accessProject1 = new AccessProject();
                    accessProject1.setValue(increase);
                    accessProject1.setKey(accessProject.getKey());
                    accessProject1.setName(accessProject.getName());
                    increaseCounts += increase;
                    accessMonthIncreaseInfosThisMonthIncrease.add(accessProject1);
                }

                if(accessProject.getValue() == 0){
                    iterator.remove();
                }

            }

        }


        accessMonthIncreaseInfosThisMonth.sort(new Comparator<AccessProject>() {

            @Override
            public int compare(AccessProject o1, AccessProject o2) {
                return o1.getValue() - o2.getValue() >= 0 ? -1 : 1;
            }
        });

        accessMonthIncreaseInfosThisMonthIncrease.sort(new Comparator<AccessProject>() {

            @Override
            public int compare(AccessProject o1, AccessProject o2) {
                return o1.getValue() - o2.getValue() >= 0 ? -1 : 1;
            }
        });

        accessMonthIncreaseInfosThisMonth = accessMonthIncreaseInfosThisMonth.subList(0, 10);
        accessMonthIncreaseInfosThisMonthIncrease = accessMonthIncreaseInfosThisMonthIncrease.subList(0, 10);

        for(AccessProject accessProject : accessMonthIncreaseInfosThisMonth){
            Integer value = accessProject.getValue();
            Double rate = value / (allcounts * 1.0) * 100;
            accessProject.setRate(String.format("%.2f", rate));
        }

        for(AccessProject accessProject : accessMonthIncreaseInfosThisMonthIncrease){
            Integer value = accessProject.getValue();
            Double rate = value / (increaseCounts * 1.0) * 100;
            accessProject.setRate(String.format("%.2f", rate));
        }


        AccessTopVo accessTopVo = new AccessTopVo();
        accessTopVo.setAll(accessMonthIncreaseInfosThisMonth);
        accessTopVo.setIncrease(accessMonthIncreaseInfosThisMonthIncrease);

        return ObjectResult.success(accessTopVo);

    }


}
