package com.hikvision.yinterior.export.repository;

import com.hikvision.yinterior.export.dto.ProjectDTO;
import com.hikvision.yinterior.export.dto.ProjectItemDTO;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

@Mapper
public interface ExcelMapper {


    @Insert({
            "<script>",
            "insert into project_info(app_key, project_name, create_date,principal_name,device_nums,access_nums,browse_times,active_devices,active_access) values ",
            "<foreach collection='projectList' item='item' index='index' separator=','>",
            "(#{item.appKey}, #{item.projectName}, #{item.date}, #{item.principal},#{item.devices},#{item.access},#{item.browseTimes},#{item.activeDevices},#{item.activeAccess} )",
            "</foreach>",
            "</script>"
    })
    void insertAllProject(@Param(value = "projectList") List<ProjectItemDTO> list);


    @Select("SELECT app_key as appKey,browse_times as browseTimes, active_access as activeAccess FROM project_info where create_date between #{startDate} and #{endDate};")
    List<ProjectDTO> get(@Param("startDate") Date start, @Param("endDate") Date end);

    @Update({"<script>" +
            "<foreach collection= 'smsConfigTemplateList' item='item' separator=';'>" +
            " UPDATE" +
            " project_info" +
            " SET browse_times = #{item.browseTimes}, " +
            " active_access = #{item.activeAccess} " +
            " WHERE " +
            " app_key = #{item.appKey} " +
            "</foreach>" +
            "</script>"})
    void update(@Param("smsConfigTemplateList") List<ProjectDTO> smsConfigTemplateList);




}