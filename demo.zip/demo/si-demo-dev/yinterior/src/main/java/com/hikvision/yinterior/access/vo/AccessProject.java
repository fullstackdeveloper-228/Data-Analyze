package com.hikvision.yinterior.access.vo;


import lombok.Data;

@Data
public class AccessProject {

    /**
     * 項目編碼
     */
    private String key;

    /**
     * 项目名
     */
    private String name;

    /**
     * 項目通道總數
     */
    private Integer value;

    /**
     * 通道占比
     */
    private String rate;



}
