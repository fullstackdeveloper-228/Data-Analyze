package com.hikvision.yinterior.device.controller;

import com.hikvision.yinterior.device.service.DeviceService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

@RestController
@RequestMapping("/device")
public class DeviceController {

    @Autowired
    DeviceService deviceService;

    @PostMapping(value = "/devices/counts", produces = "application/json; charset=utf-8")
    @ApiOperation(value = "统计设备数量", httpMethod = "POST", notes = "统计设备数量")
    public Mono<Object> statisticsDeviceCounts() {

        return Mono.create(s -> s.success(deviceService.getDeviceCounts())
        ).subscribeOn(Schedulers.elastic());

    }


    @PostMapping(value = "/devices/top/increase", produces = "application/json; charset=utf-8")
    @ApiOperation(value = "统计top10的设备新增數", httpMethod = "POST", notes = "统计top10的设备新增數")
    public Mono<Object> statisticsTopDeviceIncrease() {

        return Mono.create(s -> s.success(deviceService.getDeviceMonthSort())
        ).subscribeOn(Schedulers.elastic());

    }

    @PostMapping(value = "/devices/active/rate", produces = "application/json; charset=utf-8")
    @ApiOperation(value = "统计设备活躍率", httpMethod = "POST", notes = "统计设备活躍率")
    public Mono<Object> statisticsActiveRate() {

        return Mono.create(s -> s.success(deviceService.getActiveDeviceAccess())
        ).subscribeOn(Schedulers.elastic());

    }
}
