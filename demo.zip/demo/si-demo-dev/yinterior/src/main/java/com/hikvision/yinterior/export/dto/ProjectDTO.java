package com.hikvision.yinterior.export.dto;

import lombok.Data;

@Data
public class ProjectDTO {

    //AppKey
    private String appKey;

    //浏览次数
    private Integer browseTimes;

    //活跃通道数
    private Integer activeAccess;

}
