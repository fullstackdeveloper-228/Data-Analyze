package com.hikvision.yinterior.project.repository;

import com.hikvision.yinterior.project.dto.ProjectMonthCountsInfoDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;


import java.util.Date;
import java.util.List;

@Mapper
public interface ProjectMapper {

    @Select("SELECT  count(app_key) as counts FROM project_info where create_date between #{startDate} and #{endDate};")
    Integer getProjectMonthCountsInfo(@Param("startDate") Date start, @Param("endDate") Date end);







}
