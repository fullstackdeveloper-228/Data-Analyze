package com.hikvision.yinterior.device.repository;

import com.hikvision.yinterior.access.vo.AccessProject;
import com.hikvision.yinterior.device.dto.ActiveDeviceAccessDTO;
import com.hikvision.yinterior.device.dto.DeviceMonthCountsInfoDTO;
import com.hikvision.yinterior.device.dto.DeviceProjectMonthDTO;
import com.hikvision.yinterior.device.vo.DeviceProject;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

@Mapper
public interface DeviceMapper {

    @Select("SELECT project_name as projectName,device_nums as deviceNums,access_nums as accessNums,active_devices as activeDevice,active_access as activeAccess FROM project_info where create_date between #{startDate} and #{endDate};")
    List<ActiveDeviceAccessDTO> getActiveDeviceAccess(@Param("startDate")Date start,@Param("endDate") Date end);

    @Select("SELECT SUM(device_nums) as counts FROM project_info where create_date between #{startDate} and #{endDate};")
    Integer getDeviceMonthCountsInfo(@Param("startDate")Date start,@Param("endDate") Date end);

    @Select("select app_key as key,project_name as name,device_nums as value from project_info where create_date between #{startDate} and #{endDate};")
    List<DeviceProjectMonthDTO> getDeviceMonthIncreaseInfo(@Param("startDate") Date start, @Param("endDate") Date end);



}
