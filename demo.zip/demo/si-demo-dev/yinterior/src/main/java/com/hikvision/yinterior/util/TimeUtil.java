package com.hikvision.yinterior.util;

import java.util.Calendar;
import java.util.Date;

public class TimeUtil {

    /**
     * @param monthsTag 0 本月月初  -1  上月月初  1 本月月末
     * @param dayTag  1 月初  0  月末
     * @return 指定日期
     */
    public static Date getDate(int monthsTag, int dayTag) {

        Calendar cale = Calendar.getInstance();
        cale.add(Calendar.MONTH, monthsTag);
        cale.set(Calendar.DAY_OF_MONTH, dayTag);
        cale.set(Calendar.MILLISECOND,0);
        cale.set(Calendar.SECOND,0);
        cale.set(Calendar.MINUTE,0);
        cale.set(Calendar.HOUR_OF_DAY,0);
        return cale.getTime();

    }




}
