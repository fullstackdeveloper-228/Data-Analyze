package com.hikvision.yinterior.device.dto;

import lombok.Data;

@Data
public class ActiveDeviceAccessDTO {

    private String projectName;

    private Integer deviceNums;

    private Integer accessNums;

    private Integer activeDevice;

    private Integer activeAccess;


}
