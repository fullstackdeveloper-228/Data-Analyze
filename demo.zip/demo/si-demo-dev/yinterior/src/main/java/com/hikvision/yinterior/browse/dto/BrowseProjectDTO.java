package com.hikvision.yinterior.browse.dto;

import lombok.Data;

@Data
public class BrowseProjectDTO {


    private String appKey;

    private String projectName;

    //总预览次数
    private Integer browseTimes;

    //总通道数
    private Integer accessCounts;
}
