package com.hikvision.yinterior.access.dto;

import lombok.Data;

@Data
public class AccessInfoDTO {

    private Integer accessCounts;

    private Integer lastCounts;

    private Integer thisCoubts;

}
