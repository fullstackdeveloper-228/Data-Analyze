package com.hikvision.yinterior.device.service;

import com.hikvision.hikkan.kcommon.bean.ObjectResult;


public interface DeviceService {

    ObjectResult getDeviceCounts();


    ObjectResult getActiveDeviceAccess();

    ObjectResult getDeviceMonthSort();
}
