package com.hikvision.yinterior.access.vo;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class AccessTopVo {

    List<AccessProject> all = new ArrayList<>();


    List<AccessProject> increase = new ArrayList<>();


}
