package com.hikvision.yinterior.export.service.impl;

import com.hikvision.hikkan.kcommon.bean.ObjectResult;
import com.hikvision.yinterior.export.dto.ProjectDTO;
import com.hikvision.yinterior.export.dto.ProjectItemDTO;
import com.hikvision.yinterior.export.repository.ExcelMapper;
import com.hikvision.yinterior.export.service.ExcelService;
import com.hikvision.yinterior.util.FileUtil;
import com.hikvision.yinterior.util.TimeUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class ExcelServiceImpl implements ExcelService {

    @Autowired
    ExcelMapper excelMapper;


    @Override
    public ObjectResult exportExcel() {


//        InputStream inputStream = null;

        List<ProjectItemDTO> list = new ArrayList<>();

        InputStream inputStream = null;
        try {
            inputStream = new FileInputStream("F:\\test\\test1.xlsx");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

//        try {
//            inputStream = file.getInputStream();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//        if(inputStream == null){
//            return ObjectResult.error("读取excel文件为空");
//        }

        String name = "test2.xlsx";

        //读取excel表格数据，封装对象
        try {

            list= FileUtil.readExcelToEntity(ProjectItemDTO.class,inputStream,name);

        } catch (Exception e) {

            e.printStackTrace();

        }

        if(list.isEmpty()){
            return ObjectResult.error("解析的数据为空");
        }

        //添加进数据库
        excelMapper.insertAllProject(list);

        return ObjectResult.SUCCESS;
    }

    @Override
    public void match() {

        //查出上个月的项目appkey,浏览记录与活跃通道数

        //获取上月月初
        Date beginMonth = TimeUtil.getDate(-1, 1);

        //获取本月月初
        Date endMonth = TimeUtil.getDate(0, 1);
        List<ProjectDTO> projectDTOS  = excelMapper.get(beginMonth,endMonth);


        //批量修改本月对应的项目的浏览记录与活跃通道数

        excelMapper.update(projectDTOS);


    }

}
