package com.hikvision.yinterior.device.vo;

import lombok.Data;

@Data
public class DeviceMonthInfo {

    private Integer counts;

    private Integer increaseCounts;

    private String increaseRate;

    private Integer tag;

}
