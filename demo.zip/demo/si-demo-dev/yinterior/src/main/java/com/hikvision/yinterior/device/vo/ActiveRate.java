package com.hikvision.yinterior.device.vo;

import lombok.Data;

@Data
public class ActiveRate {

    //設備活躍率
    private Double deviceActiveRate;

    //通道活躍率
    private Double accessActiveRate;

    //項目名
    private String projectName;

}
