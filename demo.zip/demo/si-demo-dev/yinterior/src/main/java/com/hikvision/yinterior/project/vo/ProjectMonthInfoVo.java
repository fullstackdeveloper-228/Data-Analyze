package com.hikvision.yinterior.project.vo;

import lombok.Data;

@Data
public class ProjectMonthInfoVo {

    private Integer counts;

    private Integer increaseCounts;

    private String increaseRate;

    private Integer tag;


}
