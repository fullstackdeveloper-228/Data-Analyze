package com.hikvision.yinterior.export.dto;

import lombok.Data;

import java.util.Calendar;
import java.util.Date;
@Data
public class ProjectItemDTO {

    //日期
    private Date date;

    //项目名
    private String projectName;

    //AppKey
    private String appKey;

    //负责人
    private String principal;

    //设备数
    private Integer devices;

    //通道数
    private Integer access;

    //浏览次数
    private Integer browseTimes;

    //活跃设备数
    private Integer activeDevices;

    //活跃通道数
    private Integer activeAccess;

}
