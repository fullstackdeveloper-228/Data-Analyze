package com.hikvision.yinterior.project.dto;

import lombok.Data;

import java.util.Date;

@Data
public class ProjectMonthCountsInfoDTO {

    //日期
    private Date date;

    //設備數
    private Integer counts;

}
