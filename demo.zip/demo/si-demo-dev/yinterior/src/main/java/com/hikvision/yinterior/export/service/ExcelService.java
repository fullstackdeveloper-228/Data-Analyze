package com.hikvision.yinterior.export.service;

import com.hikvision.hikkan.kcommon.bean.ObjectResult;
import org.springframework.web.multipart.MultipartFile;

public interface ExcelService {

    ObjectResult exportExcel();

    void match();


}