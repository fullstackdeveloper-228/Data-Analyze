package com.hikvision.yinterior.browse.controller;

import com.hikvision.yinterior.browse.service.BrowseService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

@RestController
@RequestMapping("/browse")
public class BrowseController {

    @Autowired
    BrowseService browseService;

    @PostMapping(value = "/counts", produces = "application/json; charset=utf-8")
    @ApiOperation(value = "统计预览次数", httpMethod = "POST", notes = "统计预览次数")
    public Mono<Object> statisticsBrowseCounts() {

        return Mono.create(s -> s.success(browseService.getBrowseCounts())
        ).subscribeOn(Schedulers.elastic());

    }

    @PostMapping(value = "/avg", produces = "application/json; charset=utf-8")
    @ApiOperation(value = "统计平均预览次数", httpMethod = "POST", notes = "统计平均预览次数")
    public Mono<Object> statisticsAvgBrowse() {

        return Mono.create(s -> s.success(browseService.getAvgBrowseCounts())
        ).subscribeOn(Schedulers.elastic());

    }


}
