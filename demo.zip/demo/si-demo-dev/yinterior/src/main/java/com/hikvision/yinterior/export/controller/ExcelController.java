package com.hikvision.yinterior.export.controller;

import com.hikvision.hikkan.kcommon.bean.ObjectResult;
import com.hikvision.yinterior.export.service.ExcelService;
import io.swagger.annotations.ApiOperation;
import org.apache.ibatis.annotations.Options;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.FileInputStream;
import java.io.InputStream;

@RestController
@RequestMapping("/excel")
public class ExcelController {

    @Autowired
    ExcelService excelService;

    //导入文件

    @RequestMapping(value = "/export1", method = RequestMethod.POST)
    @ApiOperation(value = "导入excel", httpMethod = "POST", notes = "导入excel")
    //@RequestParam MultipartFile file
    public ObjectResult exportExcel() {

        ObjectResult res = excelService.exportExcel();

        return res;

    }

    //匹配对应项

    @RequestMapping(value = "/match", method = RequestMethod.POST)
    @ApiOperation(value = "匹配对应的数据", httpMethod = "POST", notes = "匹配对应的数据")
    //@RequestParam MultipartFile file
    public void macth() {

        excelService.match();

        return;

    }


}