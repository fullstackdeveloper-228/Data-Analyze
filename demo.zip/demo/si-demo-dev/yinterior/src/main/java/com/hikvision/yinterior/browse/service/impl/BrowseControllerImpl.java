package com.hikvision.yinterior.browse.service.impl;

import com.hikvision.hikkan.kcommon.bean.ObjectResult;
import com.hikvision.yinterior.browse.dto.BrowseAccessDTO;
import com.hikvision.yinterior.browse.dto.BrowseProjectDTO;
import com.hikvision.yinterior.browse.repository.BrowseMapper;
import com.hikvision.yinterior.browse.service.BrowseService;
import com.hikvision.yinterior.browse.vo.AvgBrowseTimes;
import com.hikvision.yinterior.browse.vo.AvgBrowseTimesByProject;
import com.hikvision.yinterior.util.TimeUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
@Service
public class BrowseControllerImpl implements BrowseService {

    @Autowired
    private BrowseMapper browseMapper;

    @Override
    public ObjectResult getBrowseCounts() {

        //获取本月月初
        Date beginMonth = TimeUtil.getDate(0, 1);

        //获取本月月末
        Date endMonth = TimeUtil.getDate(1, 0);

        BrowseAccessDTO browseAccessDTO = browseMapper.getBrowseTimes(beginMonth,endMonth);

        Double accessCounts = browseAccessDTO.getAccessCounts() * 1.0;

        Integer browseTimes = browseAccessDTO.getBrowseTimes();

        Double avgBrowseTimes = browseTimes / accessCounts;

        AvgBrowseTimes avgBrowseTimes1 = new AvgBrowseTimes();

        String increase = String.format("%.2f", avgBrowseTimes);

        avgBrowseTimes1.setAvgBrowseTimes(increase);

        avgBrowseTimes1.setBrowseTimes(browseTimes);

        return ObjectResult.success(avgBrowseTimes1);
    }


    @Override
    public ObjectResult getAvgBrowseCounts() {

        //获取本月月初
        Date beginMonth = TimeUtil.getDate(0, 1);

        //获取本月月末
        Date endMonth = TimeUtil.getDate(1, 0);

        List<BrowseProjectDTO> browseProjectDTOS = browseMapper.getBrowseTimesByProject(beginMonth,endMonth);

        List<AvgBrowseTimesByProject> avgBrowseTimesByProjects = new ArrayList<>();

        for (BrowseProjectDTO browseProjectDTO : browseProjectDTOS) {

            Double accessCounts = browseProjectDTO.getAccessCounts() * 1.0;

            Integer browseTimes = browseProjectDTO.getBrowseTimes();

            Double avgBrowseTimes = accessCounts == 0d ? 0d : browseTimes / accessCounts;

            AvgBrowseTimesByProject avgBrowseTimesByProject = new AvgBrowseTimesByProject();

            avgBrowseTimesByProject.setAvgBrowseTimes(String.format("%.2f", avgBrowseTimes));

            avgBrowseTimesByProject.setBrowseTimes(browseTimes);

            avgBrowseTimesByProject.setProjectName(browseProjectDTO.getProjectName());

            avgBrowseTimesByProject.setAccessCounts(browseProjectDTO.getAccessCounts());

            avgBrowseTimesByProjects.add(avgBrowseTimesByProject);

        }

        avgBrowseTimesByProjects.sort(new Comparator<AvgBrowseTimesByProject>(){

            @Override
            public int compare(AvgBrowseTimesByProject o1, AvgBrowseTimesByProject o2) {
                return Double.parseDouble(o1.getAvgBrowseTimes()) - Double.parseDouble(o2.getAvgBrowseTimes()) >= 0d ? -1 : 1;
            }
        });

        avgBrowseTimesByProjects = avgBrowseTimesByProjects.subList(0, 10);

        return ObjectResult.success(avgBrowseTimesByProjects);
    }

}
