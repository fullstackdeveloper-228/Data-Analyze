package com.hikvision.yinterior.access.repository;

import com.hikvision.yinterior.access.dto.AccessMonthCountsInfoDTO;

import com.hikvision.yinterior.access.dto.AccessProjectMonthDTO;
import com.hikvision.yinterior.access.vo.AccessProject;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;


import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Mapper
public interface AccessMapper {

    @Select("SELECT sum(access_nums) as accessNums FROM project_info where create_date between #{startDate} and #{endDate};")
    Integer getAccessMonthCountsInfo(@Param("startDate")Date start,@Param("endDate") Date end);

    @Select("select app_key as key,project_name as name,access_nums as value from project_info where create_date between #{startDate} and #{endDate};")
    List<AccessProject> getAccessMonthIncreaseInfo(@Param("startDate")Date start,@Param("endDate") Date end);











}
