package com.hikvision.yinterior.access.dto;

import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
public class AccessProjectMonthDTO {

    /**
     * 日期
     */
    private Date key;



    private List<AccessProjectMonthInfoDTO> value;



}
