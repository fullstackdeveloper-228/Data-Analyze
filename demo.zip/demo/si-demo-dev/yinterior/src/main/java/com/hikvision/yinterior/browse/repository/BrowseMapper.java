package com.hikvision.yinterior.browse.repository;

import com.hikvision.yinterior.browse.dto.BrowseAccessDTO;
import com.hikvision.yinterior.browse.dto.BrowseProjectDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;


import java.util.Date;
import java.util.List;


@Mapper
public interface BrowseMapper {


    @Select("SELECT SUM(browse_times) as browseTimes,SUM(access_nums) as accessCounts FROM project_info where create_date between #{startDate} and #{endDate};")
    BrowseAccessDTO getBrowseTimes(@Param("startDate") Date start, @Param("endDate") Date end);


    @Select("SELECT app_key as appKey,project_name as projectName,browse_times as browseTimes,access_nums as accessCounts FROM project_info where create_date between #{startDate} and #{endDate};")
    List<BrowseProjectDTO> getBrowseTimesByProject(@Param("startDate") Date start, @Param("endDate") Date end);


}
