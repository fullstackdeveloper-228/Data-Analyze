package com.hikvision.yinterior.device.dto;

import lombok.Data;

import java.util.Date;

@Data
public class DeviceMonthCountsInfoDTO {

    //日期
    private Date date;

    //設備數
    private Integer counts;


}
