package com.hikvision.yinterior.device.dto;

import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
public class DeviceProjectMonthDTO {

    /**
     * 項目編碼
     */
    private String key;

    /**
     * 项目名
     */
    private String name;

    /**
     * 項目設備總數
     */
    private Integer value;


}
