package com.hikvision.yinterior.project.service.impl;

import com.hikvision.hikkan.kcommon.bean.ObjectResult;
import com.hikvision.yinterior.device.vo.DeviceMonthInfo;
import com.hikvision.yinterior.project.repository.ProjectMapper;
import com.hikvision.yinterior.project.service.ProjectService;
import com.hikvision.yinterior.project.vo.ProjectMonthInfoVo;
import com.hikvision.yinterior.util.TimeUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

/**
 * @author lvyamin
 */
@Service
public class ProjectServiceImpl implements ProjectService {

    @Autowired
    ProjectMapper projectMapper;

    @Override
    public ObjectResult getProjectCounts() {

        //获取本月月初
        Date beginMonth = TimeUtil.getDate(0, 1);

        //获取本月月末
        Date endMonth = TimeUtil.getDate(1, 0);

        //獲取本月的項目
        Integer counts = projectMapper.getProjectMonthCountsInfo(beginMonth, endMonth);


        //获取上月月初
        beginMonth = TimeUtil.getDate(-1, 1);

        //获取本月月初
        endMonth = TimeUtil.getDate(0, 1);

        //獲取上月的項目數
        Integer countsLast = projectMapper.getProjectMonthCountsInfo(beginMonth, endMonth);


        //計算本月比上月增加的通道數
        Integer increaseCounts = counts - countsLast;

        //計算增長率
        Double increaseRate = increaseCounts / (counts - increaseCounts * 1.0) * 100;

        //封裝
        ProjectMonthInfoVo projectMonthInfo = new ProjectMonthInfoVo();
        projectMonthInfo.setCounts(counts);
        if (increaseCounts < 0) {
            projectMonthInfo.setTag(0);
        } else {
            projectMonthInfo.setTag(1);
        }
        projectMonthInfo.setIncreaseCounts(Math.abs(increaseCounts));
        projectMonthInfo.setIncreaseRate(String.format("%.2f", Math.abs(increaseRate)));

        return ObjectResult.success(projectMonthInfo);


    }
}
