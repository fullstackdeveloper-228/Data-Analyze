package com.hikvision.yinterior.browse.vo;

import lombok.Data;

@Data
public class AvgBrowseTimes {

    private Integer browseTimes;

    private String avgBrowseTimes;


}
