package com.hikvision.yinterior.project.controller;

import com.hikvision.yinterior.device.service.DeviceService;
import com.hikvision.yinterior.project.service.ProjectService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

@RestController
@RequestMapping("/project")
public class ProjectController {

    @Autowired
    ProjectService projectService;

    @PostMapping(value = "/projects/counts", produces = "application/json; charset=utf-8")
    @ApiOperation(value = "统计項目数量", httpMethod = "POST", notes = "统计項目数量")
    public Mono<Object> statisticsProjectCounts() {

        return Mono.create(s -> s.success(projectService.getProjectCounts())
        ).subscribeOn(Schedulers.elastic());

    }


}
