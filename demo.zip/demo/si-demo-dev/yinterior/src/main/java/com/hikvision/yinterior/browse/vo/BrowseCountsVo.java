package com.hikvision.yinterior.browse.vo;

import lombok.Data;

@Data
public class BrowseCountsVo {

    private Integer counts;

    private Double rate;


}
