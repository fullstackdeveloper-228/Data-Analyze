package com.hikvision.hikkan.gbmg.base.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * json格式入参分页类基类
 *
 * @author renjie
 * @version 1.0.0
 */
@Data
public class PageBaseDto {

    @ApiModelProperty(value = "第几页",allowEmptyValue = true)
    private Integer pageNo = 1;

    @ApiModelProperty(value = "每页记录数",allowEmptyValue = true)
    private Integer pageSize = 20;

    @ApiModelProperty(hidden = true)
    private Integer page = 1;
    @ApiModelProperty(hidden = true)
    private Integer size = 20;

    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
        this.page = pageNo;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
        this.size = pageSize;
    }
}