package com.hikvision.hikkan.gbmg.user.controller;

import com.hikvision.hikkan.gbmg.common.exception.DescribeException;
import com.hikvision.hikkan.gbmg.monitor.dto.YsRestrictedTokenDto;
import com.hikvision.hikkan.gbmg.user.dto.ChangePwdDTO;
import com.hikvision.hikkan.gbmg.user.dto.SavePwdDTO;
import com.hikvision.hikkan.gbmg.user.service.UserService;
import com.hikvision.hikkan.gbmg.user.vo.UserAuthsVO;
import com.hikvision.hikkan.kcommon.bean.ObjectResult;
import com.hikvision.hikkan.kcommon.enums.ServerCodeEnum;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * Created by liuning9
 * 2019/7/17 16:05
 */
@Api(value = "垃圾分类用户服务", tags = "垃圾分类用户服务")
@RestController
@RequestMapping(value = "/garbage/web")
@Slf4j
public class UserController {

    @Autowired
    private UserService userService;

    @ApiOperation(value = "获取当前登陆用户权限", notes = "获取当前登陆用户权限")
    @PostMapping(value = "/auths")
    public ObjectResult<UserAuthsVO> getAuths(){

        try {
            return userService.getAuths();
        }catch (Exception e){
            log.error("获取当前登陆用户权限error",e);
        }
        return ObjectResult.error(ServerCodeEnum.SYSTEM_ERROR.getMsg());
    }

    @ApiOperation(value="获取萤石的限制级token", notes="获取萤石的限制级token")
    @RequestMapping(value= "/user/ys/restricted/token/get", method = RequestMethod.POST)
    public ObjectResult restrictedTokenGet(@RequestBody @Valid YsRestrictedTokenDto ysRestrictedTokenDto, BindingResult results)
    {
        if(results.hasErrors()){
            throw new DescribeException(results.getFieldError().getDefaultMessage(),ServerCodeEnum.PARAM_EMPTY.getCode());
        }
        return userService.restrictedTokenGet(ysRestrictedTokenDto);
    }

    @ApiOperation(value = "找回密码的reset密码", notes = "找回密码的reset密码")
    @PostMapping(value = "/changePwd")
    public ObjectResult changePwd(@RequestBody @Valid ChangePwdDTO dto, BindingResult results){
        if(results.hasErrors()){
            return ObjectResult.error(results.getFieldError().getDefaultMessage());
        }
        try {
            return userService.changePwd(dto);
        }catch (Exception e){
            log.error("修改用户密码error",e);
        }
        return ObjectResult.error(ServerCodeEnum.SYSTEM_ERROR.getMsg());
    }

    @ApiOperation(value = "修改密码", notes = "修改密码")
    @PostMapping(value = "/updatePwd")
    public ObjectResult updatePwd(@RequestBody @Valid SavePwdDTO dto, BindingResult results){
        if(results.hasErrors()){
            return ObjectResult.error(ServerCodeEnum.PARAM_ERROR.getMsg());
        }
        try {
           return userService.updatePwd(dto);
        }catch (Exception e){
            log.error("保存密码error",e);
        }
        return ObjectResult.error(ServerCodeEnum.SYSTEM_ERROR.getMsg());
    }
}
