package com.hikvision.hikkan.gbmg.login.vo;

import lombok.Data;

/**
 * Created by liuning9
 * 2019/7/22 11:32
 */
@Data
public class LoginVO {

    /**
     * token
     */
    private String authorization;
}
