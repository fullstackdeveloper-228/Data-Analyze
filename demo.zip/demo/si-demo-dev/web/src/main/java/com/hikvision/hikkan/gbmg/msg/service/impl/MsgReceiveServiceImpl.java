package com.hikvision.hikkan.gbmg.msg.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.hikvision.hikkan.gbmg.base.service.BaseService;
import com.hikvision.hikkan.gbmg.cache.redis.RedisUtil;
import com.hikvision.hikkan.gbmg.common.constant.StaticConstant;
import com.hikvision.hikkan.gbmg.common.util.rabbitmq.MsgProducer;
import com.hikvision.hikkan.gbmg.msg.dto.AlarmMsgReceiveDto;
import com.hikvision.hikkan.gbmg.msg.service.MsgReceiveService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * 接收消息业务层
 *
 * @author renjie
 * @version 1.0.0
 */
@Service
public class MsgReceiveServiceImpl extends BaseService implements MsgReceiveService {
    private Logger log = LoggerFactory.getLogger(MsgReceiveServiceImpl.class);
    @Autowired
    RedisUtil redisUtil;
    @Autowired
    MsgProducer msgProducer;

    @Async
    public void receiveAlarmMsg(String data)
    {
        AlarmMsgReceiveDto alarmMsgReceiveDto = JSON.parseObject(data, AlarmMsgReceiveDto.class);
        String messageId = alarmMsgReceiveDto.getMessageId();
        if(isRepeatMsg(messageId)){
            return;
        }
        List<AlarmMsgReceiveDto.Body> body = alarmMsgReceiveDto.getBody();
        if(null == body || body.size() == 0){
            return;
        }
        //发送消息到mq队列
        //body.forEach(b -> msgProducer.sendMsg(JSONObject.toJSONString(b)));
        msgProducer.sendMsg(JSONObject.toJSONString(alarmMsgReceiveDto));
    }



    /**
     * 根据messageId判断云曜消息是否是重复发送
     * 1、缓存过期时间为1天
     * @return
     */
    private boolean isRepeatMsg(String messageId){
        Object o = redisUtil.get(StaticConstant.GBMG_MESSAGE_RECEIVE_ALARMSERVICE_ISREPEATMSG);
        if(!Objects.isNull(o)){
            List<String> l = (List<String>)o;
            if(l.contains(messageId)){
                return true;
            }
            l.add(messageId);
        }else{
            List<String> l = new ArrayList<>();
            l.add(messageId);
            redisUtil.set(StaticConstant.GBMG_MESSAGE_RECEIVE_ALARMSERVICE_ISREPEATMSG,l,StaticConstant.ONE_DAY);
        }
        return false;
    }



}
