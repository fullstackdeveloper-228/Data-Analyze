package com.hikvision.hikkan.gbmg.garbagepoint.vo;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by liuning9
 * 2019/7/25 10:57
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class GarbagePointPageVO {
    /**
     * pk
     */
    @JsonSerialize(using = ToStringSerializer.class)
    protected Long id;

    /**
     * 垃圾点名称
     */
    protected String garbagePointName;
    /**
     * 组织id
     */
    @JsonSerialize(using = ToStringSerializer.class)
    protected Long orgId;
    /**
     *负责人
     */
    protected String leadingName;

    /**
     * 负责人手机号
     */
    protected String phoneNo;

    /**
     * 组织名称
     */
    private String groupName;

}
