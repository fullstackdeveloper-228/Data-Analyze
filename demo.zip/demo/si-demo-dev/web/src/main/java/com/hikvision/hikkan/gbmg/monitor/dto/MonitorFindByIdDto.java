package com.hikvision.hikkan.gbmg.monitor.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * 监控点查询
 *
 * @author renjie
 * @version 1.0.0
 */
@Data
public class MonitorFindByIdDto {

    @NotNull(message = "参数id不能为空")
    @ApiModelProperty(value = "监控点id")
    private Long id;

}
