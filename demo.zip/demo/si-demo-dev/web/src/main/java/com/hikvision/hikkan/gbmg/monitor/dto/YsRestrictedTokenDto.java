package com.hikvision.hikkan.gbmg.monitor.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 *  获取限制级token
 * @author : renjie
 * @version: 1.0.0
 */
@Data
public class YsRestrictedTokenDto {

    @NotNull(message = "参数dev不能为空")
    @ApiModelProperty(value = "设备")
    private String dev;

}
