package com.hikvision.hikkan.gbmg.monitor.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/**
 * 监控点查询
 *
 * @author renjie
 * @version 1.0.0
 */
@Data
public class MonitorGlobalByCodeDto {

    @NotEmpty(message = "参数monitorCode不能为空")
    @ApiModelProperty(value = "监控点编号，格式213321354#0")
    private String monitorCode;

    @NotNull(message = "参数projectId不能为空")
    @ApiModelProperty(value = "项目id")
    private Long projectId;

}
