//package com.hikvision.hikkan.gbmg.login.controller;
//
//import com.hikvision.hikkan.gbmg.base.Base;
//import com.hikvision.hikkan.gbmg.login.dto.*;
//import com.hikvision.hikkan.gbmg.login.service.impl.LoginServiceImpl;
//import com.hikvision.hikkan.gbmg.login.vo.ChallengeCodeVO;
//import com.hikvision.hikkan.gbmg.login.vo.LoginVO;
//import com.hikvision.hikkan.gbmg.login.vo.PhoneVerifyCodeVO;
//import com.hikvision.hikkan.kcommon.bean.ObjectResult;
//import com.hikvision.hikkan.kcommon.enums.ServerCodeEnum;
//import io.swagger.annotations.Api;
//import io.swagger.annotations.ApiOperation;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.validation.BindingResult;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import javax.validation.Valid;
//
///**
// * Created by liuning9
// * 2019/7/15 20:31
// */
//@Api(value = "垃圾分类登陆服务", tags = "垃圾分类登陆服务")
//@RestController
////@RequestMapping(value = "/garbage/web")
//@Slf4j
//public class LoginController extends Base {
//
//    @Autowired
//    private LoginServiceImpl loginServiceImpl;
//
//    /**
//     * 获取挑战码
//     */
//    @ApiOperation(value = "登陆获取挑战码", notes = "登陆获取挑战码")
//    @PostMapping(value = "/challengeCode")
//    public ObjectResult<ChallengeCodeVO> getChallengeCode(@RequestBody @Valid ChallengeRequestCodeDTO dto, BindingResult results) {
//        if(results.hasErrors()){
//            return ObjectResult.error(ServerCodeEnum.PARAM_ERROR.getMsg());
//        }
//        try {
//            return loginServiceImpl.getChallengeCode(dto);
//        }catch (Exception e){
//            log.error("获取挑战码error",e);
//        }
//        return ObjectResult.error(ServerCodeEnum.SYSTEM_ERROR.getMsg());
//    }
//
//    /**
//     * 登陆
//     * @param dto
//     * @param results
//     * @return
//     */
//    @ApiOperation(value = "登陆", notes = "登陆")
//    @PostMapping(value = "/login")
//    public ObjectResult<LoginVO> login(@RequestBody @Valid LoginDTO dto, BindingResult results){
//        if(results.hasErrors()){
//            return ObjectResult.error(ServerCodeEnum.PARAM_ERROR.getMsg());
//        }
//        try{
//            return loginServiceImpl.login(dto);
//        }catch (Exception e){
//            log.error("登陆失败",e);
//        }
//        return ObjectResult.error(ServerCodeEnum.SYSTEM_ERROR.getMsg());
//    }
//
//    /**
//     * 登出
//     * @return
//     */
//    @ApiOperation(value = "登出", notes = "登出")
//    @PostMapping(value = "/logout")
//    public ObjectResult logout(){
//        try {
//            return loginServiceImpl.logout();
//        }catch (Exception e){
//            log.error("登出失败",e);
//        }
//        return ObjectResult.error(ServerCodeEnum.SYSTEM_ERROR.getMsg());
//    }
//
//    /**
//     * 滑动检测
//     * @param dto
//     * @param results
//     * @return
//     */
//    @ApiOperation(value = "滑动检测", notes = "滑动检测")
//    @PostMapping(value = "/verifyCode")
//    public ObjectResult verifyCode(@RequestBody @Valid VerifyCodeDTO dto, BindingResult results){
//        if(results.hasErrors()){
//            return ObjectResult.error(results.getFieldError().getDefaultMessage());
//        }
//        try {
//            return loginServiceImpl.verifyCode(dto);
//        }catch (Exception e){
//            log.error("滑动检测失败",e);
//        }
//        return ObjectResult.error(ServerCodeEnum.SYSTEM_ERROR.getMsg());
//    }
//
//    /**
//     * 手机获取验证码
//     * @param dto
//     * @param results
//     * @return
//     */
//    @ApiOperation(value = "手机获取验证码", notes = "手机获取验证码")
//    @PostMapping(value = "/phone/verifyCode")
//    public ObjectResult<PhoneVerifyCodeVO> phoneVerifyCode(@RequestBody @Valid PhoneVerifyCodeDTO dto, BindingResult results){
//        if(results.hasErrors()){
//            return ObjectResult.error(ServerCodeEnum.PARAM_ERROR.getMsg());
//        }
//        try {
//            return loginServiceImpl.phoneVerifyCode(dto);
//        }catch (Exception e){
//            log.error("手机获取验证码error",e);
//        }
//        return ObjectResult.error(ServerCodeEnum.SYSTEM_ERROR.getMsg());
//    }
//
//    /**
//     * 校验手机验证码
//     * @param dto
//     * @param results
//     * @return
//     */
//    @ApiOperation(value = "校验手机验证码", notes = "校验手机验证码")
//    @PostMapping(value = "/phone/checkCode")
//    public ObjectResult<PhoneVerifyCodeVO> checkVerifyCode(@RequestBody @Valid CheckPhoneVerifyCodeDTO dto, BindingResult results){
//        if(results.hasErrors()){
//            return ObjectResult.error(ServerCodeEnum.PARAM_ERROR.getMsg());
//        }
//        try {
//            return loginServiceImpl.checkPhoneVerifyCode(dto);
//        }catch (Exception e){
//            log.error("校验手机验证码error",e);
//        }
//        return ObjectResult.error(ServerCodeEnum.SYSTEM_ERROR.getMsg());
//    }
//
//    /**
//     * 获取手机认证状态
//     * @param dto
//     * @param results
//     * @return
//     */
//    @ApiOperation(value = "获取手机认证状态", notes = "获取手机认证状态")
//    @PostMapping(value = "/user/phone/status")
//    public ObjectResult phoneStatus(@RequestBody @Valid PhoneSmsDTO dto, BindingResult results){
//        if(results.hasErrors()){
//            return ObjectResult.error(results.getFieldError().getDefaultMessage());
//        }
//        return loginServiceImpl.phoneStatus(dto);
//    }
//
//}
