package com.hikvision.hikkan.gbmg.garbagepoint.repository;

import com.hikvision.hikkan.gbmg.garbagepoint.domain.GarbagePointPO;
import com.hikvision.hikkan.gbmg.garbagepoint.dto.GarbagePointSearchDTO;
import com.hikvision.hikkan.kcommon.bean.PageData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Created by liuning9
 * 2019/7/24 10:55
 */
public interface GarbagePointDao extends JpaRepository<GarbagePointPO,Long>, JpaSpecificationExecutor<GarbagePointPO> {

    /**
     * 修改垃圾点信息
     * @param po
     * @return
     */
    @Modifying
    @Query("update GarbagePointPO p set p.garbagePointName = :#{#po.garbagePointName}, p.leadingName = :#{#po.leadingName}," +
            "p.operatorId = :#{#po.operatorId}, p.phoneNo = :#{#po.phoneNo}, p.orgId = :#{#po.orgId}, p.updateTime = :#{#po.updateTime} where p.id = :#{#po.id}")
    int updateById(@Param("po") GarbagePointPO po);

    /**
     * 获取垃圾点信息
     * @param dto
     * @return
     */
    PageData<GarbagePointPO> page(GarbagePointSearchDTO dto);

    /**
     * 批量删除垃圾点
     * @param ids
     * @return
     */
    int deleteByIdIn(List<Long> ids);

}
