package com.hikvision.hikkan.gbmg.msg.vo;

import cn.afterturn.easypoi.excel.annotation.Excel;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.Date;

/**
 * 消息历史记录vo
 *
 * @author renjie
 * @version 1.0.0
 */
@Data
@AllArgsConstructor
public class AlarmMsgHistoryVo {

    private Long id;

    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS+08:00")
    private Date enterAlarmTime;

    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS+08:00")
    private Date exitAlarmTime;

    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS+08:00")
    private Date processedExitAlarmTime;

    private Integer channel;

    public AlarmMsgHistoryVo(Long id, Date enterAlarmTime, Date exitAlarmTime, Integer channel, String devSerial,
                             String enUrl, String enThumbnailUrl, String exUrl, String exThumbnailUrl, String channelName, String deviceName, String garbagePointName) {
        this.id = id;
        this.enterAlarmTime = enterAlarmTime;
        this.exitAlarmTime = exitAlarmTime;
        this.channel = channel;
        this.devSerial = devSerial;
        this.enUrl = enUrl;
        this.enThumbnailUrl = enThumbnailUrl;
        this.exUrl = exUrl;
        this.exThumbnailUrl = exThumbnailUrl;
        this.channelName = channelName;
        this.deviceName = deviceName;
        this.garbagePointName = garbagePointName;
    }

    private String devSerial;

    private String channelName;

    private String enUrl;

    private String enThumbnailUrl;

    private String exUrl;

    private String exThumbnailUrl;


    /**
     * 监控点id
     */
    private Long monitorId;
    /**
     * 在线状态 0不在线，1在线
     */
    private Integer onlineStatus;
    /**
     * 在线状态中文名
     */
    private String onlineStatusStr;

    /**
     * 分配状态 未分配：0  已分配：1
     */
    private Integer allocationStatus;
    /**
     * 分配状态中文
     */
    private String allocationStatusStr;

    /**
     * 设备名称
     */
    private String deviceName;

    /**
     * 设备型号
     */
    private String model;

    /**
     * 设备类型中文
     */
    private String modelTypeStr;

    /**
     * 组织名称
     */
    @Excel(name = "所属组织", orderNum = "5")
    private String deviceOrgName;

    /**
     * 清晰度
     */
    private Integer videoLevel;

    /**
     * 是否加密，0：不加密，1：加密
     */
    private Integer isencrypt;

    /**
     * 是否查询预览记录
     */
    private boolean previewRecord;

    /**
     * 设备验证码
     */
    private String validateCode;

    /**
     * 设备序列号
     */
    private String monitorSerial;

    /**
     * 通道号
     */
    private Integer channum;

    /**
     * 监控点编号
     */
    private String monitorCode;

    /**
     * 通道名称
     */
    private String monitorName;

    /**
     * osd信息
     */
    private String osdName;

    /**
     * 预览时间
     */
    private Date previewTime;

    /**
     * 创建时间
     */
    private Date createTime = new Date();
    /**
     * 更新时间
     */
    private Date updateTime;
    /**
     * 创建者id
     */
    private Long createrId;

    /**
     * 操作者id
     */
    private Long operatorId;

    /**
     * 垃圾点位名称
     */
    private String garbagePointName;

    @JsonSerialize(using = ToStringSerializer.class)
    public Long getId() {
        return id;
    }
    @JsonSerialize(using = ToStringSerializer.class)
    public Long getMonitorId() {
        return monitorId;
    }
    @JsonSerialize(using = ToStringSerializer.class)
    public Long getCreaterId() {
        return createrId;
    }
    @JsonSerialize(using = ToStringSerializer.class)
    public Long getOperatorId() {
        return operatorId;
    }
}
