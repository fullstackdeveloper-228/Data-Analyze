package com.hikvision.hikkan.gbmg.garbagepoint.domain;

import com.hikvision.hikkan.gbmg.base.domain.BaseDomain;
import com.hikvision.hikkan.kcommon.util.SnowflakeIdGenerator;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Created by liuning9
 * 2019/7/24 10:15
 */
@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "garbage_point")
@EqualsAndHashCode(callSuper = true)
public class GarbagePointPO extends BaseDomain {

    @Id
    @Column(name = "id")
    private Long id = SnowflakeIdGenerator.getInstance().nextId();
    /**
     * 垃圾点名称
     */
    @Column(name = "garbage_point_name")
    private String garbagePointName;
    /**
     * 组织id
     */
    @Column(name = "org_id")
    private Long orgId;
    /**
     * 负责人name
     */
    @Column(name = "leading_name")
    private String leadingName;
    /**
     * 负责人手机号
     */
    @Column(name = "phone_no")
    private String phoneNo;
}
