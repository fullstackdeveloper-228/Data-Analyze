package com.hikvision.hikkan.gbmg.common.constant;

/**
 * Created by liuning9
 * 2019/7/24 10:35
 */
public enum DeviceTypeEnum {

    MONITOR(1,"监控点"),
    NB(2, "NB设备");

    private Integer index;

    private String value;

    DeviceTypeEnum(Integer index, String value) {
        this.index = index;
        this.value = value;
    }

    public Integer getIndex() {
        return index;
    }

    public void setIndex(Integer index) {
        this.index = index;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
