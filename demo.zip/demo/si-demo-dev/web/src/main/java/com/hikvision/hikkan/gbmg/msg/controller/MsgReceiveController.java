package com.hikvision.hikkan.gbmg.msg.controller;

import com.hikvision.hikkan.gbmg.base.controller.BaseController;
import com.hikvision.hikkan.gbmg.common.util.ResultUtil;
import com.hikvision.hikkan.gbmg.msg.service.MsgReceiveService;
import com.hikvision.hikkan.kcommon.bean.ObjectResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * 接收消息控制层
 *
 * @author renjie
 * @version 1.0.0
 */
@Api(value = "垃圾分类消息接收服务", tags = "垃圾分类消息接收服务")
@RestController
@RequestMapping("/garbage/receive/msg")
public class MsgReceiveController extends BaseController {
    private Logger log = LoggerFactory.getLogger(MsgReceiveController.class);
    @Autowired
    MsgReceiveService msgReceiveService;

    @ApiOperation(value="接收alarm类型的报警消息", notes="接收alarm类型的报警消息")
    @RequestMapping(value= "/alarm", method = RequestMethod.POST)
    public ObjectResult receiveAlarmMsg(String data)
    {
        try {
            //String desData = AesUtil.aesDecrypt(data, AesUtil.AES_KEY);
            //msgReceiveService.receiveAlarmMsg(desData);
            msgReceiveService.receiveAlarmMsg(data);
            return ResultUtil.success();
        } catch (Exception e) {
            log.info("receive alarm des error : {}" ,e);
            return ResultUtil.error();
        }
    }

}
