package com.hikvision.hikkan.gbmg.msg.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.hikvision.hikkan.gbmg.base.service.BaseService;
import com.hikvision.hikkan.gbmg.common.util.CommUtil;
import com.hikvision.hikkan.gbmg.common.util.JpaBeanUtil;
import com.hikvision.hikkan.gbmg.common.util.hikvision.HikkanApiUrl;
import com.hikvision.hikkan.gbmg.common.util.hikvision.HikkanUtil;
import com.hikvision.hikkan.gbmg.monitor.dto.MonitorPageDto;
import com.hikvision.hikkan.gbmg.msg.domain.AlarmMsgHistory;
import com.hikvision.hikkan.gbmg.msg.dto.AlarmMsgHistoryPageDto;
import com.hikvision.hikkan.gbmg.msg.repository.MsgWebRepository;
import com.hikvision.hikkan.gbmg.msg.service.MsgWebService;
import com.hikvision.hikkan.gbmg.msg.vo.AlarmMsgHistoryVo;
import com.hikvision.hikkan.kcommon.bean.ObjectResult;
import com.hikvision.hikkan.kcommon.bean.PageData;
import com.hikvision.hikkan.kcommon.enums.ServerCodeEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 消息历史记录业务层
 *
 * @author renjie
 * @version 1.0.0
 */
@Service
public class MsgWebServiceImpl extends BaseService implements MsgWebService {
    private Logger log = LoggerFactory.getLogger(MsgWebServiceImpl.class);
    @Autowired
    MsgWebRepository msgWebRepository;

    public PageData<AlarmMsgHistoryVo> page(AlarmMsgHistoryPageDto alarmMsgHistoryPage)
    {
        PageData<AlarmMsgHistoryVo> page = msgWebRepository.page(alarmMsgHistoryPage);
        createMonitorInfo(page);
        return page;
    }


    private void createMonitorInfo(PageData<AlarmMsgHistoryVo> alarmMsgHistoryPageData){
        if(Objects.isNull(alarmMsgHistoryPageData)){
            return;
        }
        //组装monitorCode
        List<AlarmMsgHistoryVo> list = alarmMsgHistoryPageData.getList();
        Set<String> monitorCodeSet = new HashSet<>();
        if(!Objects.isNull(list) && !list.isEmpty()){
            for (AlarmMsgHistoryVo alarmMsgHistoryVo : list) {
                monitorCodeSet.add(CommUtil.createMonitorCode(alarmMsgHistoryVo.getDevSerial(),alarmMsgHistoryVo.getChannel()));
            }
        }
        List<String> monitorCodeList = new ArrayList<String>(){{addAll(monitorCodeSet);}};

        MonitorPageDto monitorPageDto = new MonitorPageDto();
        monitorPageDto.setMonitorCodeList(monitorCodeList);
        monitorPageDto.setPageNo(0);
        monitorPageDto.setPageSize(Integer.MAX_VALUE);
        String s = HikkanUtil.httpPost(HikkanApiUrl.MONITOR_PAGE, JSONObject.toJSONString(monitorPageDto), cacheArtemisToken());
        ObjectResult<PageData<AlarmMsgHistoryVo>> listObjectResult = JSONObject.parseObject(s, new TypeReference<ObjectResult<PageData<AlarmMsgHistoryVo>>>() {
        });
        if(Objects.isNull(listObjectResult)){
            return;
        }
        if(ServerCodeEnum.SUCCESS.getCode().equals(listObjectResult.getCode())){
            if(Objects.isNull(listObjectResult.getData()) ||
                    Objects.isNull(listObjectResult.getData().getList()) || listObjectResult.getData().getList().isEmpty()){
                return;
            }
            Map<String, AlarmMsgHistoryVo> monitorCodeAlarmMsgHistoryVoMap = listObjectResult.getData().getList().stream().collect(Collectors.toMap(AlarmMsgHistoryVo::getMonitorCode, m -> m, (k1, k2) -> k1));
            list.forEach(l->{
                AlarmMsgHistoryVo alarmMsgHistoryVo = monitorCodeAlarmMsgHistoryVoMap.get(CommUtil.createMonitorCode(l.getDevSerial(),l.getChannel()));
                if(!Objects.isNull(alarmMsgHistoryVo)){
                    JpaBeanUtil.copyNullProperties(alarmMsgHistoryVo, l);
                    l.setMonitorId(alarmMsgHistoryVo.getId());
                    //处理结束时间
                    Long enterAlarmTime = l.getEnterAlarmTime().getTime();
                    Long exitAlarmTime = Objects.isNull(l.getExitAlarmTime()) ? 0 : l.getExitAlarmTime().getTime();
                    l.setProcessedExitAlarmTime(new Date(createEndTime(enterAlarmTime,exitAlarmTime)));
                    //l.setExitAlarmTime(new Date(createEndTime(enterAlarmTime,exitAlarmTime)));
                }
            });
        }else{
            log.error(listObjectResult.getCode() + ":" + listObjectResult.getMsg());
        }


    }


}
