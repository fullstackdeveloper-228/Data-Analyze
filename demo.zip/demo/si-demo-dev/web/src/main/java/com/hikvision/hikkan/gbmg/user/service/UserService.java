package com.hikvision.hikkan.gbmg.user.service;

import com.hikvision.hikkan.gbmg.user.dto.ChangePwdDTO;
import com.hikvision.hikkan.gbmg.user.dto.SavePwdDTO;
import com.hikvision.hikkan.gbmg.monitor.dto.YsRestrictedTokenDto;
import com.hikvision.hikkan.gbmg.user.vo.UserAuthsVO;
import com.hikvision.hikkan.kcommon.bean.ObjectResult;

/**
 * Created by liuning9
 * 2019/7/17 16:10
 */
public interface UserService {

    /**
     * 获取当前登陆用户权限
     * @return
     */
    ObjectResult<UserAuthsVO> getAuths();

    /**
     * 获取萤石的限制级token
     * @param ysRestrictedTokenDto
     * @return
     */
    ObjectResult restrictedTokenGet(YsRestrictedTokenDto ysRestrictedTokenDto);

    /**
     * 修改密码
     * @param dto
     * @return
     */
    ObjectResult changePwd(ChangePwdDTO dto) throws Exception;

    /**
     * 保存密码
     * @param dto
     * @return
     */
    ObjectResult updatePwd(SavePwdDTO dto) throws Exception;
}
