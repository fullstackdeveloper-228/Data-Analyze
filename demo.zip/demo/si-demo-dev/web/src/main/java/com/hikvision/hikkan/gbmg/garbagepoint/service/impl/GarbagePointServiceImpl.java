package com.hikvision.hikkan.gbmg.garbagepoint.service.impl;

import com.alibaba.fastjson.JSON;
import com.hikvision.hikkan.gbmg.common.constant.DeviceTypeEnum;
import com.hikvision.hikkan.gbmg.common.context.AuthContext;
import com.hikvision.hikkan.gbmg.garbagepoint.domain.GarbageDeviceMapPO;
import com.hikvision.hikkan.gbmg.garbagepoint.domain.GarbagePointPO;
import com.hikvision.hikkan.gbmg.garbagepoint.dto.GarbagePointDTO;
import com.hikvision.hikkan.gbmg.garbagepoint.dto.GarbagePointSearchDTO;
import com.hikvision.hikkan.gbmg.garbagepoint.repository.GarbageDeviceMapDao;
import com.hikvision.hikkan.gbmg.garbagepoint.repository.GarbagePointDao;
import com.hikvision.hikkan.gbmg.garbagepoint.service.GarbagePointService;
import com.hikvision.hikkan.gbmg.garbagepoint.vo.GarbagePointPageVO;
import com.hikvision.hikkan.gbmg.garbagepoint.vo.GarbagePointVO;
import com.hikvision.hikkan.gbmg.org.dto.OrgDTO;
import com.hikvision.hikkan.gbmg.org.service.OrgService;
import com.hikvision.hikkan.kcommon.bean.ObjectResult;
import com.hikvision.hikkan.kcommon.bean.PageData;
import com.hikvision.hikkan.kcommon.bean.login.JwtPayload;
import com.hikvision.hikkan.kcommon.enums.ServerCodeEnum;
import com.hikvision.hikkan.kcommon.util.JwtUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by liuning9
 * 2019/7/23 19:47
 */
@Service
@Slf4j
public class GarbagePointServiceImpl implements GarbagePointService {

    @Autowired
    private GarbagePointDao garbagePointDao;

    @Autowired
    private GarbageDeviceMapDao garbageDeviceMapDao;

    @Autowired
    private OrgService orgService;

    /**
     * 保存或修改垃圾点信息
     * @param dto
     * @return
     */
    @Override
    @Transactional
    public ObjectResult saveOrUpdate(GarbagePointDTO dto) {
        if(dto == null){
            return ObjectResult.error(ServerCodeEnum.PARAM_ERROR.getMsg());
        }
        //用户信息
        String token = AuthContext.getToken();
        if(StringUtils.isBlank(token)){
            throw new RuntimeException("垃圾点查询，用户信息为空");
        }
        Object auth = JwtUtils.getAuth(token);
        JwtPayload jwtPayload = JSON.parseObject(auth.toString(), JwtPayload.class);
        //新增垃圾点
        if(dto.getId() == null){
            //保存垃圾点基本信息
            GarbagePointPO save = garbagePointDao.save(packageGarbagePointPO(dto, true, jwtPayload));
            dto.setId(save.getId());
            //保存垃圾点关联设备信息
            List<GarbageDeviceMapPO> deviceList = packageGarbageDeviceMapPO(dto, true, jwtPayload);
            if(CollectionUtils.isEmpty(deviceList)){
                return ObjectResult.success("垃圾点信息保存成功");
            }
            garbageDeviceMapDao.saveAll(deviceList);
            return ObjectResult.success("垃圾点信息保存成功");
        }
        //修改操作
        garbagePointDao.updateById(packageGarbagePointPO(dto, false, jwtPayload));
        //修改垃圾点关联设备
        //1.获取垃圾点原有的关联设备
        List<String> newPlus = packageKey(packageGarbageDeviceMapPO(dto, false, jwtPayload));
        List<GarbageDeviceMapPO> originalList = garbageDeviceMapDao.findByGarbagePointId(dto.getId());
        List<String> original = packageKey(originalList);
        //新增关联设备
        List<String> add = newPlus.parallelStream()
                .filter(device -> filterDevice(device, original) == false)
                .collect(Collectors.toList());
        //删除关联设备
        List<String> del = original.parallelStream()
                .filter(old -> filterDevice(old, newPlus) == false)
                .collect(Collectors.toList());
        List<GarbageDeviceMapPO> addPO = packageUpdateGarbageDevice(add, dto.getId(), jwtPayload);
        List<GarbageDeviceMapPO> delPO = packageUpdateGarbageDevice(del, dto.getId(), jwtPayload);
        if(CollectionUtils.isNotEmpty(addPO)) {
            garbageDeviceMapDao.saveAll(addPO);
        }
        if(CollectionUtils.isNotEmpty(delPO)){
            HashMap<String,Long> delIdMap = new HashMap<>(delPO.size());
            originalList.stream()
                    .forEach(po -> {
                        String key = po.getGarbagePointId().toString() + po.getDeviceId() + po.getType();
                        delIdMap.put(key, po.getId());
                    });
            List<Long> delIds = delPO.stream().parallel()
                    .filter(ids -> delIdMap.containsKey(ids.getGarbagePointId().toString() + ids.getDeviceId() + ids.getType()))
                    .map(ids -> delIdMap.get(ids.getGarbagePointId().toString() + ids.getDeviceId() + ids.getType()))
                    .collect(Collectors.toList());
            garbageDeviceMapDao.deleteByIdIn(delIds);
        }
        return ObjectResult.success("保存或修改垃圾点信息成功");
    }

    /**
     * 垃圾点详情
     * @param id
     * @return
     */
    @Override
    public ObjectResult<GarbagePointVO> findById(Long id) {
        if(id == null){
            return ObjectResult.error(ServerCodeEnum.PARAM_ERROR.getMsg());
        }
        Optional<GarbagePointPO> garbage = garbagePointDao.findById(id);
        GarbagePointPO po = garbage.get();
        List<GarbageDeviceMapPO> devices = garbageDeviceMapDao.findByGarbagePointId(id);
        GarbagePointVO result = new GarbagePointVO();
        result.setPhoneNo(po.getPhoneNo());
        result.setOrgId(po.getOrgId());
        result.setLeadingName(po.getLeadingName());
        result.setGarbagePointName(po.getGarbagePointName());
        result.setId(po.getId());
        List<String> nbList = new ArrayList<>();
        List<String> monitorList = new ArrayList<>();
        devices.stream()
                .forEach(device -> {
                    if(DeviceTypeEnum.MONITOR.getIndex().equals(device.getType())){
                        monitorList.add(device.getDeviceId().toString());
                    }else {
                        nbList.add(device.getDeviceId().toString());
                    }
                });
        result.setMonitorList(monitorList);
        result.setNbDeviceList(nbList);
        return ObjectResult.success(result);
    }

    /**
     * 获取垃圾点列表信息
     * @param dto
     * @return
     */
    @Override
    public ObjectResult<PageData<GarbagePointPageVO>> page(GarbagePointSearchDTO dto) {
        if(dto == null) {
            return ObjectResult.error(ServerCodeEnum.PARAM_ERROR.getMsg());
        }
        //关联下级组织id进行查询
        if(dto.getObtainChild()){
            List<Long> orgIdList = orgService.findAllIdListByParent(dto.getOrgId());
            dto.getOrgIds().addAll(orgIdList);
        }else {
            dto.getOrgIds().add(dto.getOrgId());
        }
        //垃圾点基本信息
        PageData<GarbagePointPO> page = garbagePointDao.page(dto);
        String token = AuthContext.getToken();
        if(StringUtils.isBlank(token)){
            throw new RuntimeException("垃圾点查询，用户信息为空");
        }
        //获取项目id
        Object auth = JwtUtils.getAuth(token);
        Long projectId = JSON.parseObject(auth.toString(), JwtPayload.class).getProjectId();
        //组织id list
        List<Long> orgIds = page.getList().parallelStream()
                .map(GarbagePointPO::getOrgId)
                .collect(Collectors.toList());
        List<OrgDTO> byIdsAndProjectId = orgService.findByIdsAndProjectId(orgIds, projectId);
        if(CollectionUtils.isEmpty(byIdsAndProjectId)){
            log.error("组织信息获取失败");
        }
        HashMap<Long, String> orgMap = (HashMap<Long, String>) byIdsAndProjectId.parallelStream()
                .collect(Collectors.toMap(OrgDTO::getId, OrgDTO::getGroupName));
        //返回module package
        List<GarbagePointPageVO> pageVOList = page.getList().parallelStream()
                .map(po -> packageVO(po, orgMap))
                .collect(Collectors.toList());

        PageData<GarbagePointPageVO> result = new PageData<>();
        result.setTotalPage(page.getTotalPage());
        result.setTotal(page.getTotal());
        result.setPageSize(page.getPageSize());
        result.setPageNo(page.getPageNo());
        result.setList(pageVOList);

        return ObjectResult.success(result);
    }

    /**
     * package garbagePointPageVO
     * @param po
     * @return
     */
    private GarbagePointPageVO packageVO(GarbagePointPO po, HashMap<Long, String> orgMap){
        if(po == null){
            return  null;
        }
        GarbagePointPageVO add = new GarbagePointPageVO();
        add.setPhoneNo(po.getPhoneNo());
        add.setOrgId(po.getOrgId());
        add.setLeadingName(po.getLeadingName());
        add.setId(po.getId());
        add.setGarbagePointName(po.getGarbagePointName());
        add.setGroupName(orgMap.get(po.getOrgId()));
        return add;
    }

    /**
     * 删除垃圾点信息
     * @param ids
     * @return
     */
    @Override
    @Transactional
    public ObjectResult delete(List<Long> ids) {
        if(CollectionUtils.isEmpty(ids)){
            return ObjectResult.error(ServerCodeEnum.PARAM_ERROR.getMsg());
        }
        //删除垃圾点信息
        garbagePointDao.deleteByIdIn(ids);
        //删除垃圾点关联设备信息
        garbageDeviceMapDao.deleteByGarbagePointIdIn(ids);
        return ObjectResult.SUCCESS;
    }

    /**
     * package修改的垃圾点关联设备
     * @param list
     * @param id
     * @return
     */
    private List<GarbageDeviceMapPO> packageUpdateGarbageDevice(List<String> list, Long id, JwtPayload jwtPayload){
        if(CollectionUtils.isEmpty(list)){
            return Collections.emptyList();
        }
        return list.stream().parallel()
                .map(key -> {
                    Integer type = Integer.valueOf(key.split(",")[0]);
                    Long deviceId = Long.valueOf(key.split(",")[1]);
                    GarbageDeviceMapPO add = new GarbageDeviceMapPO();
                    add.setGarbagePointId(id);
                    if(DeviceTypeEnum.MONITOR.getIndex().equals(type)){
                        add.setType(DeviceTypeEnum.MONITOR.getIndex());
                    }else {
                        add.setType(DeviceTypeEnum.NB.getIndex());
                    }
                    add.setDeviceId(deviceId);
                    add.setUpdateTime(new Date());
                    add.setCreateTime(new Date());
                    add.setOperatorId(jwtPayload.getUserId());
                    add.setCreaterId(jwtPayload.getUserId());
                    return add;
                }).collect(Collectors.toList());
    }

    /**
     * 过滤出新旧不匹配的监控点和设备的值
     * @param single
     * @param list
     * @return
     */
    private Boolean filterDevice(String single, List<String> list){
        if(CollectionUtils.isEmpty(list) || StringUtils.isBlank(single)){
            return false;
        }
        return list.stream().anyMatch(dto -> dto.equals(single));
    }

    /**
     * 包装新,老垃圾点关联设备key值（monitorId/nbDeviceId + type）
     * @param sourceList
     * @return
     */
    List<String> packageKey(List<GarbageDeviceMapPO> sourceList){
        if(CollectionUtils.isEmpty(sourceList)){
            return Collections.emptyList();
        }
        List<String> result = sourceList.stream()
                .map(po -> {
                    String end = po.getType().toString() + "," +po.getDeviceId().toString();
                    return end;
                }).collect(Collectors.toList());
        return result;
    }

    /**
     * 包装垃圾点PO
     * @param dto
     * @param flag false:修改，true：新增
     * @return
     */
    private GarbagePointPO packageGarbagePointPO(GarbagePointDTO dto, Boolean flag, JwtPayload jwtPayload){
        if(dto == null){
            throw new RuntimeException("垃圾点包装信息为null");
        }
        GarbagePointPO result = new GarbagePointPO();
        //修改时id不为null
        if(!flag) {
            result.setId(dto.getId());
            result.setUpdateTime(new Date());
            result.setOperatorId(jwtPayload.getUserId());
        }
        if(flag){
            result.setCreateTime(new Date());
            result.setCreaterId(jwtPayload.getUserId());
            result.setOperatorId(jwtPayload.getUserId());
        }
        result.setGarbagePointName(dto.getGarbagePointName());
        result.setLeadingName(dto.getLeadingName());
        result.setOrgId(dto.getOrgId());
        result.setPhoneNo(dto.getPhoneNo());
        return result;
    }

    /**
     * 包装垃圾点关联设备
     * @param dto
     * @param flag false:修改，true：新增
     * @return
     */
    private List<GarbageDeviceMapPO> packageGarbageDeviceMapPO(GarbagePointDTO dto, Boolean flag, JwtPayload jwtPayload){
        if(dto == null){
            throw new RuntimeException("垃圾点包装信息为null");
        }
        List<GarbageDeviceMapPO> result = new ArrayList<>(dto.getMonitorList().size() + dto.getNbDeviceList().size());
        //监控点设备
        if(CollectionUtils.isNotEmpty(dto.getMonitorList())){
            List<GarbageDeviceMapPO> monitorList = dto.getMonitorList().parallelStream()
                    .map(monitor -> {
                        GarbageDeviceMapPO add = packageSameFields(monitor, dto, flag, jwtPayload);
                        add.setType(DeviceTypeEnum.MONITOR.getIndex());
                        return add;
                    }).collect(Collectors.toList());
            result.addAll(monitorList);
        }
        //NB设备
        if(CollectionUtils.isNotEmpty(dto.getNbDeviceList())){
            List<GarbageDeviceMapPO> nbList = dto.getNbDeviceList().parallelStream()
                    .map(nb -> {
                        GarbageDeviceMapPO add = packageSameFields(nb, dto, flag, jwtPayload);
                        add.setType(DeviceTypeEnum.NB.getIndex());
                        return add;
                    }).collect(Collectors.toList());
            result.addAll(nbList);
        }
        return result;
    }

    /**
     * 相同的字段package
     * @param id
     * @param dto
     * @param flag
     * @return
     */
    private GarbageDeviceMapPO packageSameFields(Long id, GarbagePointDTO dto, boolean flag, JwtPayload jwtPayload){
        GarbageDeviceMapPO add = new GarbageDeviceMapPO();
        add.setGarbagePointId(dto.getId());
        add.setDeviceId(id);
        if(flag) {
            add.setCreateTime(new Date());
            add.setCreaterId(jwtPayload.getUserId());
            add.setOperatorId(jwtPayload.getUserId());
        }else {
            add.setUpdateTime(new Date());
            add.setOperatorId(jwtPayload.getUserId());
        }
        return add;
    }
}
