package com.hikvision.hikkan.gbmg.garbagepoint.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * 监控点查询
 *
 * @author liuning
 * @version 1.0.0
 */
@Data
public class GarbageDeleteByIdsDTO {

    @NotNull(message = "参数ids不能为空")
    @ApiModelProperty(value = "垃圾点ids")
    private String[] ids;

}
