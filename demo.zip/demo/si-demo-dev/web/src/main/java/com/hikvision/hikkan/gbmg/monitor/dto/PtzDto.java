package com.hikvision.hikkan.gbmg.monitor.dto;

import com.hikvision.hikkan.kcommon.constant.HikkanConstants;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/**
 * 云台控制
 *
 * @author renjie
 * @version 1.0.0
 */
@Data
public class PtzDto {

    @Pattern(regexp = HikkanConstants.DEVICE_SERIAL_PATTERN, message = "参数deviceSerial只能包含数字字母")
    @Length(max = 32, message = "参数deviceSerial长度不能大于32位")
    @NotEmpty(message = "参数deviceSerial不能为空")
    @ApiModelProperty(value = "设备序列号")
    private String deviceSerial;

    @NotNull(message = "参数channelNo不能为空")
    @ApiModelProperty(value = "通道号")
    private Integer channelNo;


    @NotNull(message = "参数direction不能为空")
    @Range(min = 0,max = 11, message = "参数direction格式不正确")
    @ApiModelProperty(value = "操作命令：0-上，1-下，2-左，3-右，4-左上，5-左下，6-右上，7-右下，8-放大，9-缩小，10-近焦距，11-远焦距")
    private Integer direction;

    //@NotNull(message = "参数speed不能为空")
    @Range(min = 0,max = 2, message = "参数speed格式不正确")
    @ApiModelProperty(value = "云台速度：0-慢，1-适中，2-快")
    private Integer speed;

    @NotNull(message = "参数direction不能为空")
    @Range(min = 0,max = 1, message = "参数type格式不正确")
    @ApiModelProperty(value = "云台控制类型：0-开始，1-停止")
    private Integer type;
}
