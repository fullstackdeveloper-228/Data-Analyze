package com.hikvision.hikkan.gbmg.base;

import com.hikvision.hikkan.kcommon.bean.login.JwtPayload;
import com.hikvision.hikkan.kcommon.bean.login.JwtProductPayload;
import com.hikvision.hikkan.kcommon.context.AuthContext;
import com.hikvision.hikkan.gbmg.common.util.CommUtil;

import java.util.Objects;

/**
 * 基类
 *
 * @author renjie
 * @version 1.0.0
 */
public class Base {
    /**
     * 获取当前登录的用户id
     * @return
     */
    public Long getUserId()
    {
        Long userId = null;
        JwtPayload user = AuthContext.getUser();
        if(CommUtil.isNotNullOrEmpty(user)){
            userId = user.getUserId();
        }
        return userId;
    }

    /**
     * 获取当前登录用户的项目id
     * @return
     */
    public Long getProjectId(){
        Long projectId = null;
        JwtPayload user = AuthContext.getUser();
        if(CommUtil.isNotNullOrEmpty(user)) {
            projectId = user.getProjectId();
        }
        return projectId;
    }

    /**
     * 获取用户类型 0：个人用户 1：租户用户 2：系统用户
     * @return
     */
    public Integer getUserType(){
        Integer type = null;
        JwtPayload user = AuthContext.getUser();
        if(CommUtil.isNotNullOrEmpty(user)){
            type = user.getType();
        }
        return type;
    }

    /**
     * 是否是个人用户
     * @return
     */
    public boolean isPersonalUser(){
        JwtPayload user = AuthContext.getUser();
        if(CommUtil.isNotNullOrEmpty(user)){
            return user.getType() == 0;
        }
        return false;
    }

    /**
     * 租户用户
     * @return
     */
    public boolean isZhUser(){
        JwtPayload user = AuthContext.getUser();
        if(CommUtil.isNotNullOrEmpty(user)){
            return user.getType() == 1;
        }
        return false;
    }

    /**
     * 运营用户
     * @return
     */
    public boolean isYyUser(){
        JwtPayload user = AuthContext.getUser();
        if(CommUtil.isNotNullOrEmpty(user)){
            return user.getType() == 2;
        }
        return false;
    }


    /**
     * 获取产品编号
     * @return
     */
    public String getProductCode(){
        String projectCode = null;
        JwtPayload user = AuthContext.getUser();
        if(CommUtil.isNotNullOrEmpty(user)) {
            projectCode = user.getProductCode();
        }
        return projectCode;
    }

    /**
     * 是否是产品维度的全局token权限
     * @return
     */
    public boolean isGlobal(){
        JwtProductPayload product = AuthContext.getProduct();
        return !Objects.isNull(product);
    }

}
