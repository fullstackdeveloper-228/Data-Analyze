package com.hikvision.hikkan.gbmg.common.constant;

/**
 * 消息类型枚举类
 *
 * @author renjie
 * @version 1.0.0
 */
public enum AlarmTypeEnum {

    EXITAREADETECTION("exit","exitareadetection"),
    ENTERAREADETECTION("enter","enterareadetection");


    private final String name;
    private final String value;
    AlarmTypeEnum(String name, String value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public String getValue() {
        return value;
    }

    /**
     * 是否存在
     * @param value
     * @return
     */
    public static boolean exist(String value){
        for(AlarmTypeEnum ate : AlarmTypeEnum.values()){
            if(ate.getValue().equals(value)){
                return true;
            }
        }
        return false;
    }
}
