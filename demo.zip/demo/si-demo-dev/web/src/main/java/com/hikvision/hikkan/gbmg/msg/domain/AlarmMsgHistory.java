package com.hikvision.hikkan.gbmg.msg.domain;

import com.hikvision.hikkan.gbmg.base.domain.BaseDomain;
import com.hikvision.hikkan.kcommon.util.SnowflakeIdGenerator;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

/**
 * 报警消息接收类
 *
 * @author renjie
 * @version 1.0.0
 */
@Data
@Entity
@Table(name = "alarm_msg_history")
@EqualsAndHashCode(callSuper = true)
public class AlarmMsgHistory  extends BaseDomain {

    @Id
    private Long id = SnowflakeIdGenerator.getInstance().nextId();
    /**
     * 报警时间 2019-07-11T12:25:09
     */
    private Date alarmTime;
    /**
     * 通道号
     */
    private Integer channel;
    /**
     * 设备序列号
     */
    private String devSerial;
    /**
     * 报警类型 只接收enterareadetection/exitareadetection类型
     */
    private String alarmType;
    /**
     * 报警id
     */
    private String alarmId;
    /**
     * 通道名称
     */
    private String channelName;
    /**
     * 设备名称
     */
    private String deviceName;
    /**
     * 图片url
     */
    private String url;

    /**
     * 缩略图url
     */
    private String thumbnailUrl;

    /**
     * 出去报警类型的消息id
     */
    private Long exitAlarmId;

    /**
     * 报警的的监控点id
     */
    private Long monitorId;
}
