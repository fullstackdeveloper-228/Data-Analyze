package com.hikvision.hikkan.gbmg.org.dto;

import cn.afterturn.easypoi.excel.annotation.Excel;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.hikvision.hikkan.kcommon.util.SnowflakeIdGenerator;
import lombok.Data;
import javax.persistence.Transient;
import java.math.BigDecimal;
import java.util.List;

/**
 * 设备组织
 *
 * @author renjie
 * @version 1.0.0
 */
@Data
public class DeviceOrgDto {

    private static final long serialVersionUID = 7291943992082860001L;
    /**
     * id
     */
    private Long id;
    /**
     * 项目id
     */
    private Long projectId;
    /**
     * 组织名称
     */
    private String groupName;
    /**
     * 父节点id
     */
    private Long parentId;
    /**
     * 描述
     */
    private String  description;
    /**
     * 节点所在层级
     */
    private Integer level;
    /**
     * 可挂载的最大设备数
     */
    private Long maxDevices;
    /**
     * 前一个节点的id（用于排序）
     */
    private BigDecimal precedeId;

    /**
     * 组织编号（随机生成）
     */
    private String orgCode;

    /**
     * 树的类型 0 : 主表  1：业务表
     */
    private Integer type;

    /**
     * 节点类型
     */
    private Integer nodeType;


    /**
     * 是否全选该节点下的设备资源，（该字段不映射到数据库表）
     */
    private boolean isAll;

    /**
     * 是否选中（该字段不映射到数据库表）
     */
    private boolean devOrgSelectable;

    /**
     * 是否禁止节点
     */
    private boolean isForbidden;

    /**
     * 选中的组织节点下的设备资源id列表（该字段不映射到数据库表）
     */
    private List<String> deviceInfoDtoIdList;

    /**
     * 行号（该字段不映射到数据库表）
     */
    private Integer rowNo;

    public DeviceOrgDto(){

    }

    public DeviceOrgDto(Long projectId, String groupName, Long parentId, String description, Long maxDevices, String orgCode, Integer nodeType) {
        this.id = SnowflakeIdGenerator.getInstance().nextId();
        this.projectId = projectId;
        this.groupName = groupName;
        this.parentId = parentId;
        this.description = description;
        this.maxDevices = maxDevices;
        this.orgCode = orgCode;
        this.nodeType = nodeType;
    }

    public DeviceOrgDto(Long id, String groupName, String description, Long maxDevices, Integer nodeType) {
        this.id = id;
        this.groupName = groupName;
        this.description = description;
        this.maxDevices = maxDevices;
        this.nodeType = nodeType;
    }

    @JsonSerialize(using = ToStringSerializer.class)
    public void setId(Long id) {
        this.id = id;
    }

    @JsonSerialize(using = ToStringSerializer.class)
    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    @JsonSerialize(using = ToStringSerializer.class)
    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

}
