package com.hikvision.hikkan.gbmg.org.dto;

import lombok.Data;

import java.util.List;

/**
 * Created by liuning9
 * 2019/7/30 19:15
 */
@Data
public class OrgFindByIdsDTO {
    /**
     * 项目id
     */
    private Long projectId;

    /**
     * 项目ids集合
     */
    private List<Long> orgIdlist;
}
