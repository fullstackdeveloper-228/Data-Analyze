package com.hikvision.hikkan.gbmg.org.dto;
import lombok.Data;
/**
 * Created by liuning9
 * 2019/7/30 19:19
 */
@Data
public class OrgDTO {
    /**
     * 组织名称
     */
    private String groupName;
    /**
     * 组织id
     */
    private Long id;

}
