package com.hikvision.hikkan.gbmg.device.controller;

import com.hikvision.hikkan.gbmg.base.controller.BaseController;
import com.hikvision.hikkan.gbmg.common.constant.DeviceKindTypeEnum;
import com.hikvision.hikkan.gbmg.common.exception.DescribeException;
import com.hikvision.hikkan.gbmg.device.dto.DeviceInfoPage;
import com.hikvision.hikkan.gbmg.device.service.DeviceService;
import com.hikvision.hikkan.kcommon.bean.ObjectResult;
import com.hikvision.hikkan.kcommon.enums.ServerCodeEnum;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * 设备
 *
 * @author renjie
 * @version 1.0.0
 */
@Api(value = "垃圾分类设备服务", tags = "垃圾分类设备服务")
@RestController
@RequestMapping("/garbage/web/device")
public class DeviceWebController extends BaseController {

    @Autowired
    private DeviceService deviceService;

    @ApiOperation(value="分页查询nb设备", notes="分页查询nb设备")
    @RequestMapping(value= "/nb/page", method = RequestMethod.POST)
    public ObjectResult nbPage(@RequestBody @Valid DeviceInfoPage deviceInfoPage, BindingResult results)
    {
        if(results.hasErrors()){
            throw new DescribeException(results.getFieldError().getDefaultMessage(),ServerCodeEnum.PARAM_EMPTY.getCode());
        }
        deviceInfoPage.setDeviceKind(DeviceKindTypeEnum.NB.getValue());
        return deviceService.devicePage(deviceInfoPage);
    }
}
