package com.hikvision.hikkan.gbmg.garbagepoint.repository;

import com.hikvision.hikkan.gbmg.base.repository.BaseRepository;
import com.hikvision.hikkan.gbmg.garbagepoint.domain.GarbagePointPO;
import com.hikvision.hikkan.gbmg.garbagepoint.dto.GarbagePointSearchDTO;
import com.hikvision.hikkan.gbmg.garbagepoint.vo.GarbagePointPageVO;
import com.hikvision.hikkan.kcommon.bean.PageData;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Pageable;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

/**
 * Created by liuning9
 * 2019/7/25 17:04
 */
public class GarbagePointDaoImpl extends BaseRepository {

    @PersistenceContext
    private EntityManager entityManager;

    public PageData<GarbagePointPO> page(GarbagePointSearchDTO dto){
        StringBuilder dataSql = new StringBuilder("select new com.hikvision.hikkan.gbmg.garbagepoint.domain.GarbagePointPO" +
                "(point.id,point.garbagePointName,point.orgId,point.leadingName,point.phoneNo) " +
                "from GarbagePointPO point where 1=1");

        //关键字信息
        String keyWord = dto.getKeyWord();

        if(StringUtils.isNotEmpty(keyWord)){
            dataSql.append(" AND (point.garbagePointName like CONCAT('%', :keyWord, '%') OR point.leadingName like CONCAT('%', :keyWord, '%')" +
                    " OR point.phoneNo like CONCAT('%', :keyWord, '%'))");
        }
        //组织id
        List<Long> orgIds = dto.getOrgIds();
        if(CollectionUtils.isNotEmpty(orgIds)){
            dataSql.append(" AND point.orgId in :orgIds");
        }
        dataSql.append(" order by point.createTime desc");

        Query dataQuery = entityManager.createQuery(dataSql.toString(), GarbagePointPO.class);

        if(StringUtils.isNotEmpty(keyWord)){
            dataQuery.setParameter("keyWord", keyWord);
        }

        if(CollectionUtils.isNotEmpty(orgIds)){
            dataQuery.setParameter("orgIds", orgIds);
        }
        Pageable pageRequest = createPageRequest(dto.getPageNo(), dto.getPageSize(), null);
        return dataQuery2PageData(dataQuery, pageRequest, new PageData());
    }
}
