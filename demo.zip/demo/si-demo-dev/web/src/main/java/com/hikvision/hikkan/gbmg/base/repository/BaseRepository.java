package com.hikvision.hikkan.gbmg.base.repository;

import com.hikvision.hikkan.kcommon.bean.PageData;
import com.hikvision.hikkan.gbmg.base.Base;
import com.hikvision.hikkan.gbmg.common.util.CommUtil;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import javax.persistence.Query;
import java.util.List;

/**
 * 数据层基础类
 *
 * @author renjie
 * @version 1.0.0
 */
public class BaseRepository  extends Base {

    /**
     * 分页查询类转换
     * @param dataQuery
     * @param pageable
     * @return
     */
    protected PageData dataQuery2PageData(Query dataQuery, Pageable pageable, PageData pageData)
    {
        int total = dataQuery.getResultList().size();
        int pageSize = pageable.getPageSize();
        int pageNumber = pageable.getPageNumber();
        dataQuery.setFirstResult((int)pageable.getOffset());
        dataQuery.setMaxResults(pageSize);
        List resultList = dataQuery.getResultList();
        int totalPage = (total + pageSize - 1) / pageSize;

        if(CommUtil.isNullOrEmpty(pageData)){
            return new PageData(pageNumber + 1, pageSize, (long)total, totalPage, resultList);
        }else{
            pageData.setPageNo(pageNumber + 1);
            pageData.setPageSize(pageSize);
            pageData.setTotal((long)total);
            pageData.setTotalPage(totalPage);
            pageData.setList(resultList);
            return pageData;
        }
    }

    /**
     * 根据入参，生成PageRequest类
     * @param pageNo
     * @param pageSize
     * @param sort
     * @return
     */
    protected Pageable createPageRequest(Integer pageNo, Integer pageSize, Sort sort)
    {
        if(CommUtil.isNullOrEmpty(pageNo) || pageNo < 1) {
            pageNo = 1;
        }
        if(CommUtil.isNullOrEmpty(pageSize) || pageSize < 1){
            pageSize = 20;
        }
        if(CommUtil.isNullOrEmpty(sort)){
            sort = new Sort(Sort.Direction.DESC,"createTime");
        }
        return new PageRequest(pageNo - 1, pageSize, sort);
    }

}
