package com.hikvision.hikkan.gbmg.garbagepoint.dto;

import com.hikvision.hikkan.gbmg.base.dto.PageBaseDto;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.data.domain.jaxb.SpringDataJaxb;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuning9
 * 2019/7/25 10:53
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class GarbagePointSearchDTO extends PageBaseDto {

    @ApiModelProperty(value = "关键字查询：垃圾点名称",allowEmptyValue = true)
    private String keyWord;

  /*  @ApiModelProperty(value = "组织id", allowEmptyValue = true)*/
    private Long orgId;

    @ApiModelProperty(value = "关联下级", allowEmptyValue = true)
    private Boolean obtainChild = false;

    private List<Long> orgIds = new ArrayList<>();
}
