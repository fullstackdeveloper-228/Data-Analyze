package com.hikvision.hikkan.gbmg.garbagepoint.controller;

import com.hikvision.hikkan.gbmg.garbagepoint.dto.GarbageDeleteByIdsDTO;
import com.hikvision.hikkan.gbmg.garbagepoint.dto.GarbageFindByIdDTO;
import com.hikvision.hikkan.gbmg.garbagepoint.dto.GarbagePointDTO;
import com.hikvision.hikkan.gbmg.garbagepoint.dto.GarbagePointSearchDTO;
import com.hikvision.hikkan.gbmg.garbagepoint.service.GarbagePointService;
import com.hikvision.hikkan.gbmg.garbagepoint.vo.GarbagePointPageVO;
import com.hikvision.hikkan.gbmg.garbagepoint.vo.GarbagePointVO;
import com.hikvision.hikkan.gbmg.login.dto.ChallengeRequestCodeDTO;
import com.hikvision.hikkan.gbmg.login.vo.ChallengeCodeVO;
import com.hikvision.hikkan.kcommon.bean.ObjectResult;
import com.hikvision.hikkan.kcommon.bean.PageData;
import com.hikvision.hikkan.kcommon.enums.ServerCodeEnum;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuning9
 * 2019/7/23 19:45
 */
@Api(value = "垃圾点服务", tags = "垃圾点服务")
@RestController
@RequestMapping(value = "/garbage/web/point")
@Slf4j
public class GarbagePointController {

    @Autowired
    private GarbagePointService garbagePointService;

    /**
     * 获取挑战码
     */
    @ApiOperation(value = "保存或修改垃圾点", notes = "保存或修改垃圾点")
    @PostMapping(value = "/save")
    public ObjectResult saveOrUpdate(@RequestBody @Valid GarbagePointDTO dto, BindingResult results) {
        if(results.hasErrors()){
            return ObjectResult.error(results.getFieldError().getDefaultMessage());
        }
            return garbagePointService.saveOrUpdate(dto);
    }

    @ApiOperation(value = "垃圾点详情", notes = "垃圾点详情")
    @PostMapping(value = "/get")
    public ObjectResult<GarbagePointVO> findById(@RequestBody GarbageFindByIdDTO dto, BindingResult results){
        if(results.hasErrors()){
            return ObjectResult.error(results.getFieldError().getDefaultMessage());
        }
        return garbagePointService.findById(dto.getId());
    }

    @ApiOperation(value = "获取垃圾点列表信息", notes = "获取垃圾点列表信息")
    @PostMapping(value = "/page")
    public ObjectResult<PageData<GarbagePointPageVO>> page(@RequestBody @Valid GarbagePointSearchDTO dto, BindingResult results){
        if(results.hasErrors()){
            return ObjectResult.error(results.getFieldError().getDefaultMessage());
        }
        return garbagePointService.page(dto);
    }

    @ApiOperation(value = "批量删除垃圾点", notes = "批量删除垃圾点")
    @PostMapping(value = "/delete")
    public ObjectResult delete(@RequestBody GarbageDeleteByIdsDTO dto, BindingResult results){
        if(results.hasErrors() || dto.getIds() == null){
            return ObjectResult.error(ServerCodeEnum.PARAM_ERROR.getMsg());
        }
        List<Long> sourceIds = new ArrayList<>(dto.getIds().length);
        for (String id : dto.getIds()) {
            sourceIds.add(Long.parseLong(id));
        }
        return garbagePointService.delete(sourceIds);
    }

}
