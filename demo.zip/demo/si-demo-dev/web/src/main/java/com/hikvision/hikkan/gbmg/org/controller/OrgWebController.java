package com.hikvision.hikkan.gbmg.org.controller;

import com.hikvision.hikkan.gbmg.base.controller.BaseController;
import com.hikvision.hikkan.gbmg.org.service.OrgService;
import com.hikvision.hikkan.kcommon.bean.ObjectResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * 组织
 *
 * @author renjie
 * @version 1.0.0
 */
@Api(value = "垃圾分类组织服务", tags = "垃圾分类组织服务")
@RestController
@RequestMapping("/garbage/web/org")
public class OrgWebController extends BaseController {

    @Autowired
    private OrgService orgService;

    @ApiOperation(value="获取用户组织树", notes="获取用户组织树")
    @RequestMapping(value= "/tree", method = RequestMethod.POST)
    public ObjectResult orgTree()
    {
        return orgService.orgTree();
    }
}
