package com.hikvision.hikkan.gbmg.init;

import com.hikvision.hikkan.kcommon.util.SnowflakeIdGenerator;
import com.hikvision.hikkan.gbmg.cache.redis.RedisUtil;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

/**
 * spring 容器加载完毕后调用
 *
 * @author heqian7
 * @version 1.0.0
 */
@Component
public class ApplicationInit implements ApplicationContextAware {

    @Autowired
    private RedisUtil redisUtil;

    @Value("${spring.application.name}")
    private String name;

    /**
     * 1.初始化SnowflakeIdGenerator
     */
    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        String snowflakeId = "SnowflakeId";
        try {
            redisUtil.lock(snowflakeId + "-key", 90000L, () -> {
                Map<String, Object> map = redisUtil.hmget(snowflakeId);
                int workId = 0;
                if (map == null || map.size() == 0) {
                    map = new HashMap<>(16);
                    SnowflakeIdGenerator.init(workId);
                    map.put(name + "-" + getIpAddress(), workId);
                } else {
                    Object o = map.get(name + "-" + getIpAddress());
                    if (o != null) {
                        SnowflakeIdGenerator.init(Long.parseLong(o.toString()));
                    } else {
                        map.put(name + "-" + getIpAddress(), map.size());
                        SnowflakeIdGenerator.init(map.size());
                    }
                }
                redisUtil.hmset(snowflakeId, map);
                return null;
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 本机获取ip地址
     */
    public static String getIpAddress() {
        try {
            Enumeration<NetworkInterface> allNetInterfaces = NetworkInterface.getNetworkInterfaces();
            InetAddress ip = null;
            while (allNetInterfaces.hasMoreElements()) {
                NetworkInterface netInterface = (NetworkInterface) allNetInterfaces.nextElement();
                if (netInterface.isLoopback() || netInterface.isVirtual() || !netInterface.isUp()) {
                    continue;
                } else {
                    Enumeration<InetAddress> addresses = netInterface.getInetAddresses();
                    while (addresses.hasMoreElements()) {
                        ip = addresses.nextElement();
                        if (ip != null && ip instanceof Inet4Address) {
                            return ip.getHostAddress();
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }
}
