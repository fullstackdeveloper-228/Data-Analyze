package com.hikvision.hikkan.gbmg.org.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.hikvision.hikkan.gbmg.base.service.BaseService;
import com.hikvision.hikkan.gbmg.common.util.hikvision.HikkanApiUrl;
import com.hikvision.hikkan.gbmg.common.util.hikvision.HikkanUtil;
import com.hikvision.hikkan.gbmg.org.dto.OrgDTO;
import com.hikvision.hikkan.gbmg.org.dto.OrgFindByIdsDTO;
import com.hikvision.hikkan.gbmg.org.dto.OrgTree;
import com.hikvision.hikkan.gbmg.org.service.OrgService;
import com.hikvision.hikkan.kcommon.bean.ObjectResult;
import com.hikvision.hikkan.kcommon.enums.ServerCodeEnum;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * 组织业务层
 *
 * @author renjie
 * @version 1.0.0
 */
@Service
public class OrgServiceImpl extends BaseService implements OrgService {
    private Logger log = LoggerFactory.getLogger(OrgServiceImpl.class);


    /**
     * 获取用户组织树
     * @return
     */
    @Override
    public ObjectResult orgTree() {
        String result = HikkanUtil.httpPost(HikkanApiUrl.ORG_TREE, JSONObject.toJSONString(new Object()), cacheArtemisToken());
        return JSONObject.parseObject (result,ObjectResult.class);
    }

    /**
     * 获取某个组织节点下的所有组织
     * @param parentId
     * @return
     */
    @Override
    public List<Long>  findAllIdListByParent(Long id){
        List<Long> list = new ArrayList<>();
        //从云曜获取组织树
        ObjectResult objectResult = orgTree();
        if(ServerCodeEnum.SUCCESS.getCode().equals(objectResult.getCode())){
            ObjectResult<List<OrgTree>> orgTreeObjectResult = JSONObject.parseObject(JSONObject.toJSONString(objectResult), new TypeReference<ObjectResult<List<OrgTree>>>() {
            });
            List<OrgTree> orgTreeList = orgTreeObjectResult.getData();
            if(Objects.isNull(orgTreeList)){
                return list;
            }
            //查找组织节点
            OrgTree orgTree = new OrgTree();
            findOrgTreeById(id, orgTreeList, orgTree);
            //收集id
            if(!Objects.isNull(orgTree.getId())){
                getChildrenIdList(orgTree,list);
            }
            return list;
        }else{
            log.error("调用云曜接口异常{}" + objectResult.getMsg());
            return list;
        }
    }

    @Override
    public List<OrgDTO> findByIdsAndProjectId(List<Long> orgIds, Long id) {
        if(CollectionUtils.isEmpty(orgIds) || id == null){
            return Collections.emptyList();
        }
        OrgFindByIdsDTO source = new OrgFindByIdsDTO();
        source.setOrgIdlist(orgIds);
        source.setProjectId(id);
        String result = HikkanUtil.httpPostWithToken(HikkanApiUrl.ORG_BY_IDS, JSONObject.toJSONString(source), cacheArtemisToken(), globalToken());
        ObjectResult<List<OrgDTO>> vo = JSONObject.parseObject(result, new TypeReference<ObjectResult<List<OrgDTO>>>() {
        });
       return vo.getData();
    }

    /**
     * 查找某个组织节点
     * @param id
     * @param orgTreeList
     * @return
     */
    private void findOrgTreeById(Long id,List<OrgTree> orgTreeList,OrgTree orgTree){
        if(Objects.isNull(id)){
            return;
        }
        for (OrgTree ot : orgTreeList) {
            if(id.equals(ot.getId())){
                BeanUtils.copyProperties(ot,orgTree);
                return;
            }else{
                List<OrgTree> children = ot.getChildren();
                if(!Objects.isNull(children) && !children.isEmpty()){
                    findOrgTreeById(id,children,orgTree);
                }
            }
        }
        return;
    }

    /**
     * 递归查询父节点下的所有id集合
     * @param parentId
     * @param orgTree
     * @param result
     */
    private void getChildrenIdList(OrgTree orgTree, List<Long> result){
        result.add(orgTree.getId());
        List<OrgTree> children = orgTree.getChildren();
        if(!Objects.isNull(children) && !children.isEmpty()){
            children.forEach(c->{
                getChildrenIdList(c,result);
            });
        }
    }
}
