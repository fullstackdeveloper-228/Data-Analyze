package com.hikvision.hikkan.gbmg.msg.service;

import com.hikvision.hikkan.gbmg.msg.domain.AlarmMsgHistory;
import com.hikvision.hikkan.gbmg.msg.dto.AlarmMsgHistoryPageDto;
import com.hikvision.hikkan.gbmg.msg.vo.AlarmMsgHistoryVo;
import com.hikvision.hikkan.kcommon.bean.PageData;

public interface MsgWebService {

    PageData<AlarmMsgHistoryVo> page(AlarmMsgHistoryPageDto alarmMsgHistoryPage);
}
