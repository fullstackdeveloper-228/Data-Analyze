package com.hikvision.hikkan.gbmg.msg.repository;
import com.hikvision.hikkan.gbmg.base.repository.BaseRepository;
import com.hikvision.hikkan.gbmg.common.util.CommUtil;
import com.hikvision.hikkan.gbmg.msg.dto.AlarmMsgHistoryPageDto;
import com.hikvision.hikkan.gbmg.msg.vo.AlarmMsgHistoryVo;
import com.hikvision.hikkan.kcommon.bean.PageData;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * 监控点信息数据层实现类
 *
 * @author renjie
 * @version 1.0.0
 */
public class MsgWebRepositoryImpl extends BaseRepository {

    @PersistenceContext
    private EntityManager entityManager;

    public PageData<AlarmMsgHistoryVo> page(AlarmMsgHistoryPageDto alarmMsgHistoryPageDto){
        StringBuilder dataSql = new StringBuilder("select new com.hikvision.hikkan.gbmg.msg.vo.AlarmMsgHistoryVo" +
                "(amhEn.id,amhEn.alarmTime,amhEx.alarmTime,amhEn.channel,amhEn.devSerial,amhEn.url,amhEn.thumbnailUrl,amhEx.url,amhEx.thumbnailUrl,amhEn.channelName,amhEn.deviceName,gp.garbagePointName) " +
                "from AlarmMsgHistory amhEn left join AlarmMsgHistory amhEx");


        dataSql.append(" on amhEn.exitAlarmId = amhEx.id" +
                " join GarbageDeviceMapPO gdm on gdm.deviceId = amhEn.monitorId" +
                " join GarbagePointPO gp on gp.id = gdm.garbagePointId" +
                " WHERE amhEn.alarmType = 'enterareadetection'");

        //关键字（设备序列号和设备通道号名称）
        String keyWord = alarmMsgHistoryPageDto.getKeyWord();
        if(StringUtils.isNotEmpty(keyWord)){
            dataSql.append(" AND (amhEn.channelName like CONCAT('%', :keyWord, '%')" +
                    " OR amhEn.devSerial like CONCAT('%', :keyWord, '%')" +
                    " OR amhEn.deviceName like CONCAT('%', :keyWord, '%')" +
                    " OR gp.garbagePointName like CONCAT('%', :keyWord, '%'))");
        }
        //进来时间
        Date enterAlarmTime = alarmMsgHistoryPageDto.getEnterAlarmTime();
        if(!Objects.isNull(enterAlarmTime)){
            dataSql.append(" AND amhEn.alarmTime >= :enterAlarmTime");
        }
        //出去时间
        Date exitAlarmTime = alarmMsgHistoryPageDto.getExitAlarmTime();
        if(!Objects.isNull(exitAlarmTime)){
            dataSql.append(" AND amhEn.alarmTime <= :exitAlarmTime");
        }

        dataSql.append(" order by amhEn.createTime desc");

        Query dataQuery = entityManager.createQuery(dataSql.toString(), AlarmMsgHistoryVo.class);

        if(StringUtils.isNotEmpty(keyWord)){
            dataQuery.setParameter("keyWord", keyWord);
        }

        if(!Objects.isNull(enterAlarmTime)){
            dataQuery.setParameter("enterAlarmTime", enterAlarmTime);
        }

        if(!Objects.isNull(exitAlarmTime)){
            dataQuery.setParameter("exitAlarmTime", exitAlarmTime);
        }
        Pageable pageRequest = createPageRequest(alarmMsgHistoryPageDto.getPageNo(), alarmMsgHistoryPageDto.getPageSize(), null);
        return dataQuery2PageData(dataQuery, pageRequest, new PageData());
    }

}
