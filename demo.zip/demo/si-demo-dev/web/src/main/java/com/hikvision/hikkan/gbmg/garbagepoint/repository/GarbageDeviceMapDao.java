package com.hikvision.hikkan.gbmg.garbagepoint.repository;

import com.hikvision.hikkan.gbmg.garbagepoint.domain.GarbageDeviceMapPO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;

/**
 * Created by liuning9
 * 2019/7/24 16:45
 */
public interface GarbageDeviceMapDao extends JpaRepository<GarbageDeviceMapPO,Long>, JpaSpecificationExecutor<GarbageDeviceMapPO> {

    /**
     * 获取垃圾点关联的设备
     * @param garbagePointId
     * @return
     */
    List<GarbageDeviceMapPO> findByGarbagePointId(long garbagePointId);

    /**
     *
     * @param ids
     * @return
     */
    int deleteByIdIn(List<Long> ids);

    /**
     * 删除垃圾点id的设备
     * @param garbagePointIds
     * @return
     */
    int deleteByGarbagePointIdIn(List<Long> garbagePointIds);

    /**
     * 根据设备id查询
     * @param deviceId
     * @return
     */
    GarbageDeviceMapPO findByDeviceId(Long deviceId);
}
