package com.hikvision.hikkan.gbmg.monitor.service.impl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.hikvision.hikkan.gbmg.base.service.BaseService;
import com.hikvision.hikkan.gbmg.common.constant.StaticConstant;
import com.hikvision.hikkan.gbmg.common.util.DateUtil;
import com.hikvision.hikkan.gbmg.common.util.hikvision.HikkanApiUrl;
import com.hikvision.hikkan.gbmg.common.util.hikvision.HikkanUtil;
import com.hikvision.hikkan.gbmg.garbagepoint.domain.GarbageDeviceMapPO;
import com.hikvision.hikkan.gbmg.garbagepoint.repository.GarbageDeviceMapDao;
import com.hikvision.hikkan.gbmg.monitor.dto.*;
import com.hikvision.hikkan.gbmg.monitor.service.MonitorService;
import com.hikvision.hikkan.gbmg.msg.domain.AlarmMsgHistory;
import com.hikvision.hikkan.gbmg.msg.repository.MsgWebRepository;
import com.hikvision.hikkan.kcommon.bean.ObjectResult;
import com.hikvision.hikkan.kcommon.bean.PageData;
import com.hikvision.hikkan.kcommon.enums.ServerCodeEnum;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * 监控点业务层
 *
 * @author renjie
 * @version 1.0.0
 */
@Service
public class MonitorServiceImpl extends BaseService implements MonitorService {
    private Logger log = LoggerFactory.getLogger(MonitorServiceImpl.class);
    @Autowired
    private GarbageDeviceMapDao garbageDeviceMapDao;
    @Autowired
    MsgWebRepository msgWebRepository;
    /**
     * 获取录像片段(用于前端h5画时间轴)
     * @param monitorVideoByTimeDto
     * @return
     */
    public ObjectResult videoByTime(MonitorVideoByTimeDto monitorVideoByTimeDto)
    {
        Long startTime = monitorVideoByTimeDto.getStartTime();
        Long endTime = monitorVideoByTimeDto.getEndTime();
        monitorVideoByTimeDto.setStartTime(startTime);
        monitorVideoByTimeDto.setEndTime(createEndTime(startTime,endTime));
        String monitorVideoByTimeJson = JSONObject.toJSONString(monitorVideoByTimeDto);
        String result = HikkanUtil.httpPost(HikkanApiUrl.VIDEO_BY_TIME, monitorVideoByTimeJson, cacheArtemisToken());
        return JSONObject.parseObject (result,ObjectResult.class);
    }

    /**
     * 根据id查询监控点
     * @param monitorVideoByTime
     * @return
     */
    public ObjectResult monitorById(MonitorFindByIdDto monitorFindByIdDto)
    {
        String monitorFindByIdJson = JSONObject.toJSONString(monitorFindByIdDto);
        String result = HikkanUtil.httpPost(HikkanApiUrl.MONITOR_BY_ID, monitorFindByIdJson, cacheArtemisToken());
        return JSONObject.parseObject (result,ObjectResult.class);
    }

    /**
     * 云台操作
     * @param ptzDto
     * @return
     */
    public ObjectResult ptz(PtzDto ptzDto)
    {
        String ptzJson = JSONObject.toJSONString(ptzDto);
        String result = HikkanUtil.httpPost(HikkanApiUrl.PTZ, ptzJson, cacheArtemisToken());
        return JSONObject.parseObject (result,ObjectResult.class);
    }

    /**
     * 监控点分页
     * @return
     */
    @Override
    public ObjectResult page(MonitorPageDto monitorPageDto) {
        String monitorPageDtoJson = JSONObject.toJSONString(monitorPageDto);
        String result = HikkanUtil.httpPost(HikkanApiUrl.MONITOR_PAGE, monitorPageDtoJson, cacheArtemisToken());
        //对监控点进行过滤
        ObjectResult<PageData<MonitorInfoVo>> listObjectResult = JSONObject.parseObject(result, new TypeReference<ObjectResult<PageData<MonitorInfoVo>>>() {
        });
        if(ServerCodeEnum.SUCCESS.getCode().equals(listObjectResult.getCode())){
            List<MonitorInfoVo> list = listObjectResult.getData().getList();
            for (MonitorInfoVo monitorInfoVo : list) {
                Long id = monitorInfoVo.getId();
                GarbageDeviceMapPO byDeviceId = garbageDeviceMapDao.findByDeviceId(id);
                if(!Objects.isNull(byDeviceId) && !byDeviceId.getGarbagePointId().equals(monitorPageDto.getPointId())){
                    monitorInfoVo.setOccupiedByPoint(true);
                }
            }
        }
        return listObjectResult;
    }

    /**
     * 获取播放器播放的xml
     * @return
     */
    @Override
    public ObjectResult getPlayXml(MonitorGetPlayXmlDto monitorGetPlayXmlDto) {
        String monitorGetPlayXmlDtoJson = JSONObject.toJSONString(monitorGetPlayXmlDto);
        String result = HikkanUtil.httpPost(HikkanApiUrl.PLAY_XML_GET, monitorGetPlayXmlDtoJson, cacheArtemisToken());
        ObjectResult objectResult = JSONObject.parseObject(result, ObjectResult.class);
        if(ServerCodeEnum.SUCCESS.getCode().equals(objectResult.getCode())){
            String xml = (String)objectResult.getData();
            //设置报警时间
            String s = setAlarmTimeToXml(xml, monitorGetPlayXmlDto.getMsgHistoryId());
            return ObjectResult.success((Object)s);
        }
        return null;
    }

    /**
     * 给平台播放器的xml赋报警时间值
     * @param xml
     * @param msgHistoryId
     * @return
     */
    private String setAlarmTimeToXml(String xml, Long msgHistoryId){
        Optional<AlarmMsgHistory> byId = msgWebRepository.findById(msgHistoryId);
        String timeStrByFormate;
        if(byId.isPresent()){
            Date alarmTime = new Date(byId.get().getAlarmTime().getTime() + StaticConstant.ONE_MINUTES);
            timeStrByFormate = DateUtil.timeDate2TimeStrByFormate(alarmTime, DateUtil.PLAY_VIDEO_XML_TIME_FORMAT);
        }else{
            timeStrByFormate = DateUtil.timeDate2TimeStrByFormate(new Date(), DateUtil.PLAY_VIDEO_XML_TIME_FORMAT);
        }

        try {
            Document document = DocumentHelper.parseText(xml);
            Element rootElement = document.getRootElement();
            Element cameraList = rootElement.element("CameraList");
            List elements = cameraList.elements();
            for (Object element : elements) {
                ((Element)element).addElement("AlarmTime").setText(timeStrByFormate);
            }
            return document.asXML();
        } catch (DocumentException e) {
            log.error("parse xml error:{}",e);
        }
        return null;
    }


}
