package com.hikvision.hikkan.gbmg.login.vo;

import lombok.Data;

/**
 * Created by liuning9
 * 2019/7/22 14:53
 */
@Data
public class PhoneVerifyCodeVO {

    /**
     * 校验码
     */
    private String verifyCode;
}
