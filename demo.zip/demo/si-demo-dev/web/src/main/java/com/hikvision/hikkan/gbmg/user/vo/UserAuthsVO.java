package com.hikvision.hikkan.gbmg.user.vo;

import lombok.Data;

import java.util.Collection;

/**
 * 用户权限信息
 * @author : liuning
 * @date: 2018/12/11
 * @version: 1.0.0
 */

@Data
public class UserAuthsVO {

    private String userId;

    private String userName;
    /** 用户类型：0 ：租户超级管理员  1：租户普通管理员  2: 普通用户 **/
    private Integer type;

    /** 是否管理员**/
    private boolean isAdmin;
    /** 菜单权限编号**/
    private Collection<String> menuCodes;
    /** 操作权限编号**/
    private Collection<String> operateCodes;

    /**
     * logo图片 base64编码
     */
    private String logo;

    /**
     * logo旁边的标题
     */
    private String title;

    /**
     * 皮肤主题
     */
    private String skin = "0";

    /**
     * 播放方式（0：h5播放 1：播放器插件）
     */
    private Integer playStyle;
}
