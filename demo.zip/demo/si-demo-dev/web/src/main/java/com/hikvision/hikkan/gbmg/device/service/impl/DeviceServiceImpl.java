package com.hikvision.hikkan.gbmg.device.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.hikvision.hikkan.gbmg.base.service.BaseService;
import com.hikvision.hikkan.gbmg.common.util.hikvision.HikkanApiUrl;
import com.hikvision.hikkan.gbmg.common.util.hikvision.HikkanUtil;
import com.hikvision.hikkan.gbmg.device.dto.DeviceInfoPage;
import com.hikvision.hikkan.gbmg.device.dto.DeviceInfoVo;
import com.hikvision.hikkan.gbmg.device.service.DeviceService;
import com.hikvision.hikkan.gbmg.garbagepoint.domain.GarbageDeviceMapPO;
import com.hikvision.hikkan.gbmg.garbagepoint.repository.GarbageDeviceMapDao;
import com.hikvision.hikkan.gbmg.monitor.dto.MonitorInfoVo;
import com.hikvision.hikkan.kcommon.bean.ObjectResult;
import com.hikvision.hikkan.kcommon.bean.PageData;
import com.hikvision.hikkan.kcommon.enums.ServerCodeEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

/**
 * 接收消息业务层
 *
 * @author renjie
 * @version 1.0.0
 */
@Service
public class DeviceServiceImpl extends BaseService implements DeviceService {
    private Logger log = LoggerFactory.getLogger(DeviceServiceImpl.class);

    @Autowired
    GarbageDeviceMapDao garbageDeviceMapDao;
    /**
     * 分页获取nb设备
     * @return
     */
    @Override
    public ObjectResult devicePage(DeviceInfoPage deviceInfoPage) {
        String deviceInfoPageJson = JSONObject.toJSONString(deviceInfoPage);
        String result = HikkanUtil.httpPost(HikkanApiUrl.DEVICE_PAGE, deviceInfoPageJson, cacheArtemisToken());

        //对监控点进行过滤
        ObjectResult<PageData<DeviceInfoVo>> listObjectResult = JSONObject.parseObject(result, new TypeReference<ObjectResult<PageData<DeviceInfoVo>>>() {
        });
        if(ServerCodeEnum.SUCCESS.getCode().equals(listObjectResult.getCode())){
            List<DeviceInfoVo> list = listObjectResult.getData().getList();
            for (DeviceInfoVo deviceInfoVo : list) {
                Long id = deviceInfoVo.getId();
                GarbageDeviceMapPO byDeviceId = garbageDeviceMapDao.findByDeviceId(id);
                if(!Objects.isNull(byDeviceId) && !byDeviceId.getGarbagePointId().equals(deviceInfoPage.getPointId())){
                    deviceInfoVo.setOccupiedByPoint(true);
                }
            }
        }
        return listObjectResult;
    }
}
