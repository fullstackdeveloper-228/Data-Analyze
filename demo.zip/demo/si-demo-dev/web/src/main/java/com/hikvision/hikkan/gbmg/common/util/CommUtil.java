package com.hikvision.hikkan.gbmg.common.util;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.hikvision.hikkan.kcommon.enums.ServerCodeEnum;
import com.hikvision.hikkan.gbmg.common.exception.DescribeException;
import com.hikvision.hikkan.gbmg.common.constant.StaticConstant;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static java.util.regex.Pattern.compile;

/**
 * 常用工具类
 *
 * @author renjie
 * @version 1.0.0
 */

public class CommUtil {

    private static final Log log = LogFactory.getLog(CommUtil.class);

    /**
     * 判断对象或对象数组中每一个对象是否为空: 只要存在空就返回true,都不为空才返回false
     * haveNullOrEmpt
     * @param
     * @return
     */
    public static boolean haveNullOrEmpty(Object... objs) {
        if (objs == null || objs.length == 0) {
            return true;
        }
        for (Object obj : objs) {
            if(objIsNull(obj)) {
                return true;
            }
        }
        return false;
    }

    public static boolean notHaveNullOrEmpty(Object... obj) {
        return !haveNullOrEmpty(obj);
    }

    public static boolean isNullOrEmpty(Object... objs) {
        if (objs == null || objs.length == 0) {
            return true;
        }
        for (Object obj : objs) {
            if(objIsNull(obj)) {
                return true;
            }
        }
        return false;
    }

    public static void checkStringLength(int length, String...str){
        for(String s : str){
            if(s.length() > length){
                throw new DescribeException(ServerCodeEnum.PARAM_TOO_LONG);
            }
        }
    }

    public static boolean isNotNullOrEmpty(Object... obj) {
        return !haveNullOrEmpty(obj);
    }

    public static boolean objIsNotNull(Object obj) {
        return !objIsNull(obj);
    }

    @SuppressWarnings("rawtypes")
    public static boolean objIsNull(Object obj) {
        if (obj == null) {
            return true;
        }
        if (obj instanceof CharSequence) {
            return ((CharSequence) obj).length() == 0;
        }
        if (obj instanceof Collection) {
            return ((Collection) obj).isEmpty();
        }
        if (obj instanceof Map) {
            return ((Map) obj).isEmpty();
        }
        if (obj.getClass().isArray()) {
            return Array.getLength(obj) == 0;
        }
        return false;
    }

    /**
     * 过滤字符串中不是数字的字符
     * @param str
     * @return
     */
    public static String checkStringNum(String str) {
        String regEx = "[^0-9]";
        Pattern p = compile(regEx);
        Matcher m = p.matcher(str);
        return m.replaceAll("").trim();
    }

    /**
     * 过滤字符串中所有特殊字符
     * @param str
     * @return
     */
    public static String checkFileName(String str) {
        String regEx = "[`~!@#$%^&*()+=|{}':;',\\[\\].<>/?~！@#￥%……&*（）——+|{}【】‘；：”“’。，、？]";
        Pattern p = compile(regEx);
        Matcher m = p.matcher(str);
        return m.replaceAll("").trim();
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    public static void printMap(Map map) {
        Iterator it = map.entrySet().iterator();
        while (it.hasNext()) {
            Entry<String, String> entry = (Entry<String, String>) it.next();
            Object key = entry.getKey();
            Object val = entry.getValue();
            System.out.println("#" + key + "#");
            System.out.println("*" + val + "*");
        }
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    public static void sortMap(Map map) {
        List<Entry<String, String>> infoIds = new ArrayList<Entry<String, String>>(map.entrySet());
        // 排序前
        for (int i = 0; i < infoIds.size(); i++) {
            String id = infoIds.get(i).toString();
            System.out.println(id);
        }
        // 排序
        Collections.sort(infoIds, new Comparator<Entry<String, String>>() {

            @Override
            public int compare(Entry<String, String> o1, Entry<String, String> o2) {
                return (Integer.parseInt(o1.getKey()) - Integer.parseInt(o2.getKey()));
            }
        });
        System.out.println("排序后");
        // 排序后
        for (int i = 0; i < infoIds.size(); i++) {
            String id = infoIds.get(i).toString();
            System.out.println(id);
        }
    }

    /**
     * 获取当前时间字符串，格式："yyyy-MM-dd"
     *
     * @return 时间字符串
     */
    public static String getCurrentDateString() {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Date curDate = new Date(System.currentTimeMillis()); // 获取当前时间
        return formatter.format(curDate);
    }

    /**
     * 获取当前时间字符串，格式："yyyy-MM-dd HH:mm:ss"
     *
     * @return 时间字符串
     */
    public static String getCurrentDatetimeString() {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date curDate = new Date(System.currentTimeMillis()); // 获取当前时间
        return formatter.format(curDate);
    }

    /**
     * 把unicode字符串转成中文字符
     * @param
     * @return
     */
    public static String ascii2native(String asciicode) {
        String[] asciis = asciicode.split("\\\\u");
        String nativeValue = asciis[0];
        try {
            for (int i = 1; i < asciis.length; i++) {
                String code = asciis[i];
                nativeValue += (char) Integer.parseInt(code.substring(0, 4), 16);
                if (code.length() > 4) {
                    nativeValue += code.substring(4, code.length());
                }
            }
        }
        catch (NumberFormatException e) {
            return asciicode;
        }
        return nativeValue;
    }

    /**
     * 把8859-1编码转换成UTF-8编码
     *
     * @param str
     * @return
     */
    public static String convertStringEncoding(String str) {
        try {
            return new String(str.getBytes("iso8859-1"), "UTF-8");
        }
        catch (UnsupportedEncodingException e) {
            log.error(e.getMessage(), e);
            return "Error";
        }
    }

    /**
     * 把UTF-8编码转换成8859-1编码
     *
     * @param str
     * @return
     */
    public static String convertStringDecoding(String str) {
        try {
            return new String(str.getBytes("UTF-8"), "iso8859-1");
        }
        catch (UnsupportedEncodingException e) {
            log.error(e.getMessage(), e);
            return "Error";
        }
    }

    public static String dateToStr(Object date) {
        if (date == null) {
            return "";
        }
        Date formatDate = new Date();
        if (date instanceof Date) {
            formatDate.setTime(((Date) date).getTime());
        }
        else if (date instanceof Calendar) {
            formatDate = ((Calendar) date).getTime();
        }
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        return format.format(formatDate);
    }

    public static String dateTimeToStr(Object date) {
        if (date == null) {
            return "";
        }
        Date formatDate = new Date();
        if (date instanceof Date) {
            formatDate.setTime(((Date) date).getTime());
        }
        else if (date instanceof Calendar) {
            formatDate = ((Calendar) date).getTime();
        }
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return format.format(formatDate);
    }

    public static Date strToDate(String date) {
        return strToDate(date, false);
    }

    /**
     * 将字符串格式时间转换为Date
     * @param date
     * @param isEnd 如果字符串格式为 yyyy-MM-dd HH:mm:ss，此参数无用。如果格式为yyyy-MM-dd，isEnd:true=补上“23:59:59”， isEnd:false=补上“00:00:00”
     * @return
     */
    public static Date strToDate(String date, boolean isEnd) {
        if (date == null) {
            return new Date(System.currentTimeMillis());
        }
        // 判断date 格式是否符合 yyyy-MM-dd HH:mm:ss
        if (date.indexOf(" ") == -1) {
            if (isEnd) {
                date += " 23:59:59";
            }
            else {
                date += " 00:00:00";
            }
        }
        else {// 判断 若date 为 yyyy-MM-dd 00:00:00
            if (isEnd) {
                int nIndex = date.indexOf(" ");
                date = date.substring(0, nIndex);
                date += " 23:59:59";
            }
        }

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            return format.parse(date);
        }
        catch (ParseException e) {
//			e.printStackTrace();
            log.error(e.getMessage(),e);
        }
        return new Date(System.currentTimeMillis());
    }

    /**
     * 列表转化为字符串
     * @param list
     * @param split
     * @return
     */
    public static String convertListToString(Collection<Integer> list, String split) {
        if (list == null || list.size() == 0) {
            return null;
        }
        int nCount = 0;
        StringBuffer ids = new StringBuffer();
        for (Integer id : list) {
            ids.append(id);
            nCount++;
            if (nCount != list.size()) {
                ids.append(split);
            }
        }
        return ids.toString();
    }

    public static <T> String collectionToString(Collection<T> list, String split) {
        if (list == null || list.size() == 0) {
            return null;
        }
        int nCount = 0;
        StringBuffer obj = new StringBuffer();
        for (T t : list) {
            obj.append(t);
            nCount++;
            if (nCount != list.size()) {
                obj.append(split);
            }
        }
        return obj.toString();
    }

    /**
     * 将整数集组成的字符串还原为整数列表
     * @author shanguoming 2011-11-22 下午05:18:15
     * @param str
     * @param
     * @return
     */
    public static List<Integer> splitIntStr(String str) {
        return convertStringToList(str, ",");
    }

    /**
     * 将整数集组成的字符串还原为整数列表
     * @author liupengzhen5
     * @param str
     * @param split
     * @return
     */
    public static List<Integer> convertStringToList(String str, String split) {
        List<Integer> list = new ArrayList<Integer>();
        if (!haveNullOrEmpty(str)) {
            String[] array = str.split(split);
            for (String intStr : array) {
                intStr = intStr.trim();
                if (!haveNullOrEmpty(intStr)) {
                    list.add(Integer.parseInt(intStr));
                }
            }
        }
        return list;
    }

    /**
     * 数组转化为字符串
     * @param list
     * @param split
     * @return
     */
    public static String convertArrayToString(int[] list, String split) {
        if (list == null || list.length == 0) {
            return null;
        }
        int nCount = 0;
        StringBuffer ids = new StringBuffer();
        for (Integer id : list) {
            ids.append(id);
            nCount++;
            if (nCount != list.length) {
                ids.append(split);
            }
        }
        return ids.toString();
    }

    /**
     * 获取对象的属性值
     * @author zhoufanglong 2011-8-22 上午09:09:08
     * @param object
     * @param name
     * @return
     */
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public static Object getObjectProperty(Object object, String name) {
        if (name == null || name.isEmpty()) {
            return null;
        }
        Class clazz = object.getClass();
        String methodName = "get" + name.substring(0, 1).toUpperCase() + name.substring(1);

        try {
            Method method = clazz.getMethod(methodName);
            if (method != null) {
                return method.invoke(object);
            }
        }
        catch (Exception ex) {
        }

        try {
            Field field = clazz.getField(name);
            if (field != null) {
                return field.get(object);
            }
        }
        catch (Exception ex) {
        }

        return null;
    }

    /**
     * 将对象的属性及值放入map
     * @author zhoufanglong 2011-8-22 上午09:09:26
     * @param object
     * @param names 以逗号(,)分隔的属性名
     * @return
     */
    @SuppressWarnings("rawtypes")
    public static Map getObjectMap(Object object, String names) {
        return getObjectMap(object, names.split(","));
    }

    /**
     * 将指定对象的属性及值放入map
     * @author zhoufanglong 2011-8-22 上午09:11:17
     * @param object
     * @param names 属性名数组
     * @return
     */
    @SuppressWarnings("rawtypes")
    public static Map getObjectMap(Object object, String[] names) {
        return getObjectMap(object, Arrays.asList(names));
    }

    /**
     * 将指定对象的属性及值放入map
     * @author zhoufanglong 2011-8-22 上午09:11:17
     * @param object
     * @param names 属性名列表
     * @return
     */
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public static Map getObjectMap(Object object, List<String> names) {
        Map map = new HashMap();
        for (String name : names) {
            Object value = getObjectProperty(object, name);
            if (value != null) {
                map.put(name, value);
            }
        }
        return map;
    }

    /**
     * 将列表转换为JSONArray
     * @author zhoufanglong 2011-9-21 下午07:27:37
     * @param list
     * @param names
     * @return
     */
    @SuppressWarnings("rawtypes")
    public static JSONArray convertList2JSONArray(Collection list, String names) {
        JSONArray array = new JSONArray();
        for (Object obj : list) {
            Map map = getObjectMap(obj, names);
            JSONObject json = new JSONObject();
            for (Object object : map.entrySet()) {
                Entry entry = (Entry) object;
                json.put((String) entry.getKey(), entry.getValue());
            }
            array.add(json);
        }
        return array;
    }

    public static Calendar strToCalendar(String date) {
        return strToCalendar(date, false);
    }

    /**
     * 将字符串格式时间转换为Calendar
     * @param date
     * @param isEnd 如果字符串格式为 yyyy-MM-dd HH:mm:ss，此参数无用。如果格式为yyyy-MM-dd，isEnd:true=补上“23:59:59”， isEnd:false=补上“00:00:00”
     * @return
     */
    public static Calendar strToCalendar(String date, boolean isEnd) {
        Calendar happenTime = null;
        if (!haveNullOrEmpty(date)) {
            date = date.replaceAll("T", " ");
            happenTime = Calendar.getInstance();
            happenTime.setTime(strToDate(date, isEnd));
        }
        return happenTime;
    }

    /**
     * 获取本机IP
     */
    public static String getLocalHostIP() {
        // List<String> res=new ArrayList<String>();
        Enumeration<NetworkInterface> netInterfaces;
        try {
            netInterfaces = NetworkInterface.getNetworkInterfaces();
            InetAddress ip = null;
            while (netInterfaces.hasMoreElements()) {
                NetworkInterface ni = (NetworkInterface) netInterfaces.nextElement();
                Enumeration<InetAddress> nii = ni.getInetAddresses();
                while (nii.hasMoreElements()) {
                    ip = (InetAddress) nii.nextElement();
                    if (ip.getHostAddress().indexOf(":") == -1) {
                        if (!"127.0.0.1".equals(ip.getHostAddress())) {
                            return ip.getHostAddress();
                        }
                    }
                }
            }
        }
        catch (Exception e) {
//			e.printStackTrace();
            log.error(e.getMessage(),e);
        }
        return "";
    }



    /**
     * oracle最大表达式数为1000的处理
     * @author zhangyang 2012-2-15 下午12:10:33
     * @param list
     * @param name
     * @return
     */
    @SuppressWarnings("rawtypes")
    public static String oracleInStatement(List list, String name) {
        StringBuffer sb = new StringBuffer();
        sb.append(name).append(" in (");

        for (int i = 0; i < list.size(); i++) {
            if (i != (list.size() - 1)) {
                if (i != 0 && ((i + 1) % 1000 == 0)) { // buffer中有1000个值
                    sb.append(list.get(i)).append(") or ").append(name).append(" in(");
                }
                else {
                    sb.append(list.get(i)).append(",");
                }
            }
            else {
                sb.append(list.get(i));
            }
        }
        sb.append(")");
        return sb.toString();
    }

    /**
     * 连接列表为字符串
     * @author zhoufanglong 2011-10-8 下午04:40:47
     * @param list
     * @return
     */
    @SuppressWarnings("rawtypes")
    public static String joinList(Collection list) {
        StringBuilder sb = new StringBuilder();
        for (Object obj : list) {
            sb.append(obj.toString()).append(",");
        }
        if (sb.length() > 0) {
            sb.deleteCharAt(sb.length() - 1);
        }
        return sb.toString();
    }

    /**
     * 解析整形，如果失败返回null
     *
     * @author zhoufanglong 2012-5-16 上午10:02:15
     * @param obj
     * @return
     */
    public static Integer parseInt(Object obj) {
        try {
            return Integer.parseInt(obj.toString());
        }
        catch (Exception ex) {
            // log.error(null, ex);
            return null;
        }
    }

    /**
     * 将字符串还原为字符串列表
     * @author liupengzhen5
     * @param str
     * @param split
     * @return
     */
    public static List<String> convertStringToStringList(String str, String split) {
        List<String> list = new ArrayList<String>();
        if (!haveNullOrEmpty(str)) {
            String[] array = str.split(split);
            for (String intStr : array) {
                intStr = intStr.trim();
                if (!haveNullOrEmpty(intStr)) {
                    list.add(intStr);
                }
            }
        }
        return list;
    }

    /**
     * 将字符串还原为字符串列表
     * @author liupengzhen5
     * @param str
     * @param split
     * @return
     */
    public static List<Long> convertStringToLongList(String str, String split) {
        List<Long> list = new ArrayList<Long>();
        if (!haveNullOrEmpty(str)) {
            String[] array = str.split(split);
            for (String intStr : array) {
                intStr = intStr.trim();
                if (!haveNullOrEmpty(intStr)) {
                    list.add(Long.parseLong(intStr));
                }
            }
        }
        return list;
    }

    /**
     * 返回监控点编号：设备序列号#通道号
     * @param deviceSerial
     * @param channum
     * @return
     */
    public static String createMonitorCode(String deviceSerial, Integer channum){
        return deviceSerial + StaticConstant.NUMBER_SIGN + channum;
    }

    /**
     * 生成组织编号
     * @return
     */
    public static String createDeviceOrgCode(){
        String time = new Date().getTime() + "";
        String random = 100 + (int) (Math.random() * 900) + "";
        String orgCode = time + random;
        return orgCode;
    }

    /**
     * map转对象
     * @param type
     * @param map
     * @return
     * @throws IntrospectionException
     * @throws IllegalAccessException
     * @throws InstantiationException
     * @throws InvocationTargetException
     */
    public static Object convertMap(Class type, Map map){
        BeanInfo beanInfo = null; // 获取类属性
        Object obj = null; // 创建 JavaBean 对象
        try {
            beanInfo = Introspector.getBeanInfo(type);
            obj = type.newInstance();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }catch (IntrospectionException e) {
            e.printStackTrace();
        }

        // 给 JavaBean 对象的属性赋值
        PropertyDescriptor[] propertyDescriptors = beanInfo
                .getPropertyDescriptors();
        for (int i = 0; i < propertyDescriptors.length; i++) {
            PropertyDescriptor descriptor = propertyDescriptors[i];
            String propertyName = descriptor.getName();

            if (map.containsKey(propertyName)) {
                // 下面一句可以 try 起来，这样当一个属性赋值失败的时候就不会影响其他属性赋值。
                Object value = map.get(propertyName);

                Object[] args = new Object[1];
                args[0] = value;
                try{
                    descriptor.getWriteMethod().invoke(obj, args);
                }catch(Exception e){
                    throw new DescribeException("参数" + propertyName + "格式错误","111");
                }
            }
        }
        return obj;
    }


}
