package com.hikvision.hikkan.gbmg.login.dto;

import com.hikvision.hikkan.kcommon.constant.HikkanConstants;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

/**
 * Created by liuning9
 * 2019/7/16 14:16
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class VerifyCodeDTO {

    @NotEmpty(message = "name不能为空")
    @ApiModelProperty(value = "账号")
    @Pattern(regexp = HikkanConstants.SPECIAL_CHARACTER_PATTERN, message = "name不能有特殊字符")
    @Length(max = 32, message = "参数name长度不能大于32位")
    private String name;

    @ApiModelProperty(value = "productCode", allowEmptyValue = true)
    @Pattern(regexp = HikkanConstants.SPECIAL_CHARACTER_PATTERN, message = "productCode不能有特殊字符")
    @Length(max = 32, message = "参数productCode长度不能大于32位")
    private String productCode;
}
