package com.hikvision.hikkan.gbmg.device.dto;

import com.hikvision.hikkan.gbmg.base.dto.PageBaseDto;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * 设备分页查询
 *
 * @author renjie
 * @version 1.0.0
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DeviceInfoPage extends PageBaseDto {

    @ApiModelProperty(value = "是否包含所有子节点",allowEmptyValue = true)
    private boolean containAllChildren;

    @NotNull(message = "参数deviceOrgId不能为空")
    @ApiModelProperty(value = "设备组织id")
    private Long deviceOrgId;

    @ApiModelProperty(value = "设备类型",allowEmptyValue = true, hidden = true)
    private String deviceKind;

    @ApiModelProperty(value = "设备名称或序列号",allowEmptyValue = true)
    private String deviceNameOrSerial;

    @ApiModelProperty(value = "垃圾点位id",allowEmptyValue = true)
    private Long pointId;
}
