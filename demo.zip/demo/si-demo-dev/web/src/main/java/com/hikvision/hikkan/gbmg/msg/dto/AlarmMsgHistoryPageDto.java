package com.hikvision.hikkan.gbmg.msg.dto;

import com.hikvision.hikkan.gbmg.base.dto.PageBaseDto;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

/**
 * 消息历史记录分页查询
 *
 * @author renjie
 * @version 1.0.0
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class AlarmMsgHistoryPageDto extends PageBaseDto {


    @ApiModelProperty(value = "进报警时间 格式：yyyy-MM-dd'T'HH:mm:ss.SSS+08:00",allowEmptyValue = true)
    private Date enterAlarmTime;

    @ApiModelProperty(value = "出报警时间 格式：yyyy-MM-dd'T'HH:mm:ss.SSS+08:00",allowEmptyValue = true)
    private Date exitAlarmTime;

//    @ApiModelProperty(value = "设备序列号",allowEmptyValue = true)
//    private String devSerial;
//
//    @ApiModelProperty(value = "通道名称",allowEmptyValue = true)
//    private String channelName;

    @ApiModelProperty(value = "关键字查询：通道名称/设备序列号",allowEmptyValue = true)
    private String keyWord;

}
