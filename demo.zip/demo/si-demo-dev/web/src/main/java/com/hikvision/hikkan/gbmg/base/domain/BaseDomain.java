package com.hikvision.hikkan.gbmg.base.domain;


import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.hikvision.hikkan.gbmg.base.Base;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.MappedSuperclass;
import java.io.Serializable;
import java.util.Date;

/**
 * 实体类基类
 *
 * @author renjie
 * @version 1.0.0
 */
@MappedSuperclass
@Data
@EqualsAndHashCode(callSuper = true)
public class BaseDomain  extends Base implements Serializable {

	private static final long serialVersionUID = -5286002360844471931L;

	/**
	 * 创建时间
	 */
	//@ApiModelProperty(value="创建时间",hidden = true)
	private Date createTime = new Date();
	/**
	 * 更新时间
	 */
	//@ApiModelProperty(value="更新时间",hidden = true)
	private Date updateTime;
	/**
	 * 创建者id
	 */
	//@ApiModelProperty(value="创建者id",hidden = true)
	private Long createrId = super.getUserId();

	/**
	 * 操作者id
	 */
	//@ApiModelProperty(value="操作者id",hidden = true)
	private Long operatorId;


	@JsonSerialize(using = ToStringSerializer.class)
	public void setCreaterId(Long createrId) {
		this.createrId = createrId;
	}


	@JsonSerialize(using = ToStringSerializer.class)
	public void setOperatorId(Long operatorId) {
		this.operatorId = operatorId;
	}

}
