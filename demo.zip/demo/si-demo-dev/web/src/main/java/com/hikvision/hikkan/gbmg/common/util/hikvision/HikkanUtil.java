package com.hikvision.hikkan.gbmg.common.util.hikvision;

import com.hikvision.hikkan.gbmg.base.service.BaseService;
import com.hikvision.hikkan.gbmg.common.context.AuthContext;
import com.hikvision.hikkan.gbmg.common.exception.DescribeException;
import com.hikvision.hikkan.kcommon.enums.ServerCodeEnum;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import javax.net.ssl.*;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.HashMap;

/**
 * Created by liuning9
 * 2019/7/16 10:26
 */
@Slf4j
public class HikkanUtil {

    private static void print(String url, String param){
        log.info("request url: " + url);
        log.info("request param: " + param);
    }

    public static String httpPostWithToken(String url, String params, String cacheArtemisToken, String token){
        try{
            print(url, params);
            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, new TrustManager[]{new TrustAnyTrustManager()}, new java.security.SecureRandom());
            URL console = new URL(url);
            int timeout = 20 * 1000;
            HttpsURLConnection conn = (HttpsURLConnection) console.openConnection();
            conn.setSSLSocketFactory(sc.getSocketFactory());
            conn.setHostnameVerifier(new TrustAnyHostnameVerifier());
            conn.setReadTimeout(timeout);
            if (StringUtils.isNotBlank(cacheArtemisToken)) {
                conn.setRequestProperty("access_token", cacheArtemisToken);
                log.info("token信息:{}",token);
                conn.setRequestProperty("Authorization", token);
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            }
            conn.setConnectTimeout(timeout);
            conn.setDoOutput(true);
            conn.connect();
            DataOutputStream out = new DataOutputStream(conn.getOutputStream());
            if(StringUtils.isNotBlank(params)) {
                out.write(params.getBytes("utf-8"));
            }
            // 刷新、关闭
            out.flush();
            out.close();
            InputStream in = conn.getInputStream();
            return readInputStream(in, "utf-8");
        }catch(Exception e){
            log.error("request to " + url + " error.", e);
            throw new DescribeException(ServerCodeEnum.SYSTEM_ERROR);
        }
    }

    /**
     * post方式请求服务器(https协议)
     * @param url
     * @param params
     * @return
     * @throws Exception
     */
    public static String httpPost(String url, String params, String cacheArtemisToken) {
        return httpPostWithToken(url,params,cacheArtemisToken,AuthContext.getToken());
    }


    /**
     * 从输入流中读取数据
     * @param inStream
     * @param encode
     * @return
     * @throws Exception
     */
    private static String readInputStream(InputStream inStream, String encode) throws Exception {
        ByteArrayOutputStream outStream = null;
        String str = null;
        try {
            outStream = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int len = 0;
            while ((len = inStream.read(buffer)) != -1) {
                outStream.write(buffer, 0, len);
            }
            str = new String(outStream.toByteArray(), encode);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            if (null != inStream) {
                inStream.close();
            }
            if (null != outStream) {
                outStream.close();
            }
        }
        return str;
    }

    private static class TrustAnyHostnameVerifier implements HostnameVerifier {

        public boolean verify(String hostname, SSLSession session) {
            return true;
        }
    }

    private static class TrustAnyTrustManager implements X509TrustManager {

        public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
        }

        public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
        }

        public X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[]{};
        }
    }

}
