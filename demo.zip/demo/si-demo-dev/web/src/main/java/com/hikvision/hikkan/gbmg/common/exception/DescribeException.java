package com.hikvision.hikkan.gbmg.common.exception;

import com.hikvision.hikkan.kcommon.enums.ServerCodeEnum;
import com.hikvision.hikkan.gbmg.common.constant.StaticConstant;

/**
 * 自定义错误信息类
 *
 * @author renjie
 * @version 1.0.0
 */
public class DescribeException extends RuntimeException{
    private String code;

    /**
     * 继承exception，加入错误状态值
     * @param exceptionEnum
     */
    public DescribeException(ServerCodeEnum serverCodeEnum) {
        super(serverCodeEnum.getMsg());
        this.code = serverCodeEnum.getCode() + "";
    }

    /**
     * 继承exception，加入错误状态值
     * @param exceptionEnum
     */
    public DescribeException(ServerCodeEnum serverCodeEnum,String appendMsg) {
        super(serverCodeEnum.getMsg() + StaticConstant.COLON + appendMsg);
        this.code = serverCodeEnum.getCode() + "";
    }

    /**
     * 自定义错误信息
     * @param message
     * @param code
     */
    public DescribeException(String message, String code) {
        super(message);
        this.code = code;
    }

    /**
     * 自定义错误信息
     * @param e
     */
    public DescribeException(Exception e){
        super(e.getMessage());
        this.code = ServerCodeEnum.SYSTEM_ERROR.getCode();
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
