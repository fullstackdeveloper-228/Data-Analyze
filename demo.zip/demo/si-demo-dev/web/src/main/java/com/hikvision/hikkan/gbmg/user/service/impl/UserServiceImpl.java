package com.hikvision.hikkan.gbmg.user.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.hikvision.hikkan.gbmg.base.service.BaseService;
import com.hikvision.hikkan.gbmg.common.util.hikvision.HikkanApiUrl;
import com.hikvision.hikkan.gbmg.common.util.hikvision.HikkanUtil;
import com.hikvision.hikkan.gbmg.user.vo.UserAuthsVO;
import com.hikvision.hikkan.gbmg.monitor.dto.YsRestrictedTokenDto;
import com.hikvision.hikkan.gbmg.user.dto.ChangePwdDTO;
import com.hikvision.hikkan.gbmg.user.dto.SavePwdDTO;
import com.hikvision.hikkan.gbmg.user.service.UserService;
import com.hikvision.hikkan.kcommon.bean.ObjectResult;
import com.hikvision.hikkan.kcommon.enums.ServerCodeEnum;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

/**
 * Created by liuning9
 * 2019/7/17 16:11
 */
@Service
public class UserServiceImpl extends BaseService implements UserService {

    /**
     * 获取当前登陆用户权限
     * @return
     */
    @Override
    public ObjectResult<UserAuthsVO> getAuths(){
        String result = HikkanUtil.httpPost(HikkanApiUrl.AUTHS, null, artemisToken());
        if(StringUtils.isBlank(result)){
            throw new RuntimeException("云曜开放接口获取当前登陆用户权限error");
        }
        ObjectResult<UserAuthsVO> vo = JSON.parseObject(result, ObjectResult.class);
        return vo;
    }

    /**
     * 修改密码
     * @param dto
     * @return
     */
    @Override
    public ObjectResult changePwd(ChangePwdDTO dto){
        if(dto == null){
            return ObjectResult.error(ServerCodeEnum.PARAM_ERROR.getMsg());
        }
        String source = JSONObject.toJSONString(dto);
        if(StringUtils.isBlank(source)){
            throw new RuntimeException("修改密码参数json转化异常");
        }
        String result = HikkanUtil.httpPost(HikkanApiUrl.CHANGE_PWD, source, artemisToken());
        if(StringUtils.isBlank(result)){
            throw new RuntimeException("云曜开放接口修改密码error");
        }
        return JSON.parseObject(result, ObjectResult.class);
    }

    /**
     * 保存密码
     * @param dto
     * @return
     */
    @Override
    public ObjectResult updatePwd(SavePwdDTO dto){
        if(dto == null){
            return ObjectResult.error(ServerCodeEnum.PARAM_ERROR.getMsg());
        }
        String source = JSONObject.toJSONString(dto);
        if(StringUtils.isBlank(source)){
            throw new RuntimeException("保存密码参数json转化异常");
        }
        String result = HikkanUtil.httpPost(HikkanApiUrl.UPDATE_PWD, source, artemisToken());
        if(StringUtils.isBlank(result)){
            throw new RuntimeException("云曜开放接口修改密码error");
        }
        return JSON.parseObject(result, ObjectResult.class);
    }

    /**
     * 获取萤石的限制级token
     * @param ysRestrictedToken
     * @return
     */
    @Override
    public ObjectResult restrictedTokenGet(YsRestrictedTokenDto ysRestrictedTokenDto)
    {
        String ysRestrictedTokenJson = JSONObject.toJSONString(ysRestrictedTokenDto);
        String result = HikkanUtil.httpPost(HikkanApiUrl.RESTRICTED_TOKEN_GET, ysRestrictedTokenJson, artemisToken());
        return JSONObject.parseObject(result,ObjectResult.class);
    }
}
