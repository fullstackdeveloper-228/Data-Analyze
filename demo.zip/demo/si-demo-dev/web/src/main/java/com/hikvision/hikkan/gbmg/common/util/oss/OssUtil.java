package com.hikvision.hikkan.gbmg.common.util.oss;

import com.aliyun.oss.OSSClient;
import com.aliyun.oss.model.*;
import com.hikvision.hikkan.gbmg.common.constant.StaticConstant;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URL;
import java.util.Date;
import java.util.List;

/**
 * oss封装类
 *
 * @author renjie
 * @version 1.0.0
 */
@Component
public class OssUtil {
    //log
    private final Logger LOG = LoggerFactory.getLogger(OssUtil.class);
    @Autowired
    OssProperties ossProperties;

    /**
     * 获取阿里云OSS客户端对象
     * */
    public OSSClient getOSSClient(){
        return new OSSClient(ossProperties.getOssaddress(),ossProperties.getAccessKeyId(), ossProperties.getAccessKeySecret());
    }
    /**
     * 新建Bucket  --Bucket权限:私有
     * @param bucketName bucket名称
     * @return true 新建Bucket成功
     * */
    public boolean createBucket(OSSClient client, String bucketName){
        Bucket bucket = client.createBucket(bucketName);
        return bucketName.equals(bucket.getName());
    }
    /**
     * 删除Bucket
     * @param bucketName bucket名称
     * */
    public void deleteBucket(OSSClient client, String bucketName){
        client.deleteBucket(bucketName);
    }
    /**
     * 向阿里云的OSS存储中存储文件  --file也可以用InputStream替代
     * @param client OSS客户端
     * @param file 上传文件
     * @return String 唯一MD5数字签名
     * */
    public String uploadObject2OSS(String path, File file) throws Exception {
        String resultStr = null;
        try {
            InputStream is = new FileInputStream(file);
            String fileName = path + "/" + file.getName();
            Long fileSize = file.length();
            //创建上传Object的Metadata
            ObjectMetadata metadata = new ObjectMetadata();
            metadata.setContentLength(is.available());
            metadata.setCacheControl("no-cache");
            metadata.setHeader("Pragma", "no-cache");
            metadata.setContentEncoding("utf-8");
            metadata.setContentType(getContentType(fileName));
            metadata.setContentDisposition("filename/filesize=" + fileName + "/" + fileSize + "Byte.");
            //上传文件
            PutObjectResult putResult = this.getOSSClient().putObject(ossProperties.getBucketName(), ossProperties.getFilePath() + fileName, is, metadata);
            //解析结果
            resultStr = putResult.getETag();
            //抓拍的图片设置成公共读
            if(StaticConstant.OSD_PATH_CAPTURE.equals(path)){
                this.getOSSClient().setObjectAcl(ossProperties.getBucketName(), ossProperties.getFilePath() + fileName, CannedAccessControlList.PublicRead);
                Date expiration = new Date(new Date().getTime() + 3600l * 1000 * 24 * 365 * 10);
                URL url = this.getOSSClient().generatePresignedUrl(ossProperties.getBucketName(), ossProperties.getFilePath() + fileName, expiration);
                resultStr = url.toString();
                String http = "http://";
                if(StringUtils.isNotEmpty(resultStr) && resultStr.startsWith(http)){
                    resultStr = resultStr.replace(http, "https://");
                }
            }
            is.close();
        } catch (Exception e) {
            LOG.error("上传阿里云OSS服务器异常." + e.getMessage(), e);
            throw e;
        }finally {
            file.delete();
        }
        return resultStr;
    }

    /**
     * 根据key获取OSS服务器上的文件输入流
     * @param client OSS客户端
     * @param bucketName bucket名称
     * @param diskName 文件路径
     * @param key Bucket下的文件的路径名+文件名
     */
    public InputStream getOSS2InputStream(OSSClient client, String bucketName, String filePath, String key){
        OSSObject ossObj = client.getObject(bucketName, filePath + key);
        return ossObj.getObjectContent();
    }

    /**
     * 根据key删除OSS服务器上的文件
     * @param client OSS客户端
     * @param bucketName bucket名称
     * @param diskName 文件路径
     * @param key Bucket下的文件的路径名+文件名
     */
    public void deleteFile(OSSClient client, String bucketName, String filePath, String key){
        client.deleteObject(bucketName, filePath+ key);
        LOG.info("删除" + bucketName + "下的文件" + filePath + key + "成功");
    }

    /**
     * 批量删除文件
     * @param filePath
     */
    public void deleteFiles(String path, List<String> fileNames){
        String filePath = ossProperties.getFilePath();
        for(int i = 0 ; i < fileNames.size() ; i++ ){
            fileNames.set(i,filePath + path + "/" + fileNames.get(i));
        }
        DeleteObjectsResult deleteObjectsResult = this.getOSSClient().deleteObjects(new DeleteObjectsRequest(ossProperties.getBucketName()).withKeys(fileNames));
        List<String> deletedObjects = deleteObjectsResult.getDeletedObjects();
        LOG.info("删除文件成功:");
        LOG.info(deletedObjects.toString());
    }

    public InputStream getFileInputStream(String path, String fileName){
        OSSObject ossObject = this.getOSSClient().getObject(ossProperties.getBucketName(), ossProperties.getFilePath() + path + "/" + fileName);
        InputStream objectContent = ossObject.getObjectContent();
        return objectContent;
    }

    public void downloadFile(String path, String fileName, HttpServletResponse httpServletResponse){
        httpServletResponse.setContentType("application/octet-stream");// 设置强制下载不打开
        httpServletResponse.addHeader("Content-Disposition", "attachment;filename=" +fileName);
        // ossObject包含文件所在的存储空间名称、文件名称、文件元信息以及一个输入流。
        OSSObject ossObject = this.getOSSClient().getObject(ossProperties.getBucketName(), ossProperties.getFilePath() + path + "/" + fileName);
        InputStream inputStream = null;
        BufferedOutputStream outputStream = null;
        try {
            inputStream = ossObject.getObjectContent();
            outputStream = new BufferedOutputStream(httpServletResponse.getOutputStream());
            // 读取文件内容。
            byte[] car = new byte[1024];
            int L;
            while((L = inputStream.read(car)) != -1){
                if (car.length!=0){
                    outputStream.write(car, 0,L);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            // 数据读取完成后，获取的流必须关闭，否则会造成连接泄漏，导致请求无连接可用，程序无法正常工作。
            try {
                outputStream.flush();
                outputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 通过文件名判断并获取OSS服务文件上传时文件的contentType
     * @param fileName 文件名
     * @return 文件的contentType
     */
    public final String getContentType(String fileName){
        String fileExtension = fileName.substring(fileName.lastIndexOf(".")+1);
        if("bmp".equalsIgnoreCase(fileExtension)) return "image/bmp";
        if("gif".equalsIgnoreCase(fileExtension)) return "image/gif";
        if("jpeg".equalsIgnoreCase(fileExtension) || "jpg".equalsIgnoreCase(fileExtension)  ) return "image/jpeg";
        if("png".equalsIgnoreCase(fileExtension)) return "image/png";
        if("html".equalsIgnoreCase(fileExtension)) return "text/html";
        if("txt".equalsIgnoreCase(fileExtension)) return "text/plain";
        if("vsd".equalsIgnoreCase(fileExtension)) return "application/vnd.visio";
        if("ppt".equalsIgnoreCase(fileExtension) || "pptx".equalsIgnoreCase(fileExtension)) return "application/vnd.ms-powerpoint";
        if("doc".equalsIgnoreCase(fileExtension) || "docx".equalsIgnoreCase(fileExtension)) return "application/msword";
        if("xml".equalsIgnoreCase(fileExtension)) return "text/xml";
        return "text/html";
    }

    /**
     * 销毁
     */
    public void destory(OSSClient client) {
        client.shutdown();
    }



}
