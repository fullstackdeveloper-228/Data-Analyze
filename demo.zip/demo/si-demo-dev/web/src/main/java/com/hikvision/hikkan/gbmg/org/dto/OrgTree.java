package com.hikvision.hikkan.gbmg.org.dto;

import com.hikvision.hikkan.gbmg.common.util.CommUtil;
import org.springframework.beans.BeanUtils;

import java.util.List;

/**
 * 返回消息树
 *
 * @author renjie
 * @version 1.0.0
 */
public class OrgTree extends DeviceOrgDto {

    /**
     * 是否是根节点
     */
    private boolean isRoot;
    /**
     * 节点名称
     */
    private String label;

    /**
     * 子节点集合
     */
    private List<OrgTree> children;

    public OrgTree(DeviceOrgDto deviceOrgDto) {
        if(CommUtil.isNullOrEmpty(deviceOrgDto)){
            new OrgTree();
            return;
        }
        BeanUtils.copyProperties(deviceOrgDto,this);
    }

    public OrgTree() {

    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public List<OrgTree> getChildren() {
        return children;
    }

    public void setChildren(List<OrgTree> children) {
        this.children = children;
    }

    public boolean isRoot() {
        return isRoot;
    }

    public void setRoot(boolean root) {
        isRoot = root;
    }
}
