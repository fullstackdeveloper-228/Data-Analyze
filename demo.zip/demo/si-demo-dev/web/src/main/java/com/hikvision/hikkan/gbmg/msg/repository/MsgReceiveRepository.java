package com.hikvision.hikkan.gbmg.msg.repository;

import com.hikvision.hikkan.gbmg.msg.domain.AlarmMsgHistory;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Date;
import java.util.List;


/**
 * 消息历史记录数据层
 *
 * @author renjie
 * @version 1.0.0
 */
public interface MsgReceiveRepository extends JpaRepository<AlarmMsgHistory, Long> {


    List<AlarmMsgHistory> findByAlarmTypeAndDevSerialAndChannelAndAlarmTimeAfterAndExitAlarmIdIsNullOrderByAlarmTime(String alarmType,String deviceSerial, Integer channel,  Date alarmTime);

}
