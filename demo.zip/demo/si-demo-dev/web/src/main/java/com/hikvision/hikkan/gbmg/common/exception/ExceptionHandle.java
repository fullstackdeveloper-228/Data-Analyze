package com.hikvision.hikkan.gbmg.common.exception;

import com.hikvision.hikkan.kcommon.bean.ObjectResult;
import com.hikvision.hikkan.kcommon.enums.ServerCodeEnum;
import com.hikvision.hikkan.kcommon.util.CommonUtil;
import com.hikvision.hikkan.gbmg.common.util.ResultUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 异常信息处理类
 *
 * @author renjie
 * @version 1.0.0
 */
@ControllerAdvice
public class ExceptionHandle {
    private final static Logger log = LoggerFactory.getLogger(ExceptionHandle.class);

    /**
     * 判断错误是否是已定义的已知错误，不是则由未知错误代替，同时记录在log中
     * @param e
     * @return
     */
    @ExceptionHandler(value = Exception.class)
    @ResponseBody
    public ObjectResult exceptionGet(Exception e){
        log.error(e.getMessage(),e);
        if(e instanceof DescribeException){
            DescribeException MyException = (DescribeException) e;
            return ResultUtil.error(MyException.getCode(),MyException.getMessage());
        }else if(e instanceof com.hikvision.hikkan.kcommon.bean.exception.DescribeException){
            com.hikvision.hikkan.kcommon.bean.exception.DescribeException MyException = (com.hikvision.hikkan.kcommon.bean.exception.DescribeException) e;
            return ResultUtil.error(MyException.getCode(),MyException.getMessage());
        }else if(e instanceof HttpMessageNotReadableException){
            return CommonUtil.catchException(e);
        }

        log.error("【系统异常】{}",e);
        return ResultUtil.error(ServerCodeEnum.SYSTEM_ERROR);
    }
}
