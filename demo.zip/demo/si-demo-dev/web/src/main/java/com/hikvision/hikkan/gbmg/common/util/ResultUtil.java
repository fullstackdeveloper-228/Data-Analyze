package com.hikvision.hikkan.gbmg.common.util;

import com.hikvision.hikkan.kcommon.bean.ObjectResult;
import com.hikvision.hikkan.kcommon.enums.ServerCodeEnum;

/**
 *  返回结果处理工具类
 *
 * @author renjie
 * @version 1.0.0
 */
public class ResultUtil {
    /**
     * 返回成功，传入返回体具体出參
     * @param object
     * @return
     */
    public static ObjectResult success(Object data){
        return ObjectResult.success(data);
    }

    /**
     * 提供给部分不需要出參的接口
     * @return
     */
    public static ObjectResult success(){
        return success(null);
    }

    /**
     * 提供给部分不需要出參的接口
     * @return
     */
    public static ObjectResult error(){
        return ObjectResult.ERROR;
    }

    /**
     * 自定义错误信息
     * @param code
     * @param msg
     * @return
     */
    public static ObjectResult error(String code, String msg){
        ObjectResult result = new ObjectResult();
        result.setCode(code);
        result.setMsg(msg);
        result.setData(null);
        return result;
    }

    /**
     * 返回异常信息，在已知的范围内
     * @param exceptionEnum
     * @return
     */
    public static ObjectResult error(ServerCodeEnum serverCodeEnum){
        ObjectResult result = new ObjectResult();
        result.setCode(serverCodeEnum.getCode());
        result.setMsg(serverCodeEnum.getMsg());
        result.setData(null);
        return result;
    }
}
