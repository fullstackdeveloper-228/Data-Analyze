package com.hikvision.hikkan.gbmg.monitor.dto;

import cn.afterturn.easypoi.excel.annotation.Excel;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import lombok.Data;

import javax.persistence.Column;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 监控点信息扩展类
 *
 * @author renjie
 * @version 1.0.0
 */
@Data
public class MonitorInfoVo{

    /**
     * 在线状态 0不在线，1在线
     */
    private Integer onlineStatus;
    /**
     * 在线状态中文名
     */
    private String onlineStatusStr;

    /**
     * 分配状态 未分配：0  已分配：1
     */
    private Integer allocationStatus;
    /**
     * 分配状态中文
     */
    @Excel(name = "分配状态", orderNum = "5")
    private String allocationStatusStr;

    /**
     * 设备名称
     */
    private String deviceName;

    /**
     * 设备型号
     */
    private String model;

    /**
     * 设备类型中文
     */
    private String modelTypeStr;

    /**
     * 组织名称
     */
    @Excel(name = "所属组织", orderNum = "5")
    private String deviceOrgName;
    /**
     * 分配状态
     */
    Map<String, Integer> allocationStatusMap;
    /**
     * 清晰度
     */
    private Integer videoLevel;
    /**
     * 封面
     */
    private String url;
    /**
     * 是否加密，0：不加密，1：加密
     */
    private Integer isencrypt;



    /**
     * (do)组织id列表（分页查询时包含下级的情况）
     */
    private List<Long> deviceOrgIdList;

    /**
     * (do)给web端页面模糊搜索查询用
     */
    private String nameOrSerialOrDeviceName;

    /**
     * (do)是否包括所有子组织
     */
    private boolean containAllChildren;

    /**
     * (do)设备状态 0停用，1启用
     */
    private Integer openStatus;

    /**
     * 是否查询预览记录
     */
    private boolean previewRecord;

    /**
     * 设备验证码
     */
    private String validateCode;
    /**
     * (do)监控点code列表，分页查询用
     */
    private List<String> monitorCodeList;

    private Long id;

    /**
     * 设备序列号
     */
    private String monitorSerial;

    /**
     * 通道号
     */
    private Integer channum;

    /**
     * 监控点编号
     */
    private String monitorCode;

    /**
     * 通道名称
     */
    private String monitorName;

    /**
     * osd信息
     */
    private String osdName;

    /**
     * 预览时间
     */
    private Date previewTime;


    @JsonSerialize(using = ToStringSerializer.class)
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 更新时间
     */
    private Date updateTime;
    /**
     * 创建者id
     */
    private Long createrId;

    /**
     * 操作者id
     */
    private Long operatorId;

    /**
     * 被垃圾点位占用
     */
    private boolean occupiedByPoint;
    public MonitorInfoVo(){

    }
}
