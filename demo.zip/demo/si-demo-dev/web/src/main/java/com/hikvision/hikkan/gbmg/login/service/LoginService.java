package com.hikvision.hikkan.gbmg.login.service;

import com.hikvision.hikkan.gbmg.login.dto.*;
import com.hikvision.hikkan.gbmg.login.vo.ChallengeCodeVO;
import com.hikvision.hikkan.gbmg.login.vo.LoginVO;
import com.hikvision.hikkan.gbmg.login.vo.PhoneVerifyCodeVO;
import com.hikvision.hikkan.kcommon.bean.ObjectResult;

/**
 * Created by liuning9
 * 2019/7/16 10:17
 */
public interface LoginService {

    /**
     * 获取挑战码
     * @param dto
     * @return
     * @throws Exception
     */
    ObjectResult<ChallengeCodeVO> getChallengeCode(ChallengeRequestCodeDTO dto);

    /**
     * 登陆
     * @param dto
     * @return
     * @throws Exception
     */
    ObjectResult<LoginVO> login(LoginDTO dto);

    /**
     * 登出
     * @return
     */
    ObjectResult logout();

    /**
     * 活动检测
     * @param dto
     * @return
     */
    ObjectResult verifyCode(VerifyCodeDTO dto) ;

    /**
     * 获取手机验证码
     * @param dto
     * @return
     */
    ObjectResult<PhoneVerifyCodeVO> phoneVerifyCode(PhoneVerifyCodeDTO dto);

    /**
     * 校验手机验证码
     * @param dto
     * @return
     */
    ObjectResult<PhoneVerifyCodeVO> checkPhoneVerifyCode(CheckPhoneVerifyCodeDTO dto);

    /**
     * 获取手机认证状态
     * @param dto
     * @return
     */
    ObjectResult phoneStatus(PhoneSmsDTO dto);
}
