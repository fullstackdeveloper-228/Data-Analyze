package com.hikvision.hikkan.gbmg.user.dto;

import com.hikvision.hikkan.kcommon.constant.HikkanConstants;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

/**
 * Created by liuning9
 * 2019/7/17 19:12
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SavePwdDTO {

    @NotEmpty(message = "挑战码不能为空")
    @ApiModelProperty(value = "codeId")
    @Pattern(regexp = HikkanConstants.SPECIAL_CHARACTER_PATTERN, message = "codeId不能有特殊字符")
    @Length(max = 128, message = "参数codeId长度不能大于128位")
    private String codeId;

    @NotEmpty(message = "盐值不能为空")
    @ApiModelProperty(value = "salt")
    private String salt;

    @ApiModelProperty(value = "密码", allowEmptyValue = true)
    private String oldPwd;

    @NotEmpty(message = "newPwd不能为空")
    @ApiModelProperty(value = "密码", allowEmptyValue = true)
    private String newPwd;
}
