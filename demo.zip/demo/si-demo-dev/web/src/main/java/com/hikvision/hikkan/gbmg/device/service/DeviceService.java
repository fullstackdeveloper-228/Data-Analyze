package com.hikvision.hikkan.gbmg.device.service;

import com.hikvision.hikkan.gbmg.device.dto.DeviceInfoPage;
import com.hikvision.hikkan.kcommon.bean.ObjectResult;

public interface DeviceService {

    /**
     * 分页查询设备
     * @return
     */
    ObjectResult devicePage(DeviceInfoPage deviceInfoPage);

}
