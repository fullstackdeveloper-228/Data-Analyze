package com.hikvision.hikkan.gbmg.garbagepoint.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * 监控点查询
 *
 * @author liuning
 * @version 1.0.0
 */
@Data
public class GarbageFindByIdDTO {

    @NotNull(message = "参数id不能为空")
    @ApiModelProperty(value = "垃圾点id")
    private Long id;

}
