package com.hikvision.hikkan.gbmg.common.context;

/**
 * 用于存储用户token
 *
 * @author renjie
 * @version 1.0.0
 */
public class AuthContext {
    private static ThreadLocal<String> local = new ThreadLocal();

    public AuthContext() {
    }

    public static String getToken(){
       return local.get();
    }

    public static void setToken(String token) {
        local.set(token);
    }

    public static void clean() {
        if (local.get() != null) {
            local.set(null);
        }
    }

}
