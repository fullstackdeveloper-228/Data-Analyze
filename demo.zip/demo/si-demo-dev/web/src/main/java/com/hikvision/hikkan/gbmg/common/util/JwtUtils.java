package com.hikvision.hikkan.gbmg.common.util;

import com.alibaba.fastjson.JSON;
import com.hikvision.hikkan.kcommon.bean.login.JwtPayload;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;


/**
 * JWT 工具类
 *
 * @author heqian7
 * @version 1.0.0
 */
public class JwtUtils {

    /**
     * 5天
     */
    private static final long EXPIRATION_TIME = 432_000_000L;
    /**
     * JWT密码
     */
    private static final String SECRET = "P@ssw02d";
    /**
     * Token前缀
     */
    public static final String TOKEN_PREFIX = "Login_";
    /**
     * 存放Token的Header Key
     */
    public static final String HEADER_STRING = "Authorization";

    private static final String SEPARATOR = "_";

    /**
     * JWT生成方法
     */
    public static String addAuth(JwtPayload payload) {
        return Jwts.builder()
                //设置主题
                .setSubject(HEADER_STRING)
                .claim("payload", JSON.toJSONString(payload))
                // 有效期设置
                //.setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
                // 签名设置
                .signWith(SignatureAlgorithm.HS512, SECRET)
                .compact();
    }

    /**
     * JWT验证方法
     */
    public static Object getAuth(String token) {
        // 从Header中拿到token
        if (token != null) {
            // 解析 Token
            Claims claims = Jwts.parser()
                    // 验签
                    .setSigningKey(SECRET)
                    // 去掉 Bearer
                    .parseClaimsJws(token.replace(TOKEN_PREFIX, ""))
                    .getBody();
            return claims.get("payload");
        }
        return null;
    }

    /**
     * 获取jwt的key
     */
    public static String getAuthKey(JwtPayload payload, String jwt) {
        return getPrefixAuthKey(payload.getType(), payload.getUserName(), payload.getProductCode()) + jwt;
    }

    public static String getPrefixAuthKey(Integer type, String name, String productCode) {
        return TOKEN_PREFIX + type + SEPARATOR + name + SEPARATOR + productCode + SEPARATOR;
    }
}
