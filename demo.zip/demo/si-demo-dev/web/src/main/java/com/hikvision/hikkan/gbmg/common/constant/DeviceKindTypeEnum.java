package com.hikvision.hikkan.gbmg.common.constant;

/**
 * 设备类型枚举类
 *
 * @author renjie
 * @version 1.0.0
 */
public enum DeviceKindTypeEnum {

    /**
     * 门禁设备
     */
    ACCESS("门禁设备","ACCESS"),

    /**
     * NB设备
     */
    NB("NB设备","NB");


    private final String name;
    private final String value;


    DeviceKindTypeEnum(String name, String value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public String getValue() {
        return value;
    }

}
