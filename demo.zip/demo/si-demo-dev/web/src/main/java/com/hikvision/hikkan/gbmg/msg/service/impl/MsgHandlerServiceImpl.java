
package com.hikvision.hikkan.gbmg.msg.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.hikvision.hikkan.gbmg.base.service.BaseService;
import com.hikvision.hikkan.gbmg.common.constant.AlarmTypeEnum;
import com.hikvision.hikkan.gbmg.common.constant.StaticConstant;
import com.hikvision.hikkan.gbmg.common.util.CommUtil;
import com.hikvision.hikkan.gbmg.common.util.FileUtil;
import com.hikvision.hikkan.gbmg.common.util.hikvision.HikkanApiUrl;
import com.hikvision.hikkan.gbmg.common.util.hikvision.HikkanUtil;
import com.hikvision.hikkan.gbmg.common.util.oss.OssUtil;
import com.hikvision.hikkan.gbmg.config.RabbitConfig;
import com.hikvision.hikkan.gbmg.monitor.dto.MonitorGlobalByCodeDto;
import com.hikvision.hikkan.gbmg.monitor.dto.MonitorPageDto;
import com.hikvision.hikkan.gbmg.msg.domain.AlarmMsgHistory;
import com.hikvision.hikkan.gbmg.msg.dto.AlarmMsgReceiveDto;
import com.hikvision.hikkan.gbmg.msg.repository.MsgReceiveRepository;
import com.hikvision.hikkan.gbmg.msg.vo.AlarmMsgHistoryVo;
import com.hikvision.hikkan.kcommon.bean.ObjectResult;
import com.hikvision.hikkan.kcommon.bean.PageData;
import com.hikvision.hikkan.kcommon.enums.ServerCodeEnum;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;


/**
 * 消息消费者
 *
 * @author renjie
 * @version 1.0.0
 */

@Component
@RabbitListener(queues = RabbitConfig.QUEUE_ALARM)
public class MsgHandlerServiceImpl extends BaseService {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private MsgReceiveRepository msgReceiveRepository;
    @Autowired
    private OssUtil ossUtil;
    @Value("${gbmb.processTime:30}")
    private long processTime;


    @RabbitHandler
    public void process(String content) {
        //消息封装成对象
        List<AlarmMsgHistory> alarmMsgHistories = msgHandler(content);
        msgReceiveRepository.saveAll(alarmMsgHistories);
        logger.info("接收处理队列gbmg_alarm_queue中的消息： " + content);
    }



/**
     * 处理消息
     * @param content
     * @return
     */

    private List<AlarmMsgHistory> msgHandler(String content){
        AlarmMsgReceiveDto alarmMsgReceiveDto = JSON.parseObject(content, AlarmMsgReceiveDto.class);
        List<AlarmMsgReceiveDto.Body> body = alarmMsgReceiveDto.getBody();
        List<AlarmMsgHistory> alarmMsgHistoryList = new ArrayList<>();
        body.forEach(b -> {
            String alarmType = b.getAlarmType();
            //只捕获exitareadetection、enterareadetection类型的消息
            if(AlarmTypeEnum.exist(alarmType)){
                AlarmMsgHistory alarmMsgHistory = new AlarmMsgHistory();
                BeanUtils.copyProperties(b,alarmMsgHistory);
                //图片处理
                List<AlarmMsgReceiveDto.Picture> pictureList = b.getPictureList();
                if(!Objects.isNull(pictureList) && !pictureList.isEmpty()){
                    String url = pictureList.get(0).getUrl();
                    capturePicHandler(url,alarmMsgHistory);
                }
                //转换时间
                String alarmTime = b.getAlarmTime();
                if(StringUtils.isNotEmpty(alarmTime)){
                    try {
                        alarmMsgHistory.setAlarmTime(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").parse(alarmTime));
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                }
                //进出消息记录关联
                createProcessMsg(alarmMsgHistory);
                //只对enterareadetection类型的告警，进行相关联的监控点信息的获取
                if(AlarmTypeEnum.ENTERAREADETECTION.getValue().equals(alarmType)){
                    getMonitorInfo(alarmMsgHistory,alarmMsgReceiveDto.getProjectId());
                }
                alarmMsgHistoryList.add(alarmMsgHistory);

            }
        });
        return alarmMsgHistoryList;
    }


/**
     * 抓拍图片的处理
     * @param pictureUrl
     * @param alarmMsgHistory
     */

    private void capturePicHandler(String pictureUrl,AlarmMsgHistory alarmMsgHistory){
        //下载文件
        File file = FileUtil.downLoadFromUrl(pictureUrl);
        if(Objects.isNull(file)){
            return;
        }
        //生成缩略图
        File thumbnail = FileUtil.createThumbnail(file);
        //上传oss
        try {
            String fileUrl = ossUtil.uploadObject2OSS(StaticConstant.OSD_PATH_CAPTURE, file);
            String thumbnailUrl = ossUtil.uploadObject2OSS(StaticConstant.OSD_PATH_CAPTURE, thumbnail);
            alarmMsgHistory.setUrl(fileUrl);
            alarmMsgHistory.setThumbnailUrl(thumbnailUrl);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

/**
     * 消息关联
     * @param alarmMsgHistory
     */

    private void createProcessMsg(AlarmMsgHistory alarmMsgHistory) {
        String alarmType = alarmMsgHistory.getAlarmType();
        String devSerial = alarmMsgHistory.getDevSerial();
        Integer channel = alarmMsgHistory.getChannel();
        if (AlarmTypeEnum.EXITAREADETECTION.getValue().equals(alarmType)) {
            List<AlarmMsgHistory> alarmMsgHistoryList = msgReceiveRepository.findByAlarmTypeAndDevSerialAndChannelAndAlarmTimeAfterAndExitAlarmIdIsNullOrderByAlarmTime(
                    AlarmTypeEnum.ENTERAREADETECTION.getValue(),
                    devSerial,
                    channel,
                    new Date(alarmMsgHistory.getAlarmTime().getTime() - processTime * 1000));
            if (alarmMsgHistoryList.isEmpty()) {
                alarmMsgHistoryList = msgReceiveRepository.findByAlarmTypeAndDevSerialAndChannelAndAlarmTimeAfterAndExitAlarmIdIsNullOrderByAlarmTime(
                        AlarmTypeEnum.ENTERAREADETECTION.getValue(),
                        devSerial,
                        channel,
                        new Date(alarmMsgHistory.getAlarmTime().getTime() - processTime * 1000 * 2));
            }
            if (!alarmMsgHistoryList.isEmpty()) {
                AlarmMsgHistory alarmMsgHistory_ = alarmMsgHistoryList.get(0);
                alarmMsgHistory_.setExitAlarmId(alarmMsgHistory.getId());
                msgReceiveRepository.save(alarmMsgHistory_);
            }
        }
    }

    /**
     * 获取告警消息相关联的监控点信息
     * @param alarmMsgHistory
     */
    private void getMonitorInfo(AlarmMsgHistory alarmMsgHistory, String projectId){
        MonitorGlobalByCodeDto monitorGlobalByCodeDto = new MonitorGlobalByCodeDto();

        monitorGlobalByCodeDto.setMonitorCode(CommUtil.createMonitorCode(alarmMsgHistory.getDevSerial(), alarmMsgHistory.getChannel()));
        monitorGlobalByCodeDto.setProjectId(Long.parseLong(projectId));
        String s = HikkanUtil.httpPostWithToken(HikkanApiUrl.MONITOR_BY_CODE, JSONObject.toJSONString(monitorGlobalByCodeDto), cacheArtemisToken(), globalToken());
        ObjectResult<AlarmMsgHistoryVo> result = JSONObject.parseObject(s, new TypeReference<ObjectResult<AlarmMsgHistoryVo>>() {
        });
        if(!Objects.isNull(result)){
            if(ServerCodeEnum.SUCCESS.getCode().equals(result.getCode())){
                AlarmMsgHistoryVo alarmMsgHistoryVo = result.getData();
                if(!Objects.isNull(alarmMsgHistoryVo)){
                    alarmMsgHistory.setChannelName(alarmMsgHistoryVo.getMonitorName());
                    alarmMsgHistory.setDeviceName(alarmMsgHistoryVo.getDeviceName());
                    alarmMsgHistory.setMonitorId(alarmMsgHistoryVo.getId());
                }
            }
        }
    }
}

