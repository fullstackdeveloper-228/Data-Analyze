package com.hikvision.hikkan.gbmg.user.dto;

import com.hikvision.hikkan.kcommon.constant.HikkanConstants;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/**
 * Created by liuning9
 * 2019/7/17 18:41
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ChangePwdDTO {

    @ApiModelProperty(value = "productCode", allowEmptyValue = true)
    @Pattern(regexp = HikkanConstants.SPECIAL_CHARACTER_PATTERN, message = "productCode不能有特殊字符")
    @Length(max = 32, message = "参数productCode长度不能大于16位")
    public String productCode;

    @NotNull(message = "type不能为空")
    @ApiModelProperty(value = "账号类型： 0 ：个人用户  1：租户用户  2: 系统用户")
    private Integer type;

    @NotEmpty(message = "校验码")
    @ApiModelProperty(value = "verifyCodeId", allowEmptyValue = true)
    @Pattern(regexp = HikkanConstants.SPECIAL_CHARACTER_PATTERN, message = "verifyCodeId不能有特殊字符")
    @Length(max = 128, message = "参数verifyCodeId长度不能大于128位")
    private String verifyCode;

    @NotEmpty(message = "password不能为空")
    @ApiModelProperty(value = "密码")
    @Length(max = 128, message = "参数password长度不能大于128位")
    private String password;

    @NotEmpty(message = "挑战码不能为空")
    @ApiModelProperty(value = "codeId")
    @Pattern(regexp = HikkanConstants.SPECIAL_CHARACTER_PATTERN, message = "codeId不能有特殊字符")
    @Length(max = 128, message = "参数codeId长度不能大于128位")
    private String codeId;

    @NotEmpty(message = "盐值不能为空")
    @ApiModelProperty(value = "salt")
    private String salt;
}
