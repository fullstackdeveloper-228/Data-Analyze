package com.hikvision.hikkan.gbmg.monitor.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/**
 * 获取播放xml
 *
 * @author renjie
 * @version 1.4.0
 */
@Data
public class MonitorGetPlayXmlDto {

    @NotNull(message = "参数monitorId不能为空")
    @ApiModelProperty(value = "监控点id")
    private Long monitorId;

    @NotEmpty(message = "参数playType不能为空")
    @Pattern(regexp = "^((Preview){1,1}|(PlayBack){1,1})$", message = "参数playType格式不正确")
    @ApiModelProperty(value = "播放类型，预览：Preview  回放：PlayBack")
    private String playType;

    @NotNull(message = "参数msgId不能为空")
    @ApiModelProperty(value = "历史消息id")
    private Long msgHistoryId;

    @ApiModelProperty(hidden = true)
    private Long id;

    public void setMonitorId(Long monitorId) {
        this.monitorId = monitorId;
        this.id = monitorId;
    }
}
