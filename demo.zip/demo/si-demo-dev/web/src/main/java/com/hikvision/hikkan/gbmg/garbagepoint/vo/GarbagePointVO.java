package com.hikvision.hikkan.gbmg.garbagepoint.vo;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.hikvision.hikkan.kcommon.constant.HikkanConstants;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.util.List;

/**
 * Created by liuning9
 * 2019/7/24 9:44
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class GarbagePointVO extends GarbagePointPageVO{

    /**
     * 监控点ids
     */
    private List<String> monitorList;

    /**
     * NB设备ids
     */
    private List<String> nbDeviceList;

}
