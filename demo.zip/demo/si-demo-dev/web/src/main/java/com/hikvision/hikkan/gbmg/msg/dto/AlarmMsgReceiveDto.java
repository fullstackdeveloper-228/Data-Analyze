package com.hikvision.hikkan.gbmg.msg.dto;

import lombok.Data;

import java.util.List;

/**
 * 报警消息接收类
 *
 * @author renjie
 * @version 1.0.0
 */
@Data
public class AlarmMsgReceiveDto {

    /**
     * 消息类型   只接收ys.alarm类型的
     */
    private String subType;

    /**
     * 消息id   5d26bfbbb8894d9605d09bd0
     */
    private String messageId;

    /**
     * 项目id
     */
    private String projectId;

    /**
     * 消息体
     */
    private List<AlarmMsgReceiveDto.Body> body;

    @Data
    public static class Body{
        /**
         * 报警时间 2019-07-11T12:25:09
         */
        private String alarmTime;
        /**
         * 通道号
         */
        private Integer channel;
        /**
         * 设备序列号
         */
        private String devSerial;
        /**
         * 报警类型 只接收enterareadetection/exitareadetection类型
         */
        private String alarmType;
        /**
         * 报警id
         */
        private String alarmId;
        /**
         * 通道名称
         */
        private String channelName;
        /**
         * 图片
         */
        private List<Picture> pictureList;
    }

    @Data
    public static class Picture{
        /**
         * 图片url
         */
        private String url;
    }
}
