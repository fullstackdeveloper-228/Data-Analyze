package com.hikvision.hikkan.gbmg.garbagepoint.service;

import com.hikvision.hikkan.gbmg.garbagepoint.dto.GarbagePointDTO;
import com.hikvision.hikkan.gbmg.garbagepoint.dto.GarbagePointSearchDTO;
import com.hikvision.hikkan.gbmg.garbagepoint.vo.GarbagePointPageVO;
import com.hikvision.hikkan.gbmg.garbagepoint.vo.GarbagePointVO;
import com.hikvision.hikkan.kcommon.bean.ObjectResult;
import com.hikvision.hikkan.kcommon.bean.PageData;

import java.util.List;

/**
 * Created by liuning9
 * 2019/7/23 19:46
 */
public interface GarbagePointService {

    /**
     * 保存或修改垃圾点信息
     * @param dto
     * @return
     */
    ObjectResult saveOrUpdate(GarbagePointDTO dto);

    /**
     * 获取垃圾点详情
     * @param id
     * @return
     */
    ObjectResult<GarbagePointVO> findById(Long id);

    /**
     * 获取垃圾点列表信息
     * @param dto
     * @return
     */
    ObjectResult<PageData<GarbagePointPageVO>> page(GarbagePointSearchDTO dto);

    /**
     * 删除垃圾点信息
     * @param ids
     * @return
     */
    ObjectResult delete(List<Long> ids);
}
