package com.hikvision.hikkan.gbmg.device.dto;

import cn.afterturn.easypoi.excel.annotation.Excel;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiParam;
import lombok.Data;
import javax.persistence.Transient;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 设备
 *
 * @author renjie
 * @version 1.0.0
 */
@Data
public class DeviceInfoVo {

    private static final String deviceStatusStrMatch = "[a-zA-Z]+:-?\\d*(,[a-zA-Z]+:-?\\d*)*";

    /**
     * 设备组织名称
     */
    @Transient
    @Excel(name = "设备组织名称", orderNum = "6")
    private String deviceOrgName;


    /**
     * 设备类型Str
     */
    @Excel(name = "设备类型", orderNum = "7")
    private String modelTypeStr;

    /**
     * 是否勾选
     */
    @Transient
    private boolean selectable;

    /**
     * 在线状态
     */
    private Integer onlineStatus;
    @Excel(name = "在线状态", orderNum = "8")
    private String onlineStatusStr;


    /**
     * 启停状态
     */
    private Integer openStatus;
    @Excel(name = "启停状态", orderNum = "9")
    private String openStatusStr;


    /**
     * 智能检测
     */
    private Integer intelliVal;
    @Excel(name = "智能检测", orderNum = "10")
    private String intelliValStr;


    /**
     * 布撤防
     */
    private Integer defence;
    @Excel(name = "布撤防", orderNum = "11")
    private String defenceStr;


    /**
     *  设备存储类型  以二进制的形式展示，1表示有 0表示无  如：101  第一位：云存储；第二位：磁盘；第三位：硬盘
     */
    private String deviceStoreType;
    /**
     * 加密状态 0不加密， 1加密
     */
    private Integer isencrypt;
    /**
     * 升级状态 0正在升级，1设备重启，2升级成功，3升级失败，4等待升级
     */
    private Integer updateStatus;
    /**
     * 硬盘数量
     */
    private Integer hardDiskCount;
    /**
     * 硬盘状态
     */
    private String hardDiskStatus;
    /**
     * 磁盘状态
     */
    private String diskStatus;

    /**
     * 云存储状态
     */
    private Integer cloudStoreStatus;
    /**
     * 云存储套餐类型
     */
    private String planType;
    /**
     * 云存储套餐购买数量
     */
    private String buyNum;
    /**
     * 云存储到期时间
     */
    private Date cloudStoreTime;
    /**
     * 告警声音模式，0：短叫，1：长叫，2：静音,3:自定义语音,-1:设备没有上报或者设备不支持该状态
     */
    private Integer alarmSoundMode;

    /**
     * 设备模式列表（数据展示时用）
     */
    private Map<Integer, String> devicePatternMap;

    /**
     * 设备所属的运营商中文名称（针对nb设备） 运营商类型：CMCC-中国移动，CUCC-中国联通，CTCC-中国电信
     */
    private String operatorTypeStr;

    /**
     * 设备厂商
     */
    private String manufacturerStr;

    /**
     * 省
     */
    private String provinceStr;

    /**
     * 市
     */
    private String cityStr;

    /**
     * 区
     */
    private String districtStr;


    /*******************************接收参数********************************/

    /**
     * 名称或序列号
     */
    private String deviceNameOrSerial;

    /**
     * 设备状态字符串数组，包括在/离线、启/禁用、智能检测等（过滤查询时用）例：（[onlinestatus:1,openstatus:0]）
     */
    @ApiParam(value = "设备状态字符串数组，包括在/离线、启/禁用、智能检测等（过滤查询时用）例：（[onlinestatus:1,openstatus:0]）")
    private List<String> deviceStatus;

    /**
     * 是否包括所有子组织（过滤查询时用）
     */
    @ApiParam(value = "是否包括所有子组织（过滤查询时用）")
    private boolean containAllChildren;

    /**
     * 组织id列表（按项目编号查询时用于过滤/分页查询时包含下级的情况）
     */
    @ApiParam(value = "组织id列表（按项目编号查询时用于过滤）")
    private List<Long> deviceOrgIdList;


    /**
     * id
     */
    private Long id;

    /**
     * 设备序列号
     */
    private String deviceSerial;

    /**
     * 设备组织id
     */
    //@Excel(name = "设备组织id", orderNum = "2")
    private Long deviceOrgId;


    /**
     * 用户id
     */
    //@Excel(name = "用户id", orderNum = "3")
    private Long userId;

    /**
     * 设备名称
     */
    @Excel(name = "设备名称", orderNum = "2")
    private String deviceName;

    /**
     * 设备验证码
     */
    private String validateCode;

    /**
     * 设备型号
     */
    @Excel(name = "设备型号", orderNum = "3")
    private String model;

    /**
     * 设备类型
     */
    private String modelType;

    /**
     * 设备固件版本
     */
    @Excel(name = "设备固件版本", orderNum = "4")
    private String deviceVersion;

    /**
     * 通道数量
     */
    @Excel(name = "通道数量", orderNum = "5")
    private Integer channumCount;

    /**
     * 项目id
     */
    private Long projectId;

    /**
     * 设备分类  空表示正常的萤石协议设备；NB：nb设备，包括井盖、路灯设备
     */
    private String deviceKind;

    /**
     * 设备所属的运营商（针对nb设备） 运营商类型：CMCC-中国移动，CUCC-中国联通，CTCC-中国电信
     */
    private String operatorType;

    /**
     * 设备id号（针对nb设备）
     */
    private String deviceId;


    /**
     * 设备厂商
     */
    private String manufacturer;

    /**
     * 详细地址
     */
    private String detailAddress;

    /**
     * 省
     */
    private String province;

    /**
     * 市
     */
    private String city;

    /**
     * 区
     */
    private String district;

    /**
     * 被垃圾点位占用
     */
    private boolean occupiedByPoint;

    @JsonSerialize(using = ToStringSerializer.class)
    public void setId(Long id) {
        this.id = id;
    }

    public DeviceInfoVo(){
    }

}
