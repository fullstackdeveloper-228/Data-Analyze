package com.hikvision.hikkan.gbmg.monitor.dto;

import com.hikvision.hikkan.gbmg.base.dto.PageBaseDto;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * 监控点分页查询
 *
 * @author renjie
 * @version 1.0.0
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class MonitorPageDto extends PageBaseDto {

    @ApiModelProperty(value = "监控点序列号或名称或设备名称",allowEmptyValue = true)
    private String nameOrSerialOrDeviceName;

    @ApiModelProperty(value = "监控点序列号",allowEmptyValue = true)
    private String monitorSerial;

    @ApiModelProperty(value = "监控点名称",allowEmptyValue = true)
    private String monitorName;

    @ApiModelProperty(value = "所属设备名称",allowEmptyValue = true)
    private String deviceName;

    @ApiModelProperty(value = "设备型号",allowEmptyValue = true)
    private String model;

    @ApiModelProperty(value = "在线状态",allowEmptyValue = true)
    private Integer onlineStatus;

    //@NotNull(message = "参数deviceOrgId不能为空")
    @ApiModelProperty(value = "设备组织id")
    private Long deviceOrgId;

    @ApiModelProperty(value = "是否包含所有子节点",allowEmptyValue = true)
    private boolean containAllChildren = true;

    @ApiModelProperty(value = "设备启停状态",allowEmptyValue = true)
    private Integer openStatus;

    @ApiModelProperty(value = "是否查询预览记录",allowEmptyValue = true)
    private boolean previewRecord;

    @ApiModelProperty(value = "分配状态，0未分配，1已分配",allowEmptyValue = true)
    private Integer allocationStatus;

    @ApiModelProperty(value = "监控点编号列表，格式：[213321354#0,213321354#1]",allowEmptyValue = true)
    private List<String> monitorCodeList;

    @ApiModelProperty(value = "垃圾点位id",allowEmptyValue = true)
    private Long pointId;

}
