package com.hikvision.hikkan.gbmg.config;


import com.hikvision.hikkan.gbmg.filter.AuthFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author : wukuizhu
 * @date: 2018/12/7
 * @version: 1.0.0
 */

@Configuration
public class FilterConfig {
    @Bean
    public FilterRegistrationBean someFilterRegistration1() {
        //新建过滤器注册类
        FilterRegistrationBean registration = new FilterRegistrationBean();
        // 添加我们写好的过滤器
        registration.setFilter(new AuthFilter());
        // 设置过滤器的URL模式
        registration.addUrlPatterns("/garbage/web/*");
        registration.addInitParameter("excludeUrls","/garbage/web/challengeCode," +
                "/garbage/web/login,/garbage/web/verifyCode,/garbage/web/phone/*," +
                "/garbage/web/changePwd,/garbage/web/user/phone/status,/garbage/web/phone/verifyCode," +
                "/garbage/web/phone/checkCode");
        return registration;
    }
}
