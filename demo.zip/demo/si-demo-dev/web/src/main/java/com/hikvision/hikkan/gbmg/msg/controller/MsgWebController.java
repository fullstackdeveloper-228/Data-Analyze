package com.hikvision.hikkan.gbmg.msg.controller;

import com.hikvision.hikkan.gbmg.base.controller.BaseController;
import com.hikvision.hikkan.gbmg.common.exception.DescribeException;
import com.hikvision.hikkan.gbmg.common.util.ResultUtil;
import com.hikvision.hikkan.gbmg.msg.domain.AlarmMsgHistory;
import com.hikvision.hikkan.gbmg.msg.dto.AlarmMsgHistoryPageDto;
import com.hikvision.hikkan.gbmg.msg.service.MsgWebService;
import com.hikvision.hikkan.gbmg.msg.vo.AlarmMsgHistoryVo;
import com.hikvision.hikkan.kcommon.bean.ObjectResult;
import com.hikvision.hikkan.kcommon.bean.PageData;
import com.hikvision.hikkan.kcommon.enums.ServerCodeEnum;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * 消息历史
 *
 * @author renjie
 * @version 1.0.0
 */
@Api(value = "垃圾分类历史消息服务", tags = "垃圾分类历史消息服务")
@RestController
@RequestMapping("/garbage/web/msg")
public class MsgWebController extends BaseController {

    @Autowired
    MsgWebService msgWebService;

    @ApiOperation(value="消息历史查询", notes="消息历史查询")
    @RequestMapping(value= "/page", method = RequestMethod.POST)
    public ObjectResult page(@RequestBody @Valid AlarmMsgHistoryPageDto alarmMsgHistoryPage, BindingResult results)
    {
        if(results.hasErrors()){
        throw new DescribeException(results.getFieldError().getDefaultMessage(),ServerCodeEnum.PARAM_EMPTY.getCode());
        }
        PageData<AlarmMsgHistoryVo> page = msgWebService.page(alarmMsgHistoryPage);
        return ResultUtil.success(page);
    }

}
