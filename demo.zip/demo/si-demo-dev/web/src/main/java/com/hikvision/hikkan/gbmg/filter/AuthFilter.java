package com.hikvision.hikkan.gbmg.filter;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.hikvision.hikkan.gbmg.common.context.AuthContext;
import com.hikvision.hikkan.gbmg.common.util.hikvision.HikkanApiUrl;
import com.hikvision.hikkan.gbmg.common.util.hikvision.HikkanUtil;
import com.hikvision.hikkan.kcommon.bean.ObjectResult;
import com.hikvision.hikkan.kcommon.enums.ServerCodeEnum;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Objects;

import static com.hikvision.hikkan.gbmg.base.service.BaseService.artemisToken;


/**
 * 权限过滤器
 *
 * @author renjie
 * @version 1.0.0
 */

public class AuthFilter implements Filter{
    private static final Logger log = LoggerFactory.getLogger(AuthFilter.class);
    private String ignoresParam;
    private String[] prefixIignores;
    String errorCode = "401";
    String errorMsg = "登录超时，请重新登录";

    public AuthFilter() {
    }

    protected void fail(ServletResponse response, String code, String msg) {
        try {
            response.setContentType("application/json; charset=utf-8");
            PrintWriter writer = response.getWriter();
            writer.append(JSON.toJSONString(new ObjectResult(code, msg, null)));
        } catch (IOException e) {
            log.error("BaseFilter : ", e);
        }
    }

    public void doFilter(final ServletRequest servletRequest, final ServletResponse servletResponse, final FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest)servletRequest;
        HttpServletResponse response = (HttpServletResponse)servletResponse;
        if (this.canIgnore(request)) {
            filterChain.doFilter(request, response);
        } else {
            try {
                String authorization = request.getHeader("Authorization");
                AuthContext.setToken(authorization);
                String s = HikkanUtil.httpPost(HikkanApiUrl.TOKEN_CHECK, "", artemisToken());
                ObjectResult objectResult = JSONObject.parseObject(s, ObjectResult.class);
                if(!Objects.isNull(objectResult)){
                    if(ServerCodeEnum.SUCCESS.getCode().equals(objectResult.getCode())){
                        filterChain.doFilter(request, response);
                    }else{
                        fail(response,objectResult.getCode(),objectResult.getMsg());
                    }
                }else{
                    fail(response,errorCode,errorMsg);
                }
            } catch (Exception var14) {
                throw var14;
            } finally {
                AuthContext.clean();
            }

        }
    }


    public void init(FilterConfig filterConfig) throws ServletException {
        this.ignoresParam = filterConfig.getInitParameter("excludeUrls");
        if (StringUtils.isNotEmpty(this.ignoresParam)) {
            this.prefixIignores = this.ignoresParam.split(",");
        }

    }

    private boolean canIgnore(HttpServletRequest request) {
        boolean isExcludedPage = false;
        if (!Objects.isNull(this.prefixIignores)) {
            String[] var3 = this.prefixIignores;
            int var4 = var3.length;

            for(int var5 = 0; var5 < var4; ++var5) {
                String page = var3[var5];
                if (request.getServletPath().equals(page)) {
                    isExcludedPage = true;
                    break;
                }
            }
        }

        return isExcludedPage;
    }

    public void destroy() {
    }
}

