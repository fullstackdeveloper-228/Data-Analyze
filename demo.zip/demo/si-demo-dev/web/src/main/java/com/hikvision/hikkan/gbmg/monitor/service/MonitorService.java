package com.hikvision.hikkan.gbmg.monitor.service;

import com.hikvision.hikkan.gbmg.monitor.dto.*;
import com.hikvision.hikkan.kcommon.bean.ObjectResult;

public interface MonitorService {
    /**
     * 获取录像片段
     * @param monitorVideoByTimeDto
     * @return
     */
    ObjectResult videoByTime(MonitorVideoByTimeDto monitorVideoByTimeDto);

    /**
     * 根据id查询监控点
     * @param monitorVideoByTime
     * @return
     */
    ObjectResult monitorById(MonitorFindByIdDto monitorFindByIdDto);
    /**
     * 云台操作
     * @param ptzDto
     * @return
     */
    ObjectResult ptz(PtzDto ptzDto);

    /**
     * 监控点分页
     * @return
     */
    ObjectResult page(MonitorPageDto monitorPageDto);

    /**
     * 获取播放器播放的xml
     * @return
     */
    ObjectResult getPlayXml(MonitorGetPlayXmlDto monitorGetPlayXmlDto);
}
