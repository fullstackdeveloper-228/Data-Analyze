package com.hikvision.hikkan.gbmg.login.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.hikvision.hikkan.gbmg.base.service.BaseService;
import com.hikvision.hikkan.gbmg.common.util.hikvision.HikkanApiUrl;
import com.hikvision.hikkan.gbmg.common.util.hikvision.HikkanUtil;
import com.hikvision.hikkan.gbmg.login.dto.*;
import com.hikvision.hikkan.gbmg.login.service.LoginService;
import com.hikvision.hikkan.gbmg.login.vo.ChallengeCodeVO;
import com.hikvision.hikkan.gbmg.login.vo.LoginVO;
import com.hikvision.hikkan.gbmg.login.vo.PhoneVerifyCodeVO;
import com.hikvision.hikkan.kcommon.bean.ObjectResult;
import com.hikvision.hikkan.kcommon.enums.ServerCodeEnum;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

/**
 * Created by liuning9
 * 2019/7/16 10:15
 */
@Service
public class LoginServiceImpl extends BaseService implements LoginService {

    /**
     * 获取挑战码
     * @param dto
     * @return
     * @throws Exception
     */
    @Override
    public ObjectResult<ChallengeCodeVO> getChallengeCode(ChallengeRequestCodeDTO dto){
        if(dto == null){
            return ObjectResult.error(ServerCodeEnum.PARAM_ERROR.getMsg());
        }
        if(StringUtils.isBlank(dto.getProductCode())) {
            dto.setProductCode(productCode);
        }
        String source = JSONObject.toJSONString(dto);
        if(StringUtils.isBlank(source)){
            throw new RuntimeException("请求挑战码json数据转化异常");
        }
        String result = HikkanUtil.httpPost(HikkanApiUrl.CHALLENGE_CODE, source, artemisToken());
        if(StringUtils.isBlank(result)){
            throw new RuntimeException("云曜开放接口获取挑战码error");
        }
        ObjectResult<ChallengeCodeVO> vo = JSON.parseObject(result, ObjectResult.class);
        return vo;
    }

    /**
     * 登陆
     * @param dto
     * @return
     * @throws Exception
     */
    @Override
    public ObjectResult<LoginVO> login(LoginDTO dto){
        if(dto == null){
            return ObjectResult.error(ServerCodeEnum.PARAM_ERROR.getMsg());
        }
        if(StringUtils.isBlank(dto.getProductCode())){
            dto.setProductCode(productCode);
        }
        String source = JSONObject.toJSONString(dto);
        if(StringUtils.isBlank(source)){
            throw new RuntimeException("登陆参数数据转化异常");
        }
        String result = HikkanUtil.httpPost(HikkanApiUrl.LOGIN, source, artemisToken());
        if(StringUtils.isBlank(result)){
            throw new RuntimeException("云曜开放接口登陆error");
        }
        ObjectResult<LoginVO> vo = JSON.parseObject(result, ObjectResult.class);
        return vo;
    }

    /**
     * 登出服务
     * @return
     * @throws Exception
     */
    @Override
    public ObjectResult logout(){
        String result = HikkanUtil.httpPost(HikkanApiUrl.LOGOUT, null, artemisToken());
        if(StringUtils.isBlank(result)){
            throw new RuntimeException("云曜开发接口登出error");
        }
        return JSON.parseObject(result, ObjectResult.class);
    }

    /**
     * 滑动检测
     * @param dto
     * @return
     */
    @Override
    public ObjectResult verifyCode(VerifyCodeDTO dto){
        if(dto == null){
            return ObjectResult.error(ServerCodeEnum.PARAM_ERROR.getMsg());
        }
        if(StringUtils.isBlank(dto.getProductCode())){
            dto.setProductCode(productCode);
        }
        String source = JSONObject.toJSONString(dto);
        if(StringUtils.isBlank(source)){
            throw new RuntimeException("滑动检测参数json转化异常");
        }
        String result = HikkanUtil.httpPost(HikkanApiUrl.VERIFY_CODE, source, artemisToken());
        return JSON.parseObject(result, ObjectResult.class);
    }

    /**
     * 获取手机验证码
     * @param dto
     * @return
     */
    @Override
    public ObjectResult<PhoneVerifyCodeVO> phoneVerifyCode(PhoneVerifyCodeDTO dto){
        if(dto == null){
            return ObjectResult.error(ServerCodeEnum.PARAM_ERROR.getMsg());
        }
        if(StringUtils.isBlank(dto.getProductCode())){
            dto.setProductCode(productCode);
        }
        String source = JSONObject.toJSONString(dto);
        if(StringUtils.isBlank(source)){
            throw new RuntimeException("获取手机验证码参数json转化异常");
        }
        String result = HikkanUtil.httpPost(HikkanApiUrl.PHONE_VERIFY_CODE, source, artemisToken());
        if(StringUtils.isBlank(result)){
            throw new RuntimeException("云曜开放接口获取手机验证码error");
        }
        ObjectResult<PhoneVerifyCodeVO> vo = JSON.parseObject(result, ObjectResult.class);
        return vo;
    }

    /**
     * 校验手机验证码
     * @param dto
     * @return
     */
    @Override
    public ObjectResult<PhoneVerifyCodeVO> checkPhoneVerifyCode(CheckPhoneVerifyCodeDTO dto){
        if(dto == null){
            return ObjectResult.error(ServerCodeEnum.PARAM_ERROR.getMsg());
        }
        if(StringUtils.isBlank(dto.getProductCode())){
            dto.setProductCode(productCode);
        }
        String source = JSONObject.toJSONString(dto);
        if(StringUtils.isBlank(source)){
            throw new RuntimeException("校验手机验证码参数json转化异常");
        }
        String result = HikkanUtil.httpPost(HikkanApiUrl.CHECK_VERIFY_CODE, source, artemisToken());
        if(StringUtils.isBlank(result)){
            throw new RuntimeException("云曜开放接口校验手机验证码error");
        }
        ObjectResult<PhoneVerifyCodeVO> vo = JSON.parseObject(result, ObjectResult.class);
        return vo;
    }

    /**
     * 获取手机号认证状态
     * @param dto
     * @return
     */
    public ObjectResult phoneStatus(PhoneSmsDTO dto){
        if(dto == null){
            return ObjectResult.error(ServerCodeEnum.PARAM_ERROR.getMsg());
        }
        if(StringUtils.isBlank(dto.getProductCode())){
            dto.setProductCode(productCode);
        }
        String source = JSONObject.toJSONString(dto);
        if(StringUtils.isBlank(source)){
            throw new RuntimeException("获取手机号认证状态json转化异常");
        }
        String result = HikkanUtil.httpPost(HikkanApiUrl.PHONE_STATUS, source, artemisToken());
        if(StringUtils.isBlank(result)){
            throw new RuntimeException("云曜开放接口获取手机号认证状态error");
        }
        return JSON.parseObject(result, ObjectResult.class);
    }


}
