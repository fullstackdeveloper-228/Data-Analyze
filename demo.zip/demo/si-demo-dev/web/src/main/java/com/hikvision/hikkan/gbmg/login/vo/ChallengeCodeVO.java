package com.hikvision.hikkan.gbmg.login.vo;

import lombok.Data;

/**
 * Created by liuning9
 * 2019/7/22 9:56
 */
@Data
public class ChallengeCodeVO{

    /**
     * 挑战码
     */
    private String vCode;

    /**
     * 挑战码key
     */
    private String codeId;

    /**
     * 盐值
     */
    private String salt;
}
