package com.hikvision.hikkan.gbmg.msg.service;

public interface MsgReceiveService {

    void receiveAlarmMsg(String data);
}
