package com.hikvision.hikkan.gbmg.login.dto;

import com.hikvision.hikkan.kcommon.constant.HikkanConstants;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

/**
 * @author liuning on 2019/4/3.
 * @dsc
 * @since v1.0.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PhoneSmsDTO implements Serializable {

    private static final long serialVersionUID = -3932499782262904471L;

    @NotEmpty(message = "phoneNo不能为空")
    @ApiModelProperty(value = "手机号")
    @Pattern(regexp = "^1[0-9]{10}$", message = "phone格式不正确")
    private String phoneNo;

    @ApiModelProperty(value = "验证码", allowEmptyValue = true)
    @Pattern(regexp = HikkanConstants.SPECIAL_CHARACTER_PATTERN,message = "verifyCode不能有特殊字符")
    @Length(max = 32,message = "参数verifyCode长度不能大于32位")
    private String verifyCode;

    @ApiModelProperty(value = "原密码", allowEmptyValue = true)
    //@Pattern(regexp = HikkanConstants.SPECIAL_CHARACTER_PATTERN,message = "oldPwd不能有特殊字符")
    //@Length(max = 32,message = "参数oldPwd长度不能大于32位")
    private String oldPwd;

    @ApiModelProperty(value = "产品编号", allowEmptyValue = true)
    @Pattern(regexp = HikkanConstants.SPECIAL_CHARACTER_PATTERN,message = "productCode不能有特殊字符")
    @Length(max = 32,message = "参数productCode长度不能大于32位")
    private String productCode;

    @ApiModelProperty(value = "登陆类型： 0 ：个人用户  1：租户用户  2: 系统用户")
    private Integer type;

    @ApiModelProperty(value = "挑战码id", allowEmptyValue = true)
    @Pattern(regexp = HikkanConstants.SPECIAL_CHARACTER_PATTERN,message = "codeId不能有特殊字符")
    //@Length(max = 32,message = "参数codeId长度不能大于32位")
    private String codeId;
}
