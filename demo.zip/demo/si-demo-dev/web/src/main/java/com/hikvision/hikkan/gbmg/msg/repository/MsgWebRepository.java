package com.hikvision.hikkan.gbmg.msg.repository;

import com.hikvision.hikkan.gbmg.msg.domain.AlarmMsgHistory;
import com.hikvision.hikkan.gbmg.msg.dto.AlarmMsgHistoryPageDto;
import com.hikvision.hikkan.gbmg.msg.vo.AlarmMsgHistoryVo;
import com.hikvision.hikkan.kcommon.bean.PageData;
import org.springframework.data.jpa.repository.JpaRepository;



/**
 * 消息历史记录数据层
 *
 * @author renjie
 * @version 1.0.0
 */
public interface MsgWebRepository extends JpaRepository<AlarmMsgHistory, Long> {

    PageData<AlarmMsgHistoryVo> page(AlarmMsgHistoryPageDto alarmMsgHistoryPage);

}
