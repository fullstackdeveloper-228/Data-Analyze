package com.hikvision.hikkan.gbmg.base.controller;

import com.hikvision.hikkan.gbmg.base.Base;
import org.springframework.stereotype.Component;

/**
 * 控制层基类
 *
 * @author renjie
 * @version 1.0.0
 */
@Component
public class BaseController  extends Base {

}
