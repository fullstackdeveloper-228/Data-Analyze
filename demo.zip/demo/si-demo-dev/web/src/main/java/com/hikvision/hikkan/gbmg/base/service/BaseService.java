package com.hikvision.hikkan.gbmg.base.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.hikvision.hikkan.gbmg.common.constant.RedisConstant;
import com.hikvision.hikkan.gbmg.common.constant.StaticConstant;
import com.hikvision.hikkan.gbmg.common.util.hikvision.HikkanApiUrl;
import com.hikvision.hikkan.gbmg.common.util.hikvision.HikkanUtil;
import com.hikvision.hikkan.kcommon.enums.ServerCodeEnum;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * Created by liuning9
 * 2019/7/17 16:17
 */
@Service
public class BaseService {

    @Autowired
    private RedisTemplate redisTemplate;

    private static String artemisKey;

    private static String artemisSecret;

    private static String token;

    @Value("${hikvision.product.code}")
    protected String productCode;

    @Value("${hikvision.artemis.key}")
    public void setArtemisKey(String key) {
        artemisKey = key;
    }

    @Value("${hikvision.artemis.secret}")
    public void setArtemisSecret(String secret) {
        artemisSecret = secret;
    }

    @Value("${hikvision.url.token}")
    public void setToken(String token) {
        this.token = token;
    }

    /**
     * 全局token根据key和secret缓存
     * @return
     */
    public String cacheArtemisToken(){
//        String end = (String) redisTemplate.opsForValue().get(RedisConstant.getArtemisToken(artemisKey+artemisSecret));
//        if(StringUtils.isNotBlank(end)){
//            return end;
//        }
//        end = artemisToken();
//        redisTemplate.opsForValue().set(RedisConstant.getArtemisToken(artemisKey+artemisSecret),
//                end, RedisConstant.ARTEMIS_TOKEN_EXPIRY, TimeUnit.HOURS);
//        return end;
        return artemisToken();
    }

    /**
     * 获取全局token
     * @return
     * @throws Exception
     */
    public static String artemisToken() {
        String source = "client_id="+ artemisKey+"&client_secret="+artemisSecret;
        String result = HikkanUtil.httpPost(token, source,null);
        if(StringUtils.isBlank(result)){
            throw new RuntimeException("获取artemis token异常");
        }
        JSONObject jsonObject = JSON.parseObject(result);
        return jsonObject.getString("access_token");
    }

    /**
     *
     * 获取全局token
     * @return
     */
    public static String globalToken(){
        String result = HikkanUtil.httpPost(HikkanApiUrl.GLOBAL_TOKEN, JSONObject.toJSONString(new HashMap<String, String>() {{
            put("productCode", HikkanApiUrl.productCode);
            put("apiKey", HikkanApiUrl.apiKey);
        }}), artemisToken());
        if(StringUtils.isBlank(result)){
            throw new RuntimeException("获取global token异常");
        }
        JSONObject jsonObject = JSON.parseObject(result);
        String code = jsonObject.getString("code");
        if(ServerCodeEnum.SUCCESS.getCode().equals(code)){
            JSONObject data = jsonObject.getJSONObject("data");
            String authorization = data.getString("Authorization");
            return authorization;
        }
        return "";
    }

    /**
     * 播放器时间处理规则：如没有结束时间，则默认加1分钟；有结束时间，默认加5秒
     * @param startTime
     * @param endTime
     * @return
     */
    public static Long createEndTime(Long startTime, Long endTime){
        if(Objects.isNull(endTime) || endTime == 0){
            return startTime + StaticConstant.ONE_MINUTES;
        }else{
            return endTime + StaticConstant.FIVE_SECONDS;
        }
    }

}
