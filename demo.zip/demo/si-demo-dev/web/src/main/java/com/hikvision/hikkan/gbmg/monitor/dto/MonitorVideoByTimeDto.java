package com.hikvision.hikkan.gbmg.monitor.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;

/**
 * 获取录像回放文本信息
 *
 * @author renjie
 * @version 1.0.0
 */
@Data
public class MonitorVideoByTimeDto {

    @NotEmpty(message = "参数deviceSerial不能为空")
    @ApiModelProperty(value = "监控点序列号")
    private String deviceSerial;

    /**
     * 通道号，非必选，默认为1
     */
    @ApiModelProperty(value = "通道号，非必选，默认为1",allowEmptyValue = true)
    private Integer channelNo;

    /**
     * 起始时间，时间格式为：1378345128000。非必选，默认为当天0点
     */
    @ApiModelProperty(value = "起始时间，时间格式为：1378345128000。非必选，默认为当天0点",allowEmptyValue = true)
    private Long startTime;

    /**
     * 结束时间，时间格式为：1378345128000。非必选，默认为当前时间
     */
    @ApiModelProperty(value = "结束时间，时间格式为：1378345128000。非必选，默认为当前时间",allowEmptyValue = true)
    private Long endTime;

    /**
     * 回放源，0-系统自动选择，1-云存储，2-本地录像。非必选，默认为0
     */
    @ApiModelProperty(value = "回放源，0-系统自动选择，1-云存储，2-本地录像。非必选，默认为0",allowEmptyValue = true)
    private Integer recType;

}
