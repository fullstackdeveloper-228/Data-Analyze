package com.hikvision.hikkan.gbmg.monitor.controller;

import com.hikvision.hikkan.gbmg.base.controller.BaseController;
import com.hikvision.hikkan.gbmg.common.exception.DescribeException;
import com.hikvision.hikkan.gbmg.monitor.dto.*;
import com.hikvision.hikkan.gbmg.monitor.service.MonitorService;
import com.hikvision.hikkan.kcommon.bean.ObjectResult;
import com.hikvision.hikkan.kcommon.enums.ServerCodeEnum;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * 监控点
 *
 * @author renjie
 * @version 1.0.0
 */
@Api(value = "垃圾分类监控点服务", tags = "垃圾分类监控点服务")
@RestController
@RequestMapping("/garbage/web/monitor")
public class MonitorWebController extends BaseController {

    @Autowired
    private MonitorService monitorService;

    @ApiOperation(value="获取录像片段", notes="获取录像片段")
    @RequestMapping(value= "/video/by/time", method = RequestMethod.POST)
    public ObjectResult videoByTime(@RequestBody @Valid MonitorVideoByTimeDto monitorVideoByTimeDto, BindingResult results)
    {
        if(results.hasErrors()){
            throw new DescribeException(results.getFieldError().getDefaultMessage(),ServerCodeEnum.PARAM_EMPTY.getCode());
        }
        return monitorService.videoByTime(monitorVideoByTimeDto);
    }

    @ApiOperation(value="根据id查询监控点", notes="根据id查询监控点")
    @RequestMapping(value= "/find/by/id", method = RequestMethod.POST)
    public ObjectResult monitorById(@RequestBody @Valid MonitorFindByIdDto monitorFindByIdDto, BindingResult results)
    {
        if(results.hasErrors()){
            throw new DescribeException(results.getFieldError().getDefaultMessage(),ServerCodeEnum.PARAM_EMPTY.getCode());
        }
        return monitorService.monitorById(monitorFindByIdDto);
    }

    @ApiOperation(value="云台控制", notes="云台控制")
    @RequestMapping(value= "/ptz", method = RequestMethod.POST)
    public ObjectResult ptz(@RequestBody @Valid PtzDto ptzDto, BindingResult results)
    {
        if(results.hasErrors()){
            throw new DescribeException(results.getFieldError().getDefaultMessage(),ServerCodeEnum.PARAM_EMPTY.getCode());
        }
        return monitorService.ptz(ptzDto);
    }

    @ApiOperation(value="分页查询监控点", notes="分页查询监控点")
    @RequestMapping(value= "/page", method = RequestMethod.POST)
    public ObjectResult videoByTime(@RequestBody @Valid MonitorPageDto monitorPageDto, BindingResult results)
    {
        if(results.hasErrors()){
            throw new DescribeException(results.getFieldError().getDefaultMessage(),ServerCodeEnum.PARAM_EMPTY.getCode());
        }
        return monitorService.page(monitorPageDto);
    }

    @ApiOperation(value="获取播放器播放的xml", notes="获取播放器播放的xml")
    @RequestMapping(value= "/play/xml/get", method = RequestMethod.POST)
    public ObjectResult getPlayXml(@RequestBody @Valid MonitorGetPlayXmlDto monitorGetPlayXmlDto, BindingResult results)
    {
        if(results.hasErrors()){
            throw new DescribeException(results.getFieldError().getDefaultMessage(),ServerCodeEnum.PARAM_EMPTY.getCode());
        }
        return monitorService.getPlayXml(monitorGetPlayXmlDto);
    }
}
