package com.hikvision.hikkan.gbmg.garbagepoint.domain;

import com.hikvision.hikkan.gbmg.base.domain.BaseDomain;
import com.hikvision.hikkan.gbmg.common.constant.DeviceTypeEnum;
import com.hikvision.hikkan.kcommon.util.SnowflakeIdGenerator;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Created by liuning9
 * 2019/7/24 10:29
 */
@Data
@Entity
@Table(name = "garbage_device_map")
@EqualsAndHashCode(callSuper = true)
public class GarbageDeviceMapPO extends BaseDomain {

    @Id
    @Column(name = "id")
    private Long id = SnowflakeIdGenerator.getInstance().nextId();
    /**
     * 垃圾点id
     */
    @Column(name = "garbage_point_id")
    private Long garbagePointId;
    /*
     * 设备id
     */
    @Column(name = "device_id")
    private Long deviceId;
    /**
     * 关联类型 {@link DeviceTypeEnum}
     */
    @Column(name = "type")
    private Integer type;
}
