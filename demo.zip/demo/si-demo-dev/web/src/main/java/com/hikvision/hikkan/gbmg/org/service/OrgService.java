package com.hikvision.hikkan.gbmg.org.service;

import com.hikvision.hikkan.gbmg.org.dto.OrgDTO;
import com.hikvision.hikkan.kcommon.bean.ObjectResult;

import java.util.List;

public interface OrgService {

    /**
     * 获取用户组织树
     * @return
     */
    ObjectResult orgTree();

    /**
     * 获取某个组织节点下的所有组织
     * @param id
     * @return
     */
    List<Long> findAllIdListByParent(Long id);

    /**
     * 获取组织信息
     * @param orgIds
     * @param id
     * @return
     */
    List<OrgDTO> findByIdsAndProjectId(List<Long> orgIds, Long id);
}