package com.hikvision.hikkan.gbmg.common.constant;

/**
 * 存放一些静态常量
 *
 * @author renjie
 * @version 1.0.0
 */
public class StaticConstant {

    /**********************************************************************************************************************/
    /**************                                           设备                                           **************/
    /**********************************************************************************************************************/


    /**
     * 设备名称
     */
    public static final String DEVICE_NAME = "deviceName";

    /**
     * 设备类型
     */
    public static final String  MODEL_TYPE = "modelType";

    /**
     * 设备组织id
     */
    public static final String DEVICE_ORG_ID = "deviceOrgId";

    /**
     * 设备/监控点启停状态
     */
    public static final String OPEN_STATUS = "openStatus";

    /**
     * 设备智能开关
     */
    public static final String INTELLIVAL = "intelliVal";

    /**
     * 设备布撤防
     */
    public static final String DEFENCE = "defence";

    /**
     * 设备远程升级
     */
    public static final String UPDATE_STATUS =  "updateStatus";

    /**
     * 设备组织id（多个）
     */
    public static final String DEVICE_ORG_IDS = "device_org_ids";

    /**
     * 设备id（多个）
     */
    public static final String DEVICE_IDS = "device_ids";

    /**
     * 项目id
     */
    public static final String PROJECT_ID = "projectId";



    /**********************************************************************************************************************/
    /**************                                        监控点                                            **************/
    /**********************************************************************************************************************/

    /**
     * 监控点名称
     */
    public static final String MONITOR_NAME = "monitorName";

    public static final String ALLOCATION_STATUS = "allocationStatus";

    /**
     * osd名称
     */
    public static final String OSD_NAME = "osdName";

    /**
     * 导入导出文件夹
     */
    public static final String  OSD_PATH_IMEXPORT = "imexport";
    /**
     * 萤石抓图图片文件夹
     */
    public static final String OSD_PATH_CAPTURE = "capture";
    /**
     * 播放器及播放器插件
     */
    public static final String PREVIEW_EXE_TEMPLATE = "previewExeTemplate";


    /**********************************************************************************************************************/
    /**************                           操作日志类型及状态/导入导出相关                                **************/
    /**********************************************************************************************************************/

    /**
     * 添加
     */
    public static final String ADD = "ADD";

    /**
     * 删除
     */
    public static final String DELETE = "DELETE";

    /**
     * 更新
     */
    public static final String UPDATE = "UPDATE";


    /**
     * 导入
     */
    public static final String IMPORT = "IMPORT";

    /**
     * 导出
     */
    public static final String EXPORT = "EXPORT";


    /**
     * 设备信息导入失败的文件名
     */
    public static final String DEVICE_INFO_IMPORT_ERROR_FILENAME = "deviceInfoImportError";

    /**
     * 监控点信息导入失败的文件名
     */
    public static final String MONITOR_INFO_IMPORT_ERROR_FILENAME = "cameraInfoImportError";

    /**
     * nb设备导入失败的文件名
     */
    public static final String NB_DEVICE_INFO_IMPORT_ERROR_FILENAME = "nbDeviceInfoImportError";

    /**
     * 设备组织导入失败的文件名
     */
    public static final String DEVICE_ORG_IMPORT_ERROR_FILENAME = "deviceOrgImportError";


    /**
     * 设备信息导出的文件名
     */
    public static final String DEVICE_INFO_EXPORT_FILENAME = "deviceInfoExport";

    /**
     * 监控点信息导出的文件名
     */
    public static final String MONITOR_INFO_EXPORT_FILENAME = "monitorInfoExport";

    /**
     * 设备组织导出的文件名
     */
    public static final String DEVICE_ORG_EXPORT_FILENAME = "deviceOrgExport";

    /**
     * nb设备注册导出的文件名
     */
    public static final String NB_DEVICE_REGISTER_FILENAME = "nbDeviceRegister";

    /**
     * 导出中
     */
    public static final int EXPORTING = -1;

    /**
     * 导入中
     */
    public static final int IMPORTING = -2;

    /**
     * 导出成功
     */
    public static final int EXPORTSUCCESS = -3;

    /**
     * 导入成功
     */
    public static final int IMPORTSUCCESS = 0;

    /**
     * 导出失败
     */
    public static final int EXPORTERROR = -5;

    /**
     * 导入失败
     */
    public static final int IMPORTERROR = -4;

    /**
     * excel文件后缀
     */
    public static final String XLS = "xls";

    /**
     * 设备
     */
    public static final String DEVICE_INFO_CN = "设备";

    /**
     * NB设备
     */
    public static final String NB_DEVICE_INFO_CN = "NB设备";

    /**
     * 监控点
     */
    public static final String MONITOR_INFO_CN = "监控点";

    /**
     * 设备组织
     */
    public static final String DEVICE_ORG_CN = "设备组织";


//    /**********************************************************************************************************************/
//    /**************                                       模块变量                                           **************/
//    /**********************************************************************************************************************/
//    /**
//     * 资源中心
//     */
//    public static final String HIKKAN_RES = "hikkan_res";
//    public static final String HIKKAN_RES_STR = "资源中心";
//    /**
//     * 组织管理（资源子模块）
//     */
//    public static final String HIKKAN_RES_ORG = "hikkan_res_org";
//    public static final String HIKKAN_RES_ORG_STR = "组织管理";
//
//    /**
//     * 设备管理（资源子模块）
//     */
//    public static final String HIKKAN_RES_DEVICE = "hikkan_res_device";
//    public static final String HIKKAN_RES_DEVICE_STR = "设备管理";




    /**********************************************************************************************************************/
    /**************                                        数字 标点 等                                      **************/
    /**********************************************************************************************************************/

    /**
     * 负一千
     */
    public static final Integer MINUS_ONE_THOUSAND = -1000;

    /**
     * 一千
     */
    public static final Integer ONE_THOUSAND = 1000;

    public static final String COMMA = ",";

    public static final String COLON = ":";

    public static final String SLASH = "/";

    public static final String BACKSLASH = "\\";

    public static final String NUMBER_SIGN = "#";

    public static final String AND = "&";

    public static final String JPG = "jpg";

    public static final String SPOT = ".";

    /**
     * 三分钟（单位：毫秒）
     */
    public static final Long THREE_MINUTES = 1000*60*3L;
    /**
     * 一分钟（单位：毫秒）
     */
    public static final Long ONE_MINUTES = 1000*60*1L;
    /**
     * 5秒（单位：毫秒）
     */
    public static final Long FIVE_SECONDS = 1000*5*1L;


    /**
     * 1天
     */
    public static final Long ONE_DAY = 1000*60*60*24L;


    /**********************************************************************************************************************/
    /**************                                           redis键                                        **************/
    /**********************************************************************************************************************/

    /**
     * 接收的消息是否重复的键值
     */
    public static final String GBMG_MESSAGE_RECEIVE_ALARMSERVICE_ISREPEATMSG = "GBMG_MESSAGE_RECEIVE_ALARMSERVICE_ISREPEATMSG";


}
