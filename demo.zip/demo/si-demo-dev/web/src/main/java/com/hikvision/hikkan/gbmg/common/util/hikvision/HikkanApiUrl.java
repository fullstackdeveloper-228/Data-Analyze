package com.hikvision.hikkan.gbmg.common.util.hikvision;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * 调用云曜的接口列表
 *
 * @author renjie
 * @version 1.0.0
 */
@Component
public class HikkanApiUrl {

    //云曜apigateway服务平台地址
    public static String HIKKAN_API_GATEWAY_DOMAIN;

    //产品code
    public static String productCode;
    @Value("${hikvision.product.code}")
    public void setProductCode(String productCode) {
        HikkanApiUrl.productCode = productCode;
    }

    //产品的appkey
    public static String apiKey;
    @Value("${hikvision.artemis.key}")
    public void setApiKey(String apiKey) {
        HikkanApiUrl.apiKey = apiKey;
    }

    /**
     * 获取录像片段
     */
    public static String VIDEO_BY_TIME;

    /**
     * 获取萤石的限制级token
     */
    public static String RESTRICTED_TOKEN_GET;

    /**
     * 根据id查询监控点
     */
    public static String MONITOR_BY_ID;

    /**
     * 云台控制
     */
    public static String PTZ;

    /**
     * 分页查询监控点
     */
    public static String MONITOR_PAGE;

    /**
     * 根据code查询监控点
     */
    public static String MONITOR_BY_CODE;

    /**
     * 获取组织信息
     */
    public static String ORG_BY_IDS;

    /**
     * token保活
     */
    public static String TOKEN_CHECK;

    /**
     * 手机号认证状态
     */
    public static String PHONE_STATUS;

    /**
     * 挑战码
     */
    public static String CHALLENGE_CODE;

    /**
     * 登陆
     */
    public static String LOGIN;

    /**
     * 登出
     */
    public static String LOGOUT;

    /**
     * 滑动检测
     */
    public static String VERIFY_CODE;

    /**
     * 获取手机验证码
     */
    public static String PHONE_VERIFY_CODE;

    /**
     * 校验手机验证码
     */
    public static String CHECK_VERIFY_CODE;

    /**
     * 获取当前登陆用户权限
     */
    public static String AUTHS;

    /**
     * 修改密码
     */
    public static String CHANGE_PWD;

    /**
     * 保存密码
     */
    public static String UPDATE_PWD;

    /**
     * 获取组织树
     */
    public static String ORG_TREE;

    /**
     * 分页查询设备
     */
    public static String DEVICE_PAGE;

    /**
     * 获取播放器xml
     */
    public static String PLAY_XML_GET;

    /**
     * 获取全局token
     */
    public static String GLOBAL_TOKEN;

    @Value("${hikvision.host}")
    public void setHikvisionRoute(String host) {
        HIKKAN_API_GATEWAY_DOMAIN = host;
        //查询录像片段
        VIDEO_BY_TIME = HIKKAN_API_GATEWAY_DOMAIN + "/api/eits/v1/monitor/video/by/time";
        //获取限制级萤石token
        RESTRICTED_TOKEN_GET = HIKKAN_API_GATEWAY_DOMAIN + "/api/eits/v1/user/ys/restricted/token/get";
        //根据id查询监控点
        MONITOR_BY_ID = HIKKAN_API_GATEWAY_DOMAIN + "/api/eits/v1/monitor/find/by/id";
        //云台控制
        PTZ = HIKKAN_API_GATEWAY_DOMAIN + "/api/eits/v1/device/ptz";
        //监控点分页查询
        MONITOR_PAGE = HIKKAN_API_GATEWAY_DOMAIN + "/api/eits/v1/monitor/page";
        //token保活
        TOKEN_CHECK = HIKKAN_API_GATEWAY_DOMAIN + "/api/eits/v1/check";
        //获取手机号状态
        PHONE_STATUS = HIKKAN_API_GATEWAY_DOMAIN + "/api/eits/v1/phone/status";
        //获取挑战码
        CHALLENGE_CODE = HIKKAN_API_GATEWAY_DOMAIN + "/api/eits/v1/challengeCode";
        //登录
        LOGIN = HIKKAN_API_GATEWAY_DOMAIN + "/api/eits/v1/login";
        //登出
        LOGOUT = HIKKAN_API_GATEWAY_DOMAIN + "/api/eits/v1/logout";
        //滑动检测
        VERIFY_CODE = HIKKAN_API_GATEWAY_DOMAIN + "/api/eits/v1/verifyCode";
        //请求验证码
        PHONE_VERIFY_CODE = HIKKAN_API_GATEWAY_DOMAIN + "/api/eits/v1/phone/verifyCode";
        //校验验证码
        CHECK_VERIFY_CODE = HIKKAN_API_GATEWAY_DOMAIN + "/api/eits/v1/phone/checkCode";
        //获取用户权限信息
        AUTHS = HIKKAN_API_GATEWAY_DOMAIN + "/api/eits/v1/user/auths/get";
        //更改密码
        CHANGE_PWD = HIKKAN_API_GATEWAY_DOMAIN + "/api/eits/v1/changePwd";
        //更新密码
        UPDATE_PWD = HIKKAN_API_GATEWAY_DOMAIN + "/api/eits/v1/user/pwd/update";
        //获取组织树
        ORG_TREE = HIKKAN_API_GATEWAY_DOMAIN + "/api/eits/v1/deviceorg/findAll";
        //设备分页查询
        DEVICE_PAGE = HIKKAN_API_GATEWAY_DOMAIN + "/api/eits/v1/device/page";
        //获取播放器xml
        PLAY_XML_GET = HIKKAN_API_GATEWAY_DOMAIN + "/api/eits/v1/monitor/play/xml/get";
        //根据code查询监控点
        MONITOR_BY_CODE = HIKKAN_API_GATEWAY_DOMAIN + "/api/eits/v1/global/monitor/by/code";
        //获取全局token
        GLOBAL_TOKEN = HIKKAN_API_GATEWAY_DOMAIN + "/api/eits/v1/global/jwt";
        //获取组织信息
        ORG_BY_IDS = HIKKAN_API_GATEWAY_DOMAIN + "/api/eits/v1/global/deviceorg/find/by/ids";
    }

}
