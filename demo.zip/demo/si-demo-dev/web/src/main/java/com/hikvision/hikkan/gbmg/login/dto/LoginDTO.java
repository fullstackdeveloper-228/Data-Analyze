package com.hikvision.hikkan.gbmg.login.dto;

import com.hikvision.hikkan.kcommon.constant.HikkanConstants;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/**
 * Created by liuning9
 * 2019/7/16 11:21
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoginDTO {

    @NotEmpty(message = "name不能为空")
    @ApiModelProperty(value = "账号")
    @Pattern(regexp = HikkanConstants.SPECIAL_CHARACTER_PATTERN, message = "name不能有特殊字符")
    @Length(max = 32, message = "参数name长度不能大于32位")
     private String name;

    @NotEmpty(message = "password不能为空")
    @ApiModelProperty(value = "密码")
    @Pattern(regexp = HikkanConstants.SPECIAL_CHARACTER_PATTERN, message = "password不能有特殊字符")
    @Length(max = 128, message = "参数password长度不能大于128位")
     private String password;

    @ApiModelProperty(value = "productCode", allowEmptyValue = true)
    @Pattern(regexp = HikkanConstants.SPECIAL_CHARACTER_PATTERN, message = "productCode不能有特殊字符")
    @Length(max = 32, message = "参数productCode长度不能大于32位")
     private String productCode;

    @NotNull(message = "用户类型不能为空")
    @ApiModelProperty(value = "type")
     private Integer type = 1;

    @ApiModelProperty(value = "verifyCodeId", allowEmptyValue = true)
    @Pattern(regexp = HikkanConstants.SPECIAL_CHARACTER_PATTERN, message = "verifyCodeId不能有特殊字符")
    @Length(max = 128, message = "参数verifyCodeId长度不能大于128位")
     private String verifyCodeId;

    @ApiModelProperty(value = "expired", allowEmptyValue = true)
     private Integer expired;

    @NotEmpty(message = "挑战码不能为空")
    @ApiModelProperty(value = "codeId")
    @Pattern(regexp = HikkanConstants.SPECIAL_CHARACTER_PATTERN, message = "codeId不能有特殊字符")
    @Length(max = 128, message = "参数codeId长度不能大于128位")
     private String codeId;
}
