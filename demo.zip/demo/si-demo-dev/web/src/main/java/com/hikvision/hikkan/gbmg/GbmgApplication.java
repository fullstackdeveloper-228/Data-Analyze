package com.hikvision.hikkan.gbmg;

import com.hikvision.hikkan.kcommon.annotation.AdviceScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * 垃圾管理服务启动类
 *
 * @author renjie
 * @version 1.0.0
 */
@SpringBootApplication
@EnableAutoConfiguration
@AdviceScan("com.hikvision.hikkan.kcommon.advice")
@EnableAsync
@EnableSwagger2
public class GbmgApplication {

        public static void main(String[] args) throws Exception {
            SpringApplication.run(GbmgApplication.class, args);
        }
}
