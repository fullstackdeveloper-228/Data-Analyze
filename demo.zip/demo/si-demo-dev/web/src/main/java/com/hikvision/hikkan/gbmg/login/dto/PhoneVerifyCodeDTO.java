package com.hikvision.hikkan.gbmg.login.dto;

import com.hikvision.hikkan.kcommon.constant.HikkanConstants;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/**
 * Created by liuning9
 * 2019/7/17 14:32
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PhoneVerifyCodeDTO {

    @ApiModelProperty(value = "productCode", allowEmptyValue = true)
    @Pattern(regexp = HikkanConstants.SPECIAL_CHARACTER_PATTERN, message = "productCode不能有特殊字符")
    @Length(max = 32, message = "参数productCode长度不能大于32位")
    private String productCode;

    @ApiModelProperty(value = "type")
    private Integer type = 1;

    @NotEmpty(message = "phone不能为空")
    @ApiModelProperty(value = "手机号")
    @Pattern(regexp = "^1[0-9]{10}$", message = "phone格式不正确")
    private String phone;
}
