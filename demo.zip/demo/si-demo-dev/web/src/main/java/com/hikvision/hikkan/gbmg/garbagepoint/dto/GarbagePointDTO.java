package com.hikvision.hikkan.gbmg.garbagepoint.dto;

import com.hikvision.hikkan.kcommon.constant.HikkanConstants;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.util.List;

/**
 * Created by liuning9
 * 2019/7/24 9:44
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class GarbagePointDTO {

   /* @Length(max = 32, message = "垃圾点id不能超过32位")
    @ApiModelProperty(value = "垃圾点id")*/
    private Long id;

    @NotEmpty(message = "垃圾点名称不能为空")
    @ApiModelProperty(value = "垃圾点名称")
    @Length(max = 32, message = "垃圾点名称不能超过32位")
    @Pattern(regexp = HikkanConstants.SPECIAL_CHARACTER_PATTERN, message = "垃圾点名称不能有特殊字符")
    private String garbagePointName;

    @ApiModelProperty(value = "垃圾点负责人", allowEmptyValue = true)
    @Length(max = 32, message = "负责人名称不能超过32位")
    @Pattern(regexp = HikkanConstants.SPECIAL_CHARACTER_PATTERN, message = "垃圾点负责人不能有特殊字符")
    private String leadingName;

    @ApiModelProperty(value = "负责人手机号", allowEmptyValue = true)
    @Pattern(regexp = "^[1[0-9]{10}]*$", message = "负责人手机号格式错误")
    private String phoneNo;

    @ApiModelProperty(value = "监控点id", allowEmptyValue = true)
    private List<Long> monitorList;

    @ApiModelProperty(value = "nb设备id", allowEmptyValue = true)
    private List<Long> nbDeviceList;

    @NotNull(message = "组织id不能为空")
    @ApiModelProperty(value = "组织id")
    private Long orgId;
}
