package com.hikvision.hikkan.gbmg.common.constant;

/**
 * Created by liuning9
 * 2019/7/19 10:00
 */
public class RedisConstant {

    /**
     * 项目标识
     */
    private static String GARBAGE = "garbage_";

    /**
     * 网关token的key值
     * @param key
     * @return
     */
    public static String getArtemisToken(String key){
        return GARBAGE + key;
    }

    /**
     * 网关token过期时间
     */
    public static Long ARTEMIS_TOKEN_EXPIRY = 3L;
}
