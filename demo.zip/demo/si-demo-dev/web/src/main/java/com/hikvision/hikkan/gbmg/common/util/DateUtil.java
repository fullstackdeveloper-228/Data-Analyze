package com.hikvision.hikkan.gbmg.common.util;

import com.hikvision.hikkan.gbmg.monitor.service.impl.MonitorServiceImpl;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

/**
 * 日期工具类
 *
 * @author renjie
 * @version 1.0.0
 */
public class DateUtil {
    private static Logger log = LoggerFactory.getLogger(DateUtil.class);
    //云曜标准时间格式
    public static String TIANMU_STANDARD_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS+08:00";
    //视频播放器xml中的时间格式
    public static String PLAY_VIDEO_XML_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss.S";

    public static Long timeStr2TimeLongByFormate(String time, String formate) {
        formate = StringUtils.isEmpty(formate) ? TIANMU_STANDARD_TIME_FORMAT : formate;
        SimpleDateFormat formatter = new SimpleDateFormat(formate);
        if(!Objects.isNull(time)){
            try {
                Date d = formatter.parse(time);
                if(!Objects.isNull(d)){
                    return d.getTime();
                }
            } catch (ParseException e) {
                log.error("parse date error{}", e);
            }
        }
        return null;
    }

    /**
     * date转
     * @param date
     * @param formate
     * @return
     */
    public static String timeDate2TimeStrByFormate(Date date, String formate){
        formate = StringUtils.isEmpty(formate) ? TIANMU_STANDARD_TIME_FORMAT : formate;
        SimpleDateFormat formatter = new SimpleDateFormat(formate);
        date = Objects.isNull(date) ? new Date() : date;
        return formatter.format(date);
    }
}
