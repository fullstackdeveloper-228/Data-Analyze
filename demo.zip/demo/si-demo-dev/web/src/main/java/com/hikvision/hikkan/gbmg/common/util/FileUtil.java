package com.hikvision.hikkan.gbmg.common.util;

import cn.afterturn.easypoi.excel.ExcelExportUtil;
import cn.afterturn.easypoi.excel.ExcelImportUtil;
import cn.afterturn.easypoi.excel.entity.ExportParams;
import cn.afterturn.easypoi.excel.entity.ImportParams;
import cn.afterturn.easypoi.excel.entity.enmus.ExcelType;
import com.hikvision.hikkan.kcommon.enums.ServerCodeEnum;
import com.hikvision.hikkan.gbmg.common.exception.DescribeException;
import com.hikvision.hikkan.gbmg.common.constant.StaticConstant;
import net.coobird.thumbnailator.Thumbnails;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.util.StringUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 文件操作工具类
 *
 * @author renjie
 * @version 1.0.0
 */
public class FileUtil {

    private static final Logger logger = LoggerFactory.getLogger(FileUtil.class);

    private static final String FILEID = "fileId=";

    public static File multipartFile2File(MultipartFile multipartFile){
        File file = null;
        if(!Objects.isNull(multipartFile)){
            InputStream ins = null;
            try {
                ins = multipartFile.getInputStream();
            } catch (IOException e) {
                e.printStackTrace();
            }
            file=new File(createFileName("temp" ,StaticConstant.XLS));
            inputStreamToFile(ins, file);
        }
        return file;
    }

    public static void inputStreamToFile(InputStream ins,File file) {
        try {
            OutputStream os = new FileOutputStream(file);
            int bytesRead = 0;
            byte[] buffer = new byte[8192];
            while ((bytesRead = ins.read(buffer, 0, 8192)) != -1) {
                os.write(buffer, 0, bytesRead);
            }
            os.close();
            ins.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static File exportExcel(List<?> list, String title, String sheetName, Class<?> pojoClass, String fileName){
        Workbook workbook = ExcelExportUtil.exportExcel(new ExportParams(title, sheetName),pojoClass,list);
        File file = new File(fileName);
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(file);
            workbook.write(fos);
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                fos.flush();
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return file;
    }

    public static void exportExcel(List<?> list, String title, String sheetName, Class<?> pojoClass, String fileName, boolean isCreateHeader, HttpServletResponse response){
        ExportParams exportParams = new ExportParams(title, sheetName);
        exportParams.setCreateHeadRows(isCreateHeader);
        defaultExport(list, pojoClass, fileName, response, exportParams);
    }
    public static void exportExcel(List<?> list, String title, String sheetName, Class<?> pojoClass,String fileName, HttpServletResponse response){
        defaultExport(list, pojoClass, fileName, response, new ExportParams(title, sheetName));
    }

    private static void defaultExport(List<?> list, Class<?> pojoClass, String fileName, HttpServletResponse response, ExportParams exportParams) {
        Workbook workbook = ExcelExportUtil.exportExcel(exportParams,pojoClass,list);
        if (workbook != null)
        downLoadExcel(fileName, response, workbook);
    }

    public static void exportExcel(List<Map<String, Object>> list, String fileName, HttpServletResponse response){
        defaultExport(list, fileName, response);
    }
    private static void defaultExport(List<Map<String, Object>> list, String fileName, HttpServletResponse response) {
        Workbook workbook = ExcelExportUtil.exportExcel(list, ExcelType.HSSF);
        if (workbook != null)
        downLoadExcel(fileName, response, workbook);
    }


    private static void downLoadExcel(String fileName, HttpServletResponse response, Workbook workbook) {
        try {
            response.setCharacterEncoding("UTF-8");
            response.setHeader("context-Type", "application/vnd.ms-excel");
            response.setHeader("Content-Disposition",
                    "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8"));
            workbook.write(response.getOutputStream());
        } catch (IOException e) {
            e.printStackTrace();
            throw new DescribeException(e.getMessage(),ServerCodeEnum.SYSTEM_ERROR.getCode());
        }
    }


    public static <T> List<T> importExcel(String filePath,Integer titleRows,Integer headerRows, Class<T> pojoClass){
        List<T> list = new ArrayList<>();
        if (StringUtils.isBlank(filePath)){
            return list;
        }
        ImportParams params = new ImportParams();
        params.setTitleRows(titleRows);
        params.setHeadRows(headerRows);
        try {
            list = ExcelImportUtil.importExcel(new File(filePath), pojoClass, params);
        }catch (NoSuchElementException e){
            throw new DescribeException(ServerCodeEnum.EXCEL_TEMPLATE_CANNOT_BE_NULL);
        }
        return list;
    }
    public static <T> List<T> importExcel(MultipartFile file, Integer titleRows, Integer headerRows, Class<T> pojoClass){
        if (file == null){
            return null;
        }
        ImportParams params = new ImportParams();
        params.setTitleRows(titleRows);
        params.setHeadRows(headerRows);
        List<T> list = null;
        try {
            list = ExcelImportUtil.importExcel(file.getInputStream(), pojoClass, params);
        }catch (NoSuchElementException e){
            throw new DescribeException(ServerCodeEnum.EXCEL_FILE_CANNOT_BE_NULL);
        }catch (Exception e) {
            e.printStackTrace();
            throw new DescribeException(e.getMessage(),ServerCodeEnum.SYSTEM_ERROR.getCode());
        }
        return list;
    }

    /**
     * url文件下载
     * @param fileUrl
     */
    public static File downLoadFromUrl(String fileUrl) {
        //链接url下载图片
            URL url = null;
            int imageNumber = 0;
            if(Objects.isNull(fileUrl)){
                return null;
            }

            try {
                String fileName = null;
                if(fileUrl.contains(FILEID)){
                    String s = fileUrl.split(FILEID)[1];
                    if(StringUtils.isNotEmpty(s)){
                        fileName = s.split(StaticConstant.AND)[0] + StaticConstant.SPOT + StaticConstant.JPG;
                    }
                }
                if(StringUtils.isEmpty(fileName)){
                    fileName = createFileName(StaticConstant.OSD_PATH_CAPTURE,StaticConstant.JPG);
                }

                File file = new File(fileName);
                url = new URL(fileUrl);
                DataInputStream dataInputStream = new DataInputStream(url.openStream());


                FileOutputStream fileOutputStream = new FileOutputStream(file);
                ByteArrayOutputStream output = new ByteArrayOutputStream();

                byte[] buffer = new byte[1024];
                int length;

                while ((length = dataInputStream.read(buffer)) > 0) {
                    output.write(buffer, 0, length);
                }
                byte[] context=output.toByteArray();
                fileOutputStream.write(output.toByteArray());
                dataInputStream.close();
                fileOutputStream.close();
                return file;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
    }

    public static void download(HttpServletResponse response, File file){
        FileInputStream fis = null;
        BufferedInputStream bis = null;
        OutputStream os = null;
        try{
            response.setContentType("application/force-download");// 设置强制下载不打开
            response.addHeader("Content-Disposition", "attachment;fileName=" + file.getName());
            byte[] buffer = new byte[1024];
            fis = new FileInputStream(file);
            bis = new BufferedInputStream(fis);
            os = response.getOutputStream();
            int i = bis.read(buffer);
            while (i != -1) {
                os.write(buffer, 0, i);
                i = bis.read(buffer);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(),e);
            throw new DescribeException(e.getMessage(),ServerCodeEnum.SYSTEM_ERROR.getCode());
        }finally {
            try {
                os.flush();
                os.close();
                bis.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    /**
     * 生成文件名规则（名称 + 时间戳 + 3位随机数 + 后缀）
     * @param pre
     * @param suf
     * @return
     */
    public static String createFileName(String pre, String suf){
        String byTimeAndRandom = createByTimeAndRandom(3);
        return pre + byTimeAndRandom + StaticConstant.SPOT + suf;
    }

    /**
     * 时间戳加n位随机数
     * @param digit
     * @return
     */
    public static String createByTimeAndRandom(int digit){
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss_");
        String time = simpleDateFormat.format(new Date().getTime());
        if(digit < 1){
            return time;
        }
        double pow = Math.pow(10, digit - 1);
        String random = String.valueOf((int) (Math.random() * 9 * pow));
        return time + random;
    }

    /**
     * 生成缩略图
     * @param image
     * @return
     */
    public static File createThumbnail(File image){
        try {
            String thumbnail = image.getAbsolutePath() + "_200x300.jpg";
            Thumbnails.of(image.getAbsolutePath())
                    .size(200, 300)
                    .toFile(thumbnail);
            File thumbnailFile = new File(thumbnail);
            if(thumbnailFile.exists()){
                return thumbnailFile;
            }
        } catch (IOException e) {
            e.printStackTrace();
            logger.error("生成缩略图失败",e);
        }
        return null;
    }
}
