package com.hikvision.hikkan.gbmg.base.domain;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * json格式入参分页类基类
 *
 * @author renjie
 * @version 1.0.0
 */
@Data
public class JsonDtoPageBase {

    @ApiModelProperty(value = "第几页",allowEmptyValue = true)
    private Integer page = 1;

    @ApiModelProperty(value = "每页记录数",allowEmptyValue = true)
    private Integer size = 20;
}
