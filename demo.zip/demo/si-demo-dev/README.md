# 海康云曜上层产品demo工程

> 该工程是为了让上层应用在对接的时候，可以借鉴代码接入的项目工程；其中引用了云曜的sdk组件eits的登陆组件和视频组件；

- demo工程主要由web文件夹和fe文件夹构成；fe表示前端工程，web表示后端工程；

 - 注意该工程绑定的产品标识 productCode为demo，上层产品需要根据自己的产品code，对前后端工程代码配置进行修改；

[云曜sdk使用文档](https://guide-pre.hikyun.com/) 包含前端和后端

## 前端工程

一、 准备工作：
- 1、安装nodejs （如遇后面启动遇到问题可安装v8.11.3版本）
- 2、将npm仓库源改成公司私服，打开cmd，输入以下命令：npm config set registry http://af.hikvision.com.cn/artifactory/api/npm/npm-pbg/
- cd fe 在fe文件根目录输入命令： npm install 等待安装完成

二、 启动本地工程：
```
cd fe
npm run dev
```

打包文件：
```js
cd fe
npm run build // dev研发自测
// npm run build:qa  // 预发布pre
// npm run build:prod // 正式环境prod
```


三、上层应用修改文件配置

### 配置本地访问后端代理

 fe/config/index.js 将dev中的proxyTable的target改为自己的后端地址，然后重新启动npm run dev

### 配置部署的后端HOST
3个文件分别对应3套环境, 开发dev，预发布pre，线上正式环境
 - fe/config/pre.env.js
 - fe/config/qa.env.js
 - fe/config/prod.env.js

#### 字段说明：
 - HOST: 后端的api域名；
 - SSOURL: 对接云曜某环境的对应的租户iframe加载页地址；
 - LOGINURL：云曜遇到401登陆失效的情况下，需要跳转的上层应用登陆地址；


### api接口地址配置文件位置
```
fe/src/api/api.js

```

### 修改配置的产品code

在fe/src/store/modules/user.js中将productCode改成上层应用自己的产品code，该字段应用在登陆组件中


 [参考文档](https://wiki.hikvision.com.cn/pages/viewpage.action?pageId=143723167)

---


## 后端工程
















