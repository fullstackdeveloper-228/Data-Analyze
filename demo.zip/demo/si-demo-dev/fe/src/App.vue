<template>
    <div id="app">
        <router-view></router-view>
    </div>
</template>

<script>
import api from "./api/api.js";
import { mapGetters } from "vuex";
export default {
    name: "App",
    data () {
        return {
        };
    },
    mounted () {
        this.getSkin(this.skin);
    },
    watch: {
        errMsg (cur, old) {
            this.$message({
                showClose: true,
                message: old,
                type: "error",
                duration: 2000
            });
            this.$store.commit("CLR_ERR_MSG");
        }
    },
    computed: {
        ...mapGetters([
            "skin"
        ]),
        errMsg () {
            if (this.$store.state.errMsg !== null) {
                return this.$store.state.errMsg;
            }
        }
    },
    created () {
    },
    methods: {
        getSkin (type) {
            let themeValue = "theme";
            type = type ? type : "0";
            switch (type) {
                case "0":
                    themeValue = "theme";
                    break;
                case "1":
                    themeValue = "theme_red";
                    break;
                default: ;
            };
            let loadLink = (url) => {
                let link = document.createElement("link");
                link.type = "text/css";
                link.rel = "stylesheet";
                link.href = url;
                document.getElementsByTagName('head')[0].appendChild(link);
            };
            if (process.env.NODE_ENV === "development") {
                // require(`../plugins/dolphin/components/${themeValue}/src/index.less`);
                // require(`../static/skin/${themeValue}/index.css`);
                require("../static/reset.css");
            }
            // process.env.NODE_ENV !== "development" && loadLink(`/static/dolphin/${themeValue}/index.css`);
            // process.env.NODE_ENV !== "development" && loadLink(`/static/skin/${themeValue}/index.css`);
            process.env.NODE_ENV !== "development" && loadLink("/static/reset.css");
        }
    }
};
</script>

<style scoped lang="scss">
    #app {
        position: relative;
        width: 100%;
        height: 100%;
    }
</style>

