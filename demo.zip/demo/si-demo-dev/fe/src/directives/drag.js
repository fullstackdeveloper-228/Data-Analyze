let hkDrag = {};
let drag = {
    inserted: (el) => {
        el.onmousedown = function (e) {
            let disX = e.clientX - el.offsetLeft;
            let disY = e.clientY - el.offsetTop;
            document.onmousemove = function (e) {
                let iL = e.clientX - disX;
                let iT = e.clientY - disY;
                let maxL = document.documentElement.clientWidth - el.offsetWidth;
                let maxT = document.documentElement.clientHeight - el.offsetHeight;
                iL <= 0 && (iL = 0);
                iT <= 0 && (iT = 0);
                iL >= maxL && (iL = maxL);
                iT >= maxT && (iT = maxT);
                el.style.left = iL + 'px';
                el.style.top = iT + 'px';
                
                return false;
            };
            document.onmouseup = function () {
                document.onmousemove = null;
                document.onmouseup = null;
            };
        };
    }
};
hkDrag.install = function (Vue) {
    Vue.directive('drag', drag);
};
export default hkDrag;