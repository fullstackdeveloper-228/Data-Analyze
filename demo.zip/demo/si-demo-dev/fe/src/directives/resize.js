let hkResize = Object.create({});
hkResize.install = (Vue, options) => {
    Vue.directive("redraw", {
        bind: (el, binding, vnode) => {
            let width = "", height = "";
            function get () {
                let style = document.defaultView.getComputedStyle(el);
                if (width !== style.width || height !== style.height) {
                    binding.value({width, height});
                }
                width = style.width;
                height = style.height;
            }
            el.__vueReize__ = setInterval(get, 200);
        },
        unbind: (el) => {
            clearInterval(el.__vueReize__);
        }
    });
};


export default hkResize;
