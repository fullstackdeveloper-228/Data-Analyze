<template>
    <div class="main">
        <header class="title">云曜租户集成demo项目</header>
        <el-row type="flex" justify="center" class="main-panel">
            <el-col :span="24" class="panel-content">
                <header>找回密码</header>
                <div class="panel-inner">
                    <eits-forget-pwd
                        :product-code="productCode"
                        @forget-back="forgetBack"
                        :checkPhoneUrl="checkPhoneUrl"
                        :getCodeUrl="getCodeUrl"
                        :checkCodeUrl="checkCodeUrl"
                    >
                    </eits-forget-pwd>
                </div>
            </el-col >
        </el-row>
    </div>
</template>
<script>
export default {
    data () {
        return {
            productCode: this.$store.getters.userInfo.productCode,
            checkPhoneUrl: this.$api.PHONE_STATUS_SDK,
            getCodeUrl: this.$api.PHONE_VERIFY_CODE_SDK,
            checkCodeUrl: this.$api.CHECK_CODE_SDK
        };
    },
    created () {
    },
    computed: {
    },
    methods: {
        forgetBack (payload) {
            this.$router.push({
                name: "resetPassword",
                params: {
                    verifyCode: payload.verifyCode,
                    productCode: payload.productCode,
                    name: payload.phoneNo.replace(/-/g, "")
                }
            });
            // payload里phoneNo改为name
            // this.$router.push({ path: "resetPassword", params: payload });
        }
    }
};
</script>

<style rel="stylesheet/scss" lang="scss" >
    .main {
        width: 100%;
        height: 100%;
        .title {
            width: 100%;
            height: 64px;
            padding-left: 24px;
            background-color: #1B1F22;
            color: #FFFFFF;
            font-size: 24px;
            line-height: 64px;
        }
        .title:before {
            position: relative;
            display: inline-block;
            content: "";
            left: -11px;
            top: 6px;
            width: 60px;
            height: 40px;
            background: url("~@/assets/logo.png") no-repeat 0 -9px;
        }
        .main-panel {
            width: 100%;
            height: calc(100% - 64px);
            background-color: #F2F2F2;
            min-height: 600px;
            display: flex;
            align-items: center;
            .panel-content {
                width: 80%;
                height: 55%;
                min-height: 420px;
                max-width: 1096px;
                max-height: 560px;
                background-color: #FFF;
                padding: 24px 32px;
                header {
                    padding-bottom: 8px;
                    color: #4D4D4D;
                    font-size: 24px;
                    border-bottom: solid 1px #DDD;
                }
                .panel-inner {
                    width: 80%;
                    max-width: 750px;
                    margin: 60px auto 0;
                    form {
                        position: relative;
                        max-width: 420px;
                        margin: 0 auto;
                    }
                }
            }
        }
    }
</style>
