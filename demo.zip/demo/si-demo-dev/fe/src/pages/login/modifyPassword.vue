<template>
    <div class="main">
        <header class="title">云曜租户集成demo项目</header>
        <el-row type="flex" justify="center" class="main-panel">
            <el-col :span="24" class="panel-warp">
                <eits-weak-pwd :token="token" :user="userName" :productCode="productCode" @change-back="changeBack" :changePwdUrl="changePwdUrl" :challengeCodeUrl="challengeCodeUrl"></eits-weak-pwd>
            </el-col>
        </el-row>
    </div>
</template>
<script>
import Token from "@/utils/token";
import store from "@/store";
// 首次登陆或者弱密码强制修改页面
export default {
    data () {
        return {
            userName: this.$store.getters.userInfo.userName || "",
            token: Token.getToken(),
            productCode: this.$store.getters.userInfo.productCode,
            changePwdUrl: this.$api.UPDATE_PWD_SDK,
            challengeCodeUrl: this.$api.CHALLENGE_CODE_SDK
        };
    },
    components: {
    },
    computed: {
    },
    methods: {
        changeBack (payload) {
            if (payload.type === "success") {
                this.$router.push("/login");
                this.$message.success("密码修改成功,请重新登录");
                localStorage.removeItem("eits-login-authorization");
                this.$store.dispatch("DEL_TOKEN");
                this.$store.dispatch("DEL_USER_INFO");
                this.$store.dispatch("DEL_SKIN");
                this.$store.dispatch("CLEAR_VIDEO_VIDEO_VALIDATE_IDS");
            }
        }
    },
    beforeRouteEnter: function (to, from, next){
        if (to.params.forceModifPwd){
            next();
        } else {
            // 页面刷新时登出
            store.dispatch("FedLogOut").then(() => {
                next("/login");
            });
        }
    },
    beforeRouteLeave (to, from, next) {
        // 点击回退按钮时登出
        store.dispatch("FedLogOut").then(() => {
            next();
        });
    }
};
</script>

<style rel="stylesheet/scss" lang="scss" >
    .main {
        width: 100%;
        height: 100%;
        .title {
            width: 100%;
            height: 64px;
            padding-left: 24px;
            background-color: #1B1F22;
            color: #FFFFFF;
            font-size: 24px;
            line-height: 64px;
        }
        .title:before {
            position: relative;
            display: inline-block;
            content: "";
            left: -11px;
            top: 11px;
            width: 60px;
            height: 40px;
            background: url("~@/assets/logo.png") no-repeat 0 -12px;
        }
        .main-panel {
            width: 100%;
            height: calc(100% - 96px);
            min-height: 600px;
            display: flex;
            align-items: center;
            .panel-warp {
                width: 80%;
                height: 50%;
                min-height: 410px;
                max-width: 1096px;
                max-height: 560px;
                background-color: #FFF;
                padding: 24px 32px;
                header {
                    padding-bottom: 8px;
                    color: #4D4D4D;
                    font-size: 24px;
                    border-bottom: solid 1px #DDD;
                    .icon {
                        margin-left: 40px;
                        font-size: 14px;
                        color: #FF4949;
                    }
                    .sub-title {
                        font-size: 14px;
                        color: #999;
                        span {
                            color: #FF4949;
                        }
                    }
                }
                .panel-inner {
                    width: 80%;
                    max-width: 750px;
                    margin: 96px auto 0;
                    form {
                        max-width: 420px;
                        margin: 0 auto;
                        input {
                            font-size: 14px;
                            height: 44px;
                        }
                    }
                }
            }
        }
    }

    .el-popover.newpwd-tip {
        line-height: 20px;
        background: rgba(85, 85, 85, 0.9);
        color: #FFF;
        padding: 10px 10px 10px 30px;
        border: none;
        border-radius: 2px;
        div {
            margin-bottom: 5px;
            color: #989A9C;
        }
        .dissatisfy {
            color: #FFF;
        }
        i {
            float: left;
            margin-left: -18px;
        }
        &.el-popover[x-placement^=top] .popper__arrow {
              bottom: -11px;
              border-top-color: #666;
              &:after {
                  border-top-color: #666;
              }
          }
        &.el-popover[x-placement^=bottom] .popper__arrow {
            bottom: -11px;
            border-bottom-color: #666;
            &:after {
                border-bottom-color: #666;
            }
        }
    }
</style>
