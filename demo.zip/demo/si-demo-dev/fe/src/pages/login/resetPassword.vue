<template>
    <div class="main">
        <header class="title">云曜租户集成demo项目</header>
        <el-row type="flex" justify="center" class="main-panel">
            <el-col :span="24" class="panel-warp">
                <header>重置密码</header>
                <div class="panel-inner">
                    <eits-reset-pwd :challengeCodeUrl="challengeCodeUrl" :changePwdUrl="changePwdUrl" :phoneNo="phoneNo" :productCode="productCode" :verifyCode="verifyCode" @change-back="changeBack"></eits-reset-pwd>
                </div>
            </el-col >
        </el-row>
    </div>
</template>
<script>
import store from "@/store";

export default {
    data () {
        return {
            challengeCodeUrl: this.$api.CHALLENGE_CODE_SDK,
            changePwdUrl: this.$api.CHANGE_PWD_SDK,
            phoneNo: this.$route.params.name,
            productCode: this.$route.params.productCode,
            verifyCode: this.$route.params.verifyCode
        };
    },
    created () {
    },
    computed: {
    },
    methods: {
        changeBack (payload) {
            if (payload.type === "success") {
                this.$router.push({ path: "login" });
            }
        }
    },
    beforeRouteEnter: function (to, from, next) {
        if (to.params.verifyCode || to.params.productCode) {
            next();
        } else {
            store.dispatch("FedLogOut").then(() => {
                next("/pageLogin");
            });
        }
    }
};
</script>

<style rel="stylesheet/scss" lang="scss" >
    .main {
        width: 100%;
        height: 100%;
        .title {
            width: 100%;
            height: 64px;
            padding-left: 24px;
            background-color: #1B1F22;
            color: #FFFFFF;
            font-size: 24px;
            line-height: 64px;
        }
        .title:before {
            position: relative;
            display: inline-block;
            content: "";
            left: -11px;
            top: 6px;
            width: 60px;
            height: 40px;
            background: url("~@/assets/logo.png") no-repeat 0 -9px;
        }
        .main-panel {
            width: 100%;
            height: calc(100% - 96px);
            min-height: 600px;
            display: flex;
            align-items: center;
            .panel-warp {
                width: 80%;
                height: 50%;
                min-height: 410px;
                max-width: 1096px;
                max-height: 560px;
                background-color: #FFF;
                padding: 24px 32px;
                header {
                    padding-bottom: 8px;
                    color: #4D4D4D;
                    font-size: 24px;
                    border-bottom: solid 1px #DDD;
                    .icon {
                        margin-left: 40px;
                        font-size: 14px;
                        color: #FF4949;
                    }
                    .sub-title {
                        font-size: 14px;
                        color: #999;
                        span {
                            color: #FF4949;
                        }
                    }
                }
                .panel-inner {
                    width: 80%;
                    max-width: 750px;
                    margin: 96px auto 0;
                    .eits-reset-pwd {
                        button {
                            height: 44px;
                        }
                    }
                    .el-input__suffix {
                        top: 10px;
                    }
                    form {
                        max-width: 420px;
                        margin: 0 auto;
                        input {
                            font-size: 14px;
                            height: 44px;
                        }
                    }
                }
            }
        }
    }

    .el-popover.newpwd-tip {
        line-height: 20px;
        background: rgba(85, 85, 85, 0.9);
        color: #FFF;
        padding: 10px 10px 10px 30px;
        border: none;
        border-radius: 2px;
        div {
            margin-bottom: 5px;
            color: #989A9C;
        }
        .dissatisfy {
            color: #FFF;
        }
        i {
            float: left;
            margin-left: -18px;
        }
        &.el-popover[x-placement^=top] .popper__arrow {
              bottom: -11px;
              border-top-color: #666;
              &:after {
                  border-top-color: #666;
              }
          }
        &.el-popover[x-placement^=bottom] .popper__arrow {
            bottom: -11px;
            border-bottom-color: #666;
            &:after {
                border-bottom-color: #666;
            }
        }
    }
</style>
