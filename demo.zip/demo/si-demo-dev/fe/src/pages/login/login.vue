<template>
    <div class="login">
        <header class="title">云曜租户集成demo项目</header>
        <div id="login" align="center" class="login-panel" >
            <el-row class="login-row">
                <el-col :span="10"  class="form-col">
                    <div class="form-wrap">
                        <h1>平台登录</h1 >
                        <eits-login
                            @forget-pwd="forgetPwd"
                            @login-back="loginBack"
                            :verifyCodeUrl="verifyCodeUrl"
                            :challengeCodeUrl="challengeCodeUrl"
                            :loginUrl="loginUrl"
                            :phoneNoVerifyUrl="phoneNoVerifyUrl"
                            :changeWeakPwdUrl="changeWeakPwdUrl"
                            :getVerifyUrl="getVerifyUrl"
                            :checkVerifyUrl="checkVerifyUrl"
                            :product-code="productCode"
                        ></eits-login>
                    </div>
                </el-col>
                <el-col :span="14" class="img-col">
                    <div class="img-wrap">
                        <img src="../../assets/login.png" />
                    </div>
                </el-col>
            </el-row>
        </div>
        <div class="footer">© 2019 杭州海康威视系统技术有限公司 | 浙ICP备17026868号-3 </div>
    </div>
</template>

<script>
export default {
    name: "login",
    data () {
        return {
            productCode: this.$store.getters.userInfo.productCode,
            verifyCodeUrl: this.$api.VERIFY_CODE_SDK,
            challengeCodeUrl: this.$api.CHALLENGE_CODE_SDK,
            loginUrl: this.$api.LOGIN_SDK,
            phoneNoVerifyUrl: this.$api.PHONE_STATUS_SDK,
            changeWeakPwdUrl: this.$api.CHANGE_WEAK_PWD,
            getVerifyUrl: this.$api.GET_FORCE_VERIFYPHONENO_VERIFYCODE,
            checkVerifyUrl: this.$api.CHECK_FORCE_VERIFYPHONENO_VERIFYCODE,
            redirect: ""
        };
    },
    computed: {
        btnText () {
            if (this.isBtnLoading) return "登录中...";
            return "登录";
        }
    },
    watch: {
        $route: {
            handler: function (route) {
                if (route.query){
                    this.redirect = route.query.redirect;
                }
            },
            immediate: true
        }
    },
    methods: {
        forgetPwd () {
            this.$router.push({ path: "/forgetPass" });
        },
        loginBack (payload) {
            /* eits v2.x以上处理 */
            console.log(payload);
            if (payload.code === '200') {
                this.$store.commit("SET_TOKEN", payload.data.Authorization);
                this.$router.push({ path: this.redirect || "/" });
            }

            /* eits v2.x以上处理 */

            /* eits v1.0.0以下处理 */
            // if (payload.type === "weak") {
            //     this.$store.commit("SET_TOKEN", payload.token);
            //     this.$router.push({
            //         name: "modifyPassword",
            //         params: {
            //             forceModifPwd: true
            //         }
            //     });
            // }
            // if (payload.type === "success") {
            //     this.$store.commit("SET_TOKEN", payload.token);
            //     this.$router.push({ path: this.redirect || "/" });
            // }
            /* eits v1.0.0以下处理 */
        }
    },
    mounted () {
    }
};
</script>

<style rel="stylesheet/scss" lang="scss" >
    body {
        background-color: white;
    }
    .login {
        width: 100%;
        height: 100%;
        .title {
            width: 100%;
            height: 64px;
            padding-left: 24px;
            background-color: #1B1F22;
            color: #FFFFFF;
            font-size: 24px;
            line-height: 64px;
        }
        .title:before {
            position: relative;
            display: inline-block;
            content: "";
            left: -11px;
            top: 11px;
            width: 60px;
            height: 40px;
            background: url("~@/assets/logo.png") no-repeat 0 -12px;
        }
        .login-panel {
            height: calc(100% - 120px);
            min-height: 500px;
            background-color: white;
            display: flex;
            align-items: center;
            .login-row {
                width: 100%;
                height: 480px;
                .form-col {
                    height: 100%;
                    border-right: solid 1px #DDD;
                    padding: 0 40px;
                }
                .form-wrap {
                    float: right;
                    width: 100%;
                    max-width: 404px;
                    padding: 16px 32px;
                    h1 {
                        text-align: left;
                        font-size: 24px;
                        font-weight: normal;
                        line-height: 40px;
                        margin-bottom: 12px;
                    }
                    .login-btn {
                        width: 100%;
                        max-width: 340px;
                        height: 44px;
                        font-size: 14px;
                        font-weight: normal;
                        button {
                            height: 44px;
                        }
                    }
                }
                .img-col {
                    height: 100%;
                    display: flex;
                    align-items: center;
                }
                .img-wrap {
                    width: 100%;
                    max-width: 707px;
                    margin-left: 40px;
                    img {
                        width: 100%;
                        height: 100%;
                    }
                }
            }
        }
        .footer {
            height: 56px;
            width: 100%;
            text-align: center;
            font-size: 14px;
            color: #777;
            background: #EEE;
            line-height: 56px;
        }
    }


</style>
