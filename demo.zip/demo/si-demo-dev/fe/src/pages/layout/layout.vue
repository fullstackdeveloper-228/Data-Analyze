<template>
    <h-layout v-if="menuShow">
        <h-layout-header class="t-layout-header">
            <t-header :menu="menuData" :project-data="projectData"></t-header>
        </h-layout-header>
        <h-page class="t-page">
            <h-page-menu :menu="menuData" class="m-menu-tainmu"></h-page-menu>
            <h-layout-content><router-view></router-view></h-layout-content>
        </h-page>
    </h-layout>
    <h-layout v-else>
        <h-page>
            <h-layout-content>
                <keep-alive include="ProjectIndex,SubIndex">
                    <router-view ref="layout"></router-view>
                </keep-alive>
            </h-layout-content>
        </h-page>
    </h-layout>
</template>

<script>
import { generateMenu } from "./../../config/menu.js";
import tHeader from "@/components/t-header/src/t-header.vue";
import api from "./../../api/api.js";

export default {
    name: "layout",
    data () {
        return {
            menuData: null
        };
    },
    components: {
        tHeader
    },
    computed: {
        menuShow () {
            return true;
        },
        projectData () {
            let obj = {
                logo: this.$store.state.user.logo || require("@/assets/logo.png"),
                title: this.$store.state.user.title || "海康云曜"
            };
            return obj;
        }
    },
    mounted () {
        // if (this.$store.getters.token) {
        //     this.$store.dispatch("GetExpireInfo").then((res) => {

        //     }).catch((err) => {
        //         this.$message.error(res.msg);
        //     });
        // }
    },
    created () {
        // 菜单权限处理
        if (this.menuShow){
            this.menuData = generateMenu(this.$store.getters.userInfo);
        }
    },
    methods: {
        handleCollapse (obj) {
            this.$store.commit("SET_MENU_ISCOLLAPSE", obj);
        }
    }
};
</script>
<style scoped lang="scss">
    .t-layout-header {
        position: fixed;
        width: 100%;
        height: 36px;
        line-height: 36px;
        background: #1B1F22;
    }
    .t-page {
        height: calc(100vh - 36px);
        margin-top: 36px;
    }
</style>
