 <template>
    <h-page-container class="point-add">
        <h-page-header slot="pageHeader" :breadcrumb="breadCrumbs" return-icon></h-page-header>
        <el-scrollbar wrap-class="page-scrollbar__wrap" @on-scrollbar-x="changeScrollBarX">
            <h-page-content flex align-center class="t-content-main">
                <div class="form_style__three">
                    <h-page-group title="基本信息" class="form-container">
                        <el-form ref="addForm" :model="addForm" label-position="top" label-width="100px"  :rules="rules">
                            <el-form-item label="垃圾点名称" prop="garbagePointName">
                                <el-input v-model="addForm.garbagePointName" placeholder="请输入垃圾点名称"></el-input>
                            </el-form-item>
                            <el-form-item label="负责人" prop="leadingName">
                                <el-input v-model="addForm.leadingName" placeholder="请输入负责人姓名"></el-input>
                            </el-form-item>
                            <el-form-item label="联系方式" prop="phoneNo">
                                <el-input v-model="addForm.phoneNo" placeholder="请输入11位手机号"></el-input>
                            </el-form-item>
                        </el-form>
                    </h-page-group>
                    <h-page-group title="资源信息" class="tab-container">
                        <el-tabs v-model="activeTab">
                            <el-tab-pane label="监控点" name="first">
                                <div class="tree-container">
                                    <div class="choose-right-container right-item">
                                        <div class="resource-title">
                                            <label class="label-t">组织列表</label>
                                        </div>
                                        <div class="tree-wrap hg1">
                                            <el-tree
                                                :data="tabTreeData"
                                                :default-expanded-keys="expandKeys"
                                                node-key="id"
                                                ref="monitorTree"
                                                :check-strictly="true"
                                                @current-change="setOrgTree"
                                                :scroll-size="8"
                                                default-icon="d-icon-base-tree"
                                                >
                                            </el-tree>
                                        </div>
                                    </div>
                                    <div class="choose-right-container right-item-middle">
                                        <div class="resource-title">
                                            <label class="label-t">监控点列表</label>
                                            <label class="help-info">
                                                <el-checkbox label="包含下级" v-model="containChildren" @change="initTree"></el-checkbox>
                                            </label>
                                        </div>
                                        <el-input
                                            slot="searchContent"
                                            v-model="treeSearchKey"
                                            :placeholder="'请输入名称/序列号'"
                                            clearable
                                            :clear-icon-click="clearMonitorTree"
                                            class="filter-tree-input"
                                            @keyup.enter.native="getMonitor"
                                            >
                                        </el-input>
                                        <div class="tree-wrap hg2">
                                            <el-checkbox-group class="operate-group" v-model="checkedMonitorIds">
                                                <el-checkbox v-for="item in monitors" :disabled="item.occupiedByPoint" :label="item.id" :key="item.id" class="device-item" @change="monitorCheckboxChange">{{item.monitorName}}</el-checkbox>
                                            </el-checkbox-group>
                                            <div class="pagination-wrap">
                                                <el-pagination
                                                    small
                                                    layout="prev, pager, next"
                                                    @current-change="monitorPageChange"
                                                    :page-size="monitorPage.pageSize"
                                                    :current-page="monitorPage.pageNo"
                                                    :total="monitorPage.total">
                                                </el-pagination>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="choose-right-container right-item-last">
                                        <div class="resource-title">
                                            <label class="label-t">已选监控点</label>
                                        </div>
                                        <div class="tree-wrap hg1">
                                            <el-scrollbar wrap-class="page-scrollbar__wrap" :size="8">
                                                <el-checkbox-group class="operate-group" v-model="checkedMonitorIds">
                                                    <el-checkbox v-for="item in checkedMonitorsList" :label="item.id" :key="item.id" class="device-item" @change="monitorCheckboxChange">{{item.monitorName}}</el-checkbox>
                                                </el-checkbox-group>
                                            </el-scrollbar>
                                        </div>
                                    </div>
                                </div>
                            </el-tab-pane>
                            <el-tab-pane label="NB设备" name="second">
                                <div class="tree-container">
                                    <div class="choose-right-container right-item">
                                        <div class="resource-title">
                                            <label class="label-t">组织列表</label>
                                        </div>
                                        <div class="tree-wrap hg1">
                                            <el-tree
                                                :data="tabTreeData"
                                                :default-expanded-keys="expandKeys"
                                                node-key="id"
                                                ref="nbTree"
                                                :check-strictly="true"
                                                @current-change="setOrgTree"
                                                :scroll-size="8"
                                                default-icon="d-icon-base-tree"
                                                >
                                            </el-tree>
                                        </div>
                                    </div>
                                    <div class="choose-right-container right-item-middle">
                                        <div class="resource-title">
                                            <label class="label-t">NB设备列表</label>
                                            <label class="help-info">
                                                <el-checkbox label="包含下级" v-model="containNbChildren" @change="initTree"></el-checkbox>
                                            </label>
                                        </div>
                                        <el-input
                                            slot="searchContent"
                                            v-model="nbSearchKey"
                                            :placeholder="'请输入名称/序列号'"
                                            clearable
                                            :clear-icon-click="clearNbTree"
                                            class="filter-tree-input"
                                            @keyup.enter.native="getNbDevice"
                                            >
                                        </el-input>
                                        <div class="tree-wrap hg2">
                                            <el-checkbox-group class="operate-group" v-model="checkedNbIds">
                                                <el-checkbox v-for="item in nbDevices" :disabled="item.occupiedByPoint" :label="item.id" :key="item.id" class="device-item" @change="nbCheckboxChange">{{item.deviceName}}</el-checkbox>
                                            </el-checkbox-group>
                                            <div class="pagination-wrap">
                                                <el-pagination
                                                    small
                                                    layout="prev, pager, next"
                                                    @current-change="nbPageChange"
                                                    :page-size="nbPage.pageSize"
                                                    :current-page="nbPage.pageNo"
                                                    :total="nbPage.total">
                                                </el-pagination>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="choose-right-container right-item-last">
                                        <div class="resource-title">
                                            <label class="label-t">已选NB设备</label>
                                        </div>
                                        <div class="tree-wrap hg1">
                                            <el-scrollbar wrap-class="page-scrollbar__wrap" :size="8">
                                                <el-checkbox-group class="operate-group" v-model="checkedNbIds">
                                                    <el-checkbox v-for="item in checkedNbList" :label="item.id" :key="item.id" class="device-item" @change="nbCheckboxChange">{{item.deviceName}}</el-checkbox>
                                                </el-checkbox-group>
                                            </el-scrollbar>
                                        </div>
                                    </div>
                                </div>
                            </el-tab-pane>
                        </el-tabs>
                    </h-page-group>
                    <h-page-footer inner-width="1350px" :class="{'scrollbar-x':isScrollBarX}">
                        <el-button type="primary" @click="haveSave(1)" class="btn-wd" :loading="btnFlag">保存</el-button>
                        <el-button @click="haveSave">保存并继续添加</el-button>
                        <el-button class="btn-wd" @click="cancelAdd">取消</el-button>
                    </h-page-footer>
                </div>
            </h-page-content>
        </el-scrollbar>
    </h-page-container>
</template>

<script>
export default {
    name: "PointAdd",
    props: {
        crumbs: {
            type: Array,
            debufult: []
        }
    },
    data () {
        let self = this;
        let checkSerail = (rule, value, callback) => {
            if (!this.$hkReg.illegalChar.test(value)) {
                callback(new Error(this.$msgTxt.ILLLEGAL_CHAR_TXT));
            } else {
                callback();
            }
        };
        let checkPhoneNo = (rule, value, callback) => {
            if (value !== "") {
                if (!this.$hkReg.phoneNum.test(value)) {
                    callback(new Error("手机号码输入有误"));
                } else {
                    callback();
                }
            } else {
                callback();
            }
        };
        return {
            rules: {
                garbagePointName: [
                    { required: true, message: "请输入垃圾点名称", trigger: "blur"},
                    { min: 1, max: 32, message: "长度在1-32个字符或汉字", trigger: "blur"},
                    { validator: checkSerail, trigger: "blur"}
                ],
                phoneNo: [
                    { validator: checkPhoneNo, trigger: "blur" }
                ],
                leadingName: [
                    { min: 1, max: 32, message: "长度在1-32个字符或汉字", trigger: "blur"},
                    { validator: checkSerail, trigger: "blur"}
                ]
            },
            containChildren: true,
            containNbChildren: true,
            treeSearchKey: "",
            nbSearchKey: "",
            monitors: [],
            checkedMonitorIds: [],
            checkedMonitorsList: [],
            nbDevices: [],
            checkedNbIds: [],
            checkedNbList: [],
            addForm: {
                garbagePointName: "",
                leadingName: "",
                phoneNo: ""
            },
            monitorPage: {
                pageNo: 1,
                pageSize: 10,
                total: 0
            },
            nbPage: {
                pageNo: 1,
                pageSize: 10,
                total: 0
            },
            activeTab: "first",
            tabTreeData: [],
            expandKeys: [],
            currentOrgId: "",
            btnFlag: false,
            orgId: this.$route.query.orgid,
            isScrollBarX: false
        };
    },
    created () {
        this.initTree();
    },
    watch: {
    },
    computed: {
    },
    methods: {
        changeScrollBarX (isSowX) {
            this.isScrollBarX = isSowX;
        },
        initTree () {
            this.$http({
                method: "post",
                url: this.$api.GET_ORG_TREE
            }).then((res) => {
                this.tabTreeData = res.data;
                this.currentOrgId = res.data[0].id;
                this.expandKeys.push(res.data[0].id); 
                this.getMonitor(res.data[0].id); 
                this.getNbDevice(res.data[0].id);
                this.$nextTick(() => {
                    this.$refs.monitorTree.setCurrentKey(res.data[0].id);
                    this.$refs.nbTree.setCurrentKey(res.data[0].id);
                });
            });
        },
        getMonitor (id) {
            id = typeof id === "string" ? id : this.currentOrgId;
            this.$http({
                method: "post",
                url: this.$api.GET_MONITOR_PAGE,
                data: {
                    deviceOrgId: id,
                    page: this.monitorPage.pageNo,
                    size: this.monitorPage.pageSize,
                    containAllChildren: this.containChildren,
                    allocationStatus: "",
                    model: "",
                    nameOrSerialOrDeviceName: this.treeSearchKey,
                    onlineStatus: ""
                }
            }).then((res) => {
                if (res.code === "200"){
                    this.monitors = res.data.list;
                    this.monitorPage.total = res.data.total;
                } else {
                    this.$message.error(res.msg);
                }
            }).catch((e) => {
                console.log(e);
            });
        },
        getNbDevice (id) {
            id = typeof id === "string" ? id : this.currentOrgId;
            this.$http({
                method: "post",
                url: this.$api.GET_NB_PAGE,
                data: {
                    deviceOrgId: id,
                    page: this.nbPage.pageNo,
                    size: this.nbPage.pageSize,
                    containAllChildren: this.containNbChildren,
                    deviceNameOrSerial: this.nbSearchKey
                }
            }).then((res) => {
                if (res.code === "200"){
                    this.nbDevices = res.data.list;
                    this.nbPage.total = res.data.total;
                } else {
                    this.$message.error(res.msg);
                }
            }).catch((e) => {
                console.log(e);
            });
        },
        setOrgTree (data, node) {
            this.currentOrgId = data.id;
            if (this.activeTab === "first") {
                this.getMonitor(data.id);
            } else {
                this.getNbDevice(data.id);
            }
        },
        monitorPageChange (val, oldVal) {
            this.monitorPage.pageNo = val;
            this.getMonitor(this.currentOrgId);
        },
        nbPageChange (val, oldVal) {
            this.nbPage.pageNo = val;
            this.getNbDevice(this.currentOrgId);
        },
        cancelAdd () {
            this.$router.push({ path: "/res/point/list"});
        },
        haveSave (flag) {
            this.btnFlag = true;
            this.$refs.addForm.validate((valid) => {
                if (valid) {
                    this.onSubmit(flag);
                } else {
                    this.btnFlag = false;
                    return false;
                }
            });
        },
        onSubmit (flag) {
            let data = {
                orgId: this.orgId,
                garbagePointName: this.addForm.garbagePointName,
                leadingName: this.addForm.leadingName,
                phoneNo: this.addForm.phoneNo,
                monitorList: this.checkedMonitorIds,
                nbDeviceList: this.checkedNbIds
            };
            this.$http({
                method: "post",
                url: this.$api.MOD_POINT,
                data: data
            }).then((res) => {
                if (res.code === "200"){
                    this.$message.success("添加成功");
                    this.btnFlag = false;
                    this.resetPage();
                    if (flag === 1){
                        setTimeout(()=>{
                            this.$router.push({ path: "/res/point/list"});
                        }, 1000);
                    } else {
                        setTimeout(()=>{
                            this.$router.push({ path: `/res/point/add?orgid=${this.orgId}`});
                        }, 1000);
                    }
                } else {
                    this.btnFlag = false;
                    this.$message.error(res.msg);
                }
            }).catch((err) => {
                this.btnFlag = false;
            });
        },
        // 选中或者取消某个监控点
        monitorCheckboxChange (isCheck, e) {
            let v = e.target.value;
            if (isCheck){
                let monitorName = this.monitors.filter(({ id }) => id === v)[0].monitorName;
                let obj = Object.assign({}, { id: v }, { monitorName: monitorName});
                this.checkedMonitorsList.push(obj);
            } else {
                this.checkedMonitorsList = this.checkedMonitorsList.filter(({ id }) => id !== v);
            }
        },
        // 选中或者取消某个NB设备
        nbCheckboxChange (isCheck, e) {
            let v = e.target.value;
            if (isCheck){
                let deviceName = this.nbDevices.filter(({ id }) => id === v)[0].deviceName;
                let obj = Object.assign({}, { id: v }, { deviceName: deviceName});
                this.checkedNbList.push(obj);
            } else {
                this.checkedNbList = this.checkedNbList.filter(({ id }) => id !== v);
            }
        },
        clearMonitorTree () {
            this.treeSearchKey = "";
            this.getMonitor();
        },
        clearNbTree () {
            this.nbSearchKey = "";
            this.getNbDevice();
        },
        resetPage () {
            this.$refs["addForm"].resetFields();
            this.$refs["addForm"].resetValidates();
            this.treeSearchKey = "";
            this.nbSearchKey = "";
            this.checkedMonitorIds = [];
            this.checkedNbIds = [];
            this.monitors = [];
            this.nbDevices = [];
            this.initTree();
        }
    }
};
</script>
<style lang="scss" scoped>
.point-add {
    .title {
        height: 40px;
        line-height: 40px;
        width: 100%;
        padding-left: 16px;
        border-bottom: 1px solid #E6E6E6;
    }
    .form-container {
        width: 480px;
    }
    .tab-container {
        width: 1000px;
    }
    .tree-container {
        padding: 16px;
        text-align: center;
        .choose-label {
            display: inline-block;
            height: 100%;
            width: 100px;
            text-align: right;
            vertical-align: top;
        }
        .choose-right-container {
            display: inline-block;
            vertical-align: top;
            width: 282px;
            height: 440px;
            border: 1px solid #DDD;
            overflow: hidden;
            text-align: left;
            .resource-title {
                position: relative;
                background-color: #FAFAFA;
                height: 36px;
                line-height: 36px;
                padding-left: 12px;
                border-bottom: 1px solid #DDD;
                .label-t {
                    font-weight: 600;
                }
            }
            .help-info {
                font-weight: 300;
                cursor: pointer;
                position: absolute;
                right: 10px;
            }
            .filter-tree-input {
                width: 270px;
                margin: 5px;
            }
        }
        .right-item {
            border-right: none;
        }
        .right-item-middle {
            position: relative;
            left: -5px;
        }
        .right-item-last {
            margin-left: 72px;
        }
        .tree-wrap {
            margin: 0 auto;
            width: 280px;
            .pagination-wrap {
                position: absolute;
                bottom: 5px;
                left: 50%;
                transform: translateX(-50%);
            }
        }
        .hg1 {
            height: 402px;
        }
        .hg2 {
            height: 360px;
        }
        .operate-group {
            display: flex;
            flex-direction: column;
            .el-checkbox {
                margin-left: 16px;
            }
            .device-item {
                padding: 4px 0;
            }
        }
    }
    .btn-container {
        width: 100%;
        background-color: #FFFFFF;
        padding: 8px 0;
        text-align: center;
        border: 1px solid #E6E6E6;
        border-bottom: none;
        .btn-wd {
            width: 96px;
        }
    }
}
</style>
