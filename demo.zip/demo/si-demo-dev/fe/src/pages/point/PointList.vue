<template>
    <h-page-container class="user-management-user">
        <h-page-header slot="pageHeader" :breadcrumb="breadCrumbs" return-icon></h-page-header>
        <!-- 左侧树 -->
        <h-layout>
            <h-layout-aside>
                <t-tree>
                    <el-input
                        slot="searchContent"
                        v-model="treeSearchKey"
                        :placeholder="'请输入搜索内容'"
                        clearable
                        :clear-icon-click="handleClearTree"
                        class="filter-tree-input"
                        @keyup.enter.native="handleSearchTree"
                        >
                    </el-input>
                    <el-tree
                        slot="sidebarTree"
                        ref="orgTree"
                        :data="treeData"
                        node-key="id"
                        default-icon="d-icon-base-tree"
                        :scroll-size="8"
                        :filter-node-method="filterNode"
                        @current-change="handleCurrentChange"
                        :default-expanded-keys="expandKeys"
                    >
                    </el-tree>
                </t-tree>
            </h-layout-aside>
            <h-layout>
                <t-page-table :isSearchIcon="true">
                    <template slot="hPageAction">
                        <el-button type="iconButton" icon="h-icon-add" @click="handleClickAdd">添加</el-button>
                        <el-button type="iconButton" icon="h-icon-delete" @click="handleClickDel">删除</el-button>
                    </template>
                    <template slot="rightAction">
                        <el-checkbox v-model="obtainChild" @change="getPointList">包含下级组织</el-checkbox>
                    </template>
                    <h-page-search slot="hPageSearch" :model="filterForm" ref="filterForm" :rules="rules">
                        <h-page-search-item label="关键字" prop="keyWord">
                            <el-input v-model="filterForm.keyWord" placeholder="请输入" clearable  @keyup.enter.native="getPointList"></el-input>
                        </h-page-search-item>
                        <template slot="pageSearchAction">
                            <el-button type="primary" @click="getPointList">查询</el-button>
                            <el-button @click="resetSearch()">重置</el-button>
                        </template>
                    </h-page-search>
                    <template slot="hPageTable">
                        <el-table ref="multipleTable" :data="tableData" force-scroll show-overflow-title @selection-change="handleSelectionChange">
                            <div slot="empty" class="emptyDefault" v-if="isEmpty === 1">
                                <div class="defaultImg">
                                    <img src="../../assets/noresult.png" v-if="queryLock" />
                                    <img src="../../assets/empty.png" v-else />
                                </div>
                                <div class="defaultTxt">{{queryLock ? this.$msgTxt.NO_FIND_DATA : this.$msgTxt.NO_RESULT_DATA}}</div>
                            </div>
                            <el-table-column type="selection" min-width="40"></el-table-column>
                            <el-table-column type="index" label="序号" width="60">
                                <template slot-scope="scope">
                                    {{(scope.$index + 1) + (pageNo - 1) * pageSize}}
                                </template>
                            </el-table-column>
                            <el-table-column prop="garbagePointName" label="垃圾点名称" min-width="120"></el-table-column>
                            <el-table-column prop="groupName" label="组织名称" min-width="120"></el-table-column>
                            <el-table-column prop="leadingName" label="负责人" width="120"></el-table-column>
                            <el-table-column prop="phoneNo" label="手机号" min-width="120"></el-table-column>
                            <el-table-column label="操作" width="150">
                                <template slot-scope="scope">
                                    <div class="page-table-operate">
                                        <el-button type="iconButton" @click="pointEdit(scope.row.id)" icon="h-icon-edit" title="编辑"></el-button>
                                    </div>
                                </template>
                            </el-table-column>
                        </el-table>   
                    </template>
                    <el-pagination
                        slot="pagination"
                        @size-change="handleSizeChange"
                        @current-change="handlePageChange"
                        :current-page="pageNo"
                        :page-sizes="[10, 20, 50, 100]"
                        :page-size="pageSize"
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="total">
                    </el-pagination>
                </t-page-table>
            </h-layout>
        </h-layout>
    </h-page-container>
</template>

<script>
export default {
    name: "PointList",
    components: {
    },
    props: {
        crumbs: {
            type: Array,
            debufult: []
        }
    },
    data () {
        let checkSerail = (rule, value, callback) => {
            if (!this.$hkReg.illegalChar.test(value)) {
                callback(new Error(this.$msgTxt.ILLLEGAL_CHAR_TXT));
            } else {
                callback();
            }
        };
        return {
            rules: {
                keyWord: [
                    { validator: checkSerail, trigger: "blur"}
                ]
            },
            loading1: true,
            loading2: true,
            queryLock: false,
            curPointOrgId: '',
            treeData: [],
            treeSearchKey: "",
            expandKeys: [],
            tableData: [],
            obtainChild: true,
            filterOpen: false,
            filterForm: {
                keyWord: ""
            },
            pageNo: 1,
            pageSize: 20,
            total: 0,
            isEmpty: 0,
            multipleSelection: []
        };
    },
    created () {
        this.getTree();
    },
    watch: {
        treeSearchKey (val) {
            this.$refs.orgTree.filter(val);
        },
        "filterForm.keyWord": {
            deep: true,
            handler: function (val){
                if (val === ""){
                    this.getPointList();
                }
            }
        }
    },
    computed: {
        isQuery () {
            return !(this.filterForm.keyWord === "");
        }
    },
    methods: {
        // 树相关
        getTree () {
            this.loading2 = true;
            this.$http({
                method: "post",
                url: this.$api.GET_ORG_TREE
            }).then((res) => {
                this.loading2 = false;
                this.curPointOrgId = res.data[0].id;
                this.getPointList();
                this.treeData = res.data;
                this.$nextTick(() => {
                    this.$refs.orgTree.setCurrentKey(res.data[0].id);
                    this.expandKeys.push(this.treeData[0].id);
                });
            }).catch((err) => {
                this.loading2 = false;
            });
        },
        filterNode (value, data) {
            if (!value) return true;
            return data.label.indexOf(value) !== -1;
        },
        handleSearchTree () {
            this.$refs.orgTree.filter(this.treeSearchKey);
        },
        handleClearTree () {
            this.treeSearchKey = "";
            this.handleSearchTree();
        },
        handleCurrentChange (data, node) {
            this.curPointOrgId = data.id;
            this.obtainChild = true;
            this.filterOpen = false;
            this.resetSearch(true);
            // this.filterForm.keyWord = '';
            // this.getPointList();
        },
        // 垃圾点列表
        getPointList () {
            this.loading1 = true;
            this.isEmpty = 0;
            this.queryLock = this.isQuery ? true : false;
            this.$http({
                method: "post",
                url: this.$api.GET_POINT_LIST,
                data: {
                    orgId: this.curPointOrgId,
                    keyWord: this.filterForm.keyWord,
                    obtainChild: this.obtainChild,
                    pageNo: this.pageNo,
                    pageSize: this.pageSize
                }
            }).then((res) => {
                if (res.data && res.data.list.length > 0) {
                    this.tableData = res.data.list;
                    this.total = res.data.total;
                } else {
                    this.tableData = [];
                    this.total = 0;
                    this.isEmpty = 1;
                }
                this.loading1 = false;
            }).catch((err) => {
                this.isEmpty = 1;
                this.loading1 = false;
            });
        },
        resetSearch (flag) {
            this.filterForm.keyWord = '';
            if (flag) {
                this.getPointList();
            }
        },
        pointEdit (id) {
            this.$router.push({path: "/res/point/edit", query: {id: id}});
        },
        handleClickAdd () {
            this.$router.push({
                path: "/res/point/add",
                query: {
                    orgid: this.curPointOrgId
                }
            });
        },
        handleClickDel () {
            if (this.multipleSelection.length){
                let selectedArr = this.multipleSelection.map((v, i) => v.id);
                this.$confirm(`确认删除选中的${selectedArr.length}个垃圾点吗?`, `提示`, {
                    confirmButtonText: "确定",
                    cancelButtonText: "取消",
                    type: "question"
                }).then(() => {
                    this.$http({
                        method: "post",
                        url: this.$api.DEL_POINT,
                        data: {
                            ids: selectedArr
                        }
                    }).then((res) => {
                        this.$message.success(`已删除${selectedArr.length}个垃圾点`);
                        this.pageNo = 1;
                        this.getPointList();
                    }).catch((err) => {
                        console.log(err);
                    });
                }).catch((err) => {
                    console.log(err);
                });
            } else {
                this.$message.warning(`请选择需要删除的垃圾点`);
            }
        },
        handleSelectionChange (val) {
            this.multipleSelection = val;
        },
        /* 分页相关 */
        handleSizeChange (val, oldVal) {
            this.pageSize = val;
            this.pageNo = 1;
            this.getPointList();
        },
        handlePageChange (val, oldVal) {
            this.pageNo = val;
            this.getPointList();
        }
    }
};
</script>
<style lang="scss">
    .page-table-operate {
        margin-left: -8px;
    }
    .filter-form {
        padding: 24px 16px 0 16px;
        background-color: #FBFBFB;
        border-top: 1px solid #E6E6E6;
        .right {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            margin-bottom: 24px;
            .longbtn {
                width: 96px;
            }
        }
    }
    .point-list-main {
        height: 100%;
        overflow: hidden;
        position: relative;
        padding: 0 16px;
        .page-card-toolbar {
            border-bottom: 0;
            background-color: #FFFFFF;
            .right {
                display: flex;
                justify-content: flex-end;
                flex-wrap: nowrap;
                align-items: center;
            }
        }
        .user-table {
            position: relative;
            height: 100%;
            .table-content {
                width: 100%;
                height: calc(100% - 48px);
                .emptyDefault {
                    position: relative;
                    width: 240px;
                    height: 240px;
                    .defaultImg {
                        width: 240px;
                        height: 200px;
                        img {
                            width: 240px;
                            height: 200px;
                        }
                    }
                    .defaultTxt {
                        font-size: 14px;
                        color: #4C4C4C;
                    }
                }
                .el-table {
                    height: 100%;
                }
            }
            .table-page {
                .m-page {
                    position: absolute;
                    bottom: 0;
                    width: 100%;
                    left: 0;
                    right: 0;
                }
            }
        }
        .user-status {
            display: inline-block;
            width: 12px;
            height: 12px;
            margin-right: 2px;
            &.open {
                background: url("../../assets/icon/open1.png") no-repeat 0 1px;
            }
            &.close {
                background: url("../../assets/icon/open0.png") no-repeat 0 1px;
            }
        }
    }
    .select-tree-wrap {
        width: 100%;
        height: 500px;
    }
</style>
