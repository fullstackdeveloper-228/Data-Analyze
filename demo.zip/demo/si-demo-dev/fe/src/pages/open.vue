<template>
    <div>
        <div>这是测试跳租户页面</div>
        <div>地址: {{domain}}</div>
        <div>打开console，查看租户PostMessage返回的消息</div>
    </div>
</template>

<script>
import { mapGetters } from "vuex";
export default {
    name: "OpenPage",
    components: {},
    props: {
        crumbs: {
            type: Array,
            default: () => []
        }
    },
    data () {
        return {
            domain: 'https://zh-pre.hikyun.com',
            // domain: 'https://10.17.82.15:2018',
            timer: null
        };
    },
    mounted () {
        this.OpenNewWindow();
        // 监听消息反馈
        window.addEventListener('message', this.listenReceive, false);
    },
    watch: {
    },
    computed: {
        ...mapGetters([
            "token"
        ])
    },
    methods: {
        OpenNewWindow () {
            let data = {
                type: "settings",
                data: {
                    path: '/',
                    crumbs: this.crumbs,
                    loginUrl: process.env.LOGINURL,
                    showMenu: true,
                    skin: 1, // 0 是蓝白 1：红白
                    token: this.$utils.getToken(),
                    productCode: 'demo'
                }
            };
            let myPopup = window.open(this.domain + "/sso");
            this.timer = setInterval(() => {
                console.log(data);
                myPopup.postMessage(data, this.domain);
            }, 1000);
        },
        listenReceive (event) {
            console.log(event.origin);
            if (event.origin !== this.domain) return;
            clearInterval(this.timer);
            this.timer = null;
            console.log('received response:  ', event);
        }
    },
    beforeDestroy () {
        window.removeEventListener('message', this.listenReceive);
        clearInterval(this.timer);
        this.timer = null;
    }
};
</script>
