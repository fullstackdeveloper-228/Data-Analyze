<template>
    <div class="mask-wrap">
        <div class="left-wrap" ref="leftWrap">
            <img :src="item.enUrl" ref="bigImg" @load="loadImg(item.enUrl)"/>
            <div class="small-img-wrap" v-if="item.exThumbnailUrl">
                <img class="enter-img" :class="{' cur-img': type == 0}" :src="item.enThumbnailUrl" @click="showBigImg(0)"/>
                <img class="out-img" :class="{' cur-img': type == 1}" :src="item.exThumbnailUrl" @click="showBigImg(1)"/>
                <span class="img-txt enter-txt">进</span>
                <span class="img-txt out-txt">出</span>
            </div>
        </div>
        <div class="right-wrap">
            <div class="close-wrap" @click="changeFlag"></div>
            <ul ref="cameraInfo">
                <li>
                    <label>监控点名称：</label>
                    <label>{{item.monitorName}}</label>
                </li>
                <li>
                    <label>监控点编号：</label>
                    <label>{{item.monitorSerial}}</label>
                </li>
                <li>
                    <label>所属组织：</label>
                    <label>{{item.deviceOrgName}}</label>
                </li>
                <li>
                    <label>在线状态：</label>
                    <label v-if="item.onlineStatus==1"><i class="camera-status online-status"></i>在线</label>
                    <label v-else><i class="camera-status offline-status"></i>离线</label>
                </li>
                <li>
                    <label>所属设备：</label>
                    <label>{{item.deviceName}}</label>
                </li>
                <li>
                    <label>通道号：</label>
                    <label>{{item.channum}}</label>
                </li>
                <li>
                    <label>通道状态：</label>
                    <label>{{item.allocationStatusStr}}</label>
                </li>
                <li>
                    <label>设备OSD信息：</label>
                    <label>{{item.osdName}}</label>
                </li>
            </ul>
        </div>
    </div>
</template>
<script>
export default {
    name: 'VIdeoMask',
    data () {
        return {
            type: 0
        };
    },
    props: {
        item: {
            type: Object,
            default: () => {}
        } 
    },
    computed: {
    },
    created () {
    },
    methods: {
        changeFlag () {
            this.type = 0;
            this.$emit('showMask', false);
        },
        loadImg (src) {
            let image = new Image();
            let imageWidth = this.$refs.leftWrap.clientWidth;
            let imageHeight = this.$refs.leftWrap.clientHeight;
            image.src = src;
            // 图片高宽比
            let percent = image.height / image.width;
            if (percent < 1) {
                // 宽大于高的时候，宽度设为外部容器宽度的80%
                this.$refs.bigImg.width = imageWidth * 0.8;
                this.$refs.bigImg.height = imageWidth * 0.8 * percent;
                this.$refs.cameraInfo.style.height = imageWidth * 0.8 * percent + "px";
            } else if (percent > 1) {
                // 高大于宽的时候，高度设为外部容器高度的70%
                this.$refs.bigImg.height = imageHeight * 0.7;
                this.$refs.bigImg.width = imageHeight * 0.7 / percent;
                this.$refs.cameraInfo.style.height = imageHeight * 0.7 + "px";
            }
        },
        showBigImg (type) {
            type === 0 ? this.$refs.bigImg.src = this.item.enUrl : this.$refs.bigImg.src = this.item.exUrl;
            this.type = type;
        }
    },
    components: {
    },
    watch: {
    }
};
</script>

<style lang="scss" scoped>
.mask-wrap {
    position: fixed;
    z-index: 9999;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    display: flex;
    background-color: rgba(0, 0, 0, 0.7);
}
.left-wrap {
    flex: 1;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    .small-img-wrap {
        position: relative;
        width: 164px;
        height: 72px;
        text-align: center;
        margin-top: 12px;
        img {
            display: inline-block;
            height: 72px;
            width: 72px;
            margin: 0;
            background-color: rgba(0, 0, 0, 0.5);
            cursor: pointer;
        }
        .cur-img {
            border: 1px solid #FFFFFF;
        }
        .enter-img {
            margin-right: 16px;
        }
        .img-txt {
            position: absolute;
            bottom: 4px;
            color: #ffffff;
            display: inline-block;
            height: 16px;
            line-height: 16px;
            width: 16px;
            text-align: center;
            background-color: rgba(0, 0, 0, 0.5);
        }
        .enter-txt {
            right: 94px;
        }
        .out-txt {
            right: 0;
        }
    }
}
.right-wrap {
    width: 300px;
    display: flex;
    align-items: center;
    .close-wrap {
        position: absolute;
        top: 24px;
        right: 24px;
        width: 48px;
        height: 48px;
        background: url("~@/assets/close.png") no-repeat;
        cursor: pointer;
    }
    ul {
        vertical-align: top;
    }
    li {
        line-height: 24px;
        margin-bottom: 14px;
        font-size: 14px;
        label {
            display: inline-block;
            color: #ffffff;
            vertical-align: top;
            opacity: 0.8;
            filter: alpha(opacity = 0.8);
        }
        label:first-child {
            width: 120px;
            text-align: right;
        }
        label:last-child {
            width: 140px;
        }
        .camera-status {
            display: inline-block;
            height: 8px;
            width: 8px;
            border-radius: 8px;
            margin-right: 4px;
        }
        .online-status {
            background-color: #3BCD8D;
        }
        .offline-status {
            background-color: #FF0000;
        }
    }
}
</style>