<template>
    <el-dialog title="设备验证码" :visible="checkVisible" :area="[480,230]" top="middle" no-scrollbar :close-on-click-modal="false" :before-close="cancelFunc">
        <el-alert title="视频已加密，请输入设备验证码后播放" type="info" simple show-icon :closable="false"></el-alert>
        <el-form :model="checkForm" ref="checkForm" class="checkForm" @submit.native.prevent>
            <el-form-item label="设备验证码" prop="code" label-width="80px">
                <el-input v-model="checkForm.code" @keyup.enter.native="checkFunc"></el-input>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
            <el-button type="primary" @click="checkFunc">确 定</el-button>
            <el-button @click="cancelFunc">取 消</el-button>
        </div>
    </el-dialog>
</template>
<script>
/*
 * @Author: Sixiang Le 
 * @Date:   2019-04-03 16:09:16 
 * @Last Modified by: Sixiang Le
 * @Last Modified time: 2019-05-16 16:18:04
 */
import { subDays, format } from 'date-fns';
export default {
    name: 'DeviceValidateCodeCheck',
    data () {
        return {
            checkForm: {
                code: ''
            }
        };
    },
    props: {
        checkVisible: {
            type: Boolean,
            default: true
        },
        item: {
            type: Object,
            default: () => {}
        } 
    },
    computed: {
    },
    created () {
    },
    methods: {
        checkFunc () {
            if (this.item.validateCode === this.checkForm.code) {
                this.$refs['checkForm'].resetFields();
                this.$emit('update:checkVisible', false);
                this.$store.commit('SET_VIDEO_VALIDATE_IDS', this.item.monitorId);
                this.$emit('check-cb', {monitorId: this.item.monitorId});
            } else {
                this.$message.error("验证码错误,请重新输入");
            }
        },
        cancelFunc () {
            // 触发:visible.sync语法
            this.$emit('update:checkVisible', false); 
            this.$refs['checkForm'].resetFields();
        }
    },
    components: {
    },
    watch: {
    },
    destroyed () {
    }
};
</script>

<style lang="scss" scoped>
.checkForm {
    width: 400px;
    margin: 20px auto;
}
</style>