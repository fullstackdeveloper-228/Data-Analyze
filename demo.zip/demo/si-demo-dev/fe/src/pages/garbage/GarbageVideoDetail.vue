<template>
    <page-container :breadcrumb="breadCrumbs" class="video-detail-page" :showReturnIcon="true" ref="garbageVideoDetail" id="garbageVideoDetail">
        <div class="g-main" v-loading="loading" element-loading-text="正在加载中">
            <div class="m-video video-play" ref="videoPage">
                <div class="container">
                    <div class="left-detail">
                        <div class="m-detail">
                            <p class="base-item">
                                <span class="base-title">名称</span>
                                <span class="base-middle">：</span>
                                <span class="base-cont">{{videoInfo.monitorName}}</span>
                            </p>
                            <p class="base-item">
                                <span class="base-title">编号</span>
                                <span class="base-middle">：</span>
                                <span class="base-cont">{{videoInfo.monitorCode}}</span>
                            </p>
                            <p class="base-item">
                                <span class="base-title">所属组织</span>
                                <span class="base-middle">：</span>
                                <span class="base-cont">{{videoInfo.deviceOrgName}}</span>
                            </p>
                            <p class="base-item">
                                <span class="base-title">在线状态</span>
                                <span class="base-middle">：</span>
                                <span class="base-cont">
                                    <i :class="['camera-status',videoInfo.onlineStatus ? 'open':'close']"></i>
                                    <span>{{videoInfo.onlineStatus ? '在线' : '离线'}}</span>
                                </span>
                            </p>
                            <p class="base-item">
                                <span class="base-title">所属设备</span>
                                <span class="base-middle">：</span>
                                <span class="base-cont">{{videoInfo.deviceName}}</span>
                            </p>
                            <p class="base-item">
                                <span class="base-title">通道号</span>
                                <span class="base-middle">：</span>
                                <span class="base-cont">{{videoInfo.channum}}</span>
                            </p>
                            <p class="base-item">
                                <span class="base-title">通道状态</span>
                                <span class="base-middle">：</span>
                                <span class="base-cont">{{videoInfo.allocationStatusStr}}</span>
                            </p>
                        </div>
                    </div>
                    <div class="play-panal">
                        <div class="play-window">
                            <div class="ptz-window" v-show="ptzShow && isPreview">
                                <!-- 此处放置云台操作panel -->
                                <PTZ :info="{channelNo: videoInfo.channum, deviceSerial:videoInfo.monitorSerial, monitorCode: videoInfo.monitorCode}"></PTZ>
                            </div>
                            <div class="play-window-header">
                                <div class="tools-list clearfix">
                                    <div class="play-window-title">{{videoInfo.monitorName}}</div>
                                    <div class="pull-right" v-show="isLoaded && !((isPreview && !isHas_video_preview) || (!isPreview && !isHas_video_replay))">
                                        <div class="tools-box">
                                            <i title="截图" class="icon lidaicon-video-snapshot" @click="handleShot"></i>
                                        </div>
                                        <div class="tools-box" :class="{active: isRecording}" >
                                            <i :title="isRecording ? '结束录像' : '开始录像'" class="icon lidaicon-record" @click="handleRecord"></i>
                                        </div>
                                        <div class="tools-box" :class="{active: isZoom}">
                                            <i title="电子放大" class="icon lidaicon-video-zoom-elc" @click="handleZoom"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="play-window-bg" id="video_p">
                                <video-window ref="hkvideo" :opts="options"></video-window>
                            </div>
                            <div class="play-window-footer">
                                <div id="playback-timeline" ref="timeLineWrap" :style="{'height': !isPreview && !isHas_video_replay ?'48px': 'auto'}">
                                    <time-line ref="timeLine" v-if="!isPreview && isHas_video_replay"  :options="timeLineOpts" @change="handleChange" @update-time="updateTime"></time-line>
                                    <div class="mask" v-show="!isLoaded && !isPreview"></div>
                                </div>
                                <div class="tools-list">
                                    <div class="pull-left" v-show="isLoaded">
                                        <div class="tools-box" v-show="isPreview" :class="{disabled: !isHas_video_ptz}">
                                            <i title="云台" class="icon lidaicon-handle" @click="handlePtz"></i>
                                        </div>
                                    </div>
                                    <div class="pull-right">
                                        <div class="tools-box" v-show="!isPreview" :class="{disabled: !isHas_video_preview || !isLoaded}">
                                            <i title="切换预览" class="icon d-icon-base-video-preview" @click="changeToPreview"></i>
                                        </div>
                                        <div class="tools-box" v-show="isPreview && isHd" :class="{disabled: !isHas_video_preview || !isLoaded}">
                                            <span class="text" @click="changeToSd">高清</span>
                                        </div>
                                        <div class="tools-box" v-show="isPreview && !isHd" :class="{disabled: !isHas_video_preview || !isLoaded}">
                                            <span class="text" @click="changeToHd">标清</span>
                                        </div>
                                        <div class="tools-box" :class="{disabled: !isHas_video_replay || !isLoaded}">
                                            <i title="回放" class="icon lidaicon-playback" @click="openReplayDialog"></i>
                                        </div>
                                        <!-- <div class="tools-box">
                                            <i title="收藏" class="icon d-icon-base-collect"></i>
                                        </div> -->
                                        <div class="tools-box" :class="{disabled: !isLoaded || (isPreview && !isHas_video_preview) || (!isPreview && !isHas_video_replay)}">
                                            <i title="全屏" class="icon lidaicon-h-window-maximum" @click="handleFullScreen"></i>
                                        </div>
                                    </div>
                                    <div class="playback-show center-block" v-show="!isPreview && isHas_video_replay">
                                        <div class="pull-left scalarBox">
                                            <div class="pull-left">
                                                <div data-key="reduce" class="tools-box">
                                                    <i title="减少" class="icon lidaicon-cube-minus" @click="handleScalar('reduce')"></i>
                                                </div>
                                            </div>
                                            <div class="pull-right">
                                                <div data-key="add" class="tools-box">
                                                    <i title="增加" class="icon lidaicon-cube-add" @click="handleScalar('add')"></i>
                                                </div>
                                            </div>
                                            <!-- <div class="scalar-center" id="scalarLine"></div> -->
                                            <scalar-line ref="scalarLine" class="scalar-center" id="scalarLine" :options="scalarOptions" @change-scalar="changeScalar"></scalar-line>
                                        </div>
                                        <!-- <div class="pull-right">
                                            <div class="tools-box pauseBtn">
                                                <i title="暂停" class="icon lidaicon-pause"></i>
                                            </div>
                                            <div class="tools-box playBtn">
                                                <i title="播放" class="icon lidaicon-play"></i>
                                            </div>
                                            <div class="tools-box">
                                                <i title="前进一帧" class="icon lidaicon-next-frame"></i>
                                            </div>
                                        </div> -->
                                        <div class="center-tools">
                                            <div class="showTime">{{centerTime}}</div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <replay-time-picker :item="videoInfo" :visible.sync="replayDialogVisible" @check-func="changeToReplay"></replay-time-picker>
    </page-container>
</template>

<script>
import { format, isSameDay, isPast } from "date-fns";
import VideoWindow from "@/components/VideoWindow/VideoWindow.vue";
import ReplayTimePicker from "@/components/ReplayTimePicker/index.vue";
import TimeLine from "@/components/TimeLine/TimeLine.vue";
import PTZ from "@/components/PTZ/ptz.vue";
import ScalarLine from "@/components/ScalarLine/ScalarLine.vue";
import resize from "vue-resize-directive";
import { mapGetters } from "vuex";

export default {
    directives: {
        resize
    },
    name: "VideoDetail",
    props: {
        crumbs: {
            type: Array,
            default: () => []
        }
    },
    computed: {
        ...mapGetters([
            "operateCodes"
        ]),
        isHas_video_preview () {
            return this.operateCodes.includes("hikkan_video_preview");
        },
        isHas_video_replay () {
            return this.operateCodes.includes("hikkan_video_replay");
        },
        isHas_video_ptz () {
            // return this.operateCodes.includes("hikkan_video_ptz");
            return this.operateCodes.includes("hikkan_video_preview");
        }
    },
    data () {
        return {
            replayFinished: false,
            loading: false,
            videoInfo: {},
            isZoom: false,
            isRecording: false,
            isLoaded: false,
            recordTimer: null,
            ptzShow: false,
            isPreview: true,
            toggleToPreview: false, // 从回放切换到预览
            isHd: false,
            replayDialogVisible: false,
            recList: [],
            options: {
                id: 'video_window',
                accessToken: '',
                url: '',
                handleSuccess: this.previewSuccessFn,
                width: 1426,
                height: 765
            },
            timeLineOpts: {
                width: 500,
                height: 756,
                time: new Date().getTime(),
                timeSection: [],
                timeWidth: 0 // 0-4 0:1秒；1:1分钟，5分钟每数字；2：1分钟，10分钟每数字； 3：1小时，2小时每数字；4：1天，3天每数字
            },
            scalarOptions: {
                type: 'transverse',
                scalar: 4,
                position: 0
            },
            centerTime: '',
            timer: null, // 获取OSDtime的计时器
            runTime: false, // 是否播放成功，为true去获取OSD-Time
            realTime: '',
            oldTime: '',
            isAhead: false,
            startTime: '',
            endTime: ''
        };
    },
    mounted () {
        this.init();
    },
    components: {
        VideoWindow,
        ReplayTimePicker,
        TimeLine,
        ScalarLine,
        PTZ
    },
    methods: {
        init () {
            let self = this;
            if (this.$route.query.type === '1') {
                Promise.all([this.getPlayUrl(), this.getMonitorInfo()]).then((result) => {
                    this.onResize(true);
                }).catch((error) => {
                    // 用户不拥有该设备资源， 直接返回到列表
                    if (error.code === '02010003') {
                        setTimeout(() => {
                            this.$router.push({ path: '/app/video'});
                        }, 800);
                    }
                });
            } else {
                Promise.all([this.getPlayUrl(), this.getMonitorInfo(), this.getRecordList()]).then((result) => {
                    this.onResize(true);
                }).catch((error) => {
                    // 用户不拥有该设备资源， 直接返回到列表
                    if (error.code === '02010003') {
                        setTimeout(() => {
                            this.$router.push({ path: '/app/video'});
                        }, 800);
                    }
                });
            }
        },
        /**
         * @param type 播放类型： '1','2'
         * @param begin 开始时间时间戳
         * @param end 结束时间时间戳
         */
        getPlayUrl (type, begin, end) {
            return new Promise((resolve, reject) => {
                type = type || this.$route.query.type;
                let beginTime = begin || parseInt(this.$route.query.startTime);
                let endTime = end || parseInt(this.$route.query.endTime);
                let monitorSerial = this.$route.query.monitorSerial;
                let channum = this.$route.query.channum;
                let validateCode = this.$route.query.validateCode;
                let isencrypt = this.$route.query.isencrypt;

                this.startTime = beginTime;
                this.endTime = endTime;
                // 转为回放格式时间
                begin = format(beginTime, "YYYYMMDDHHmmss");
                end = format(endTime, "YYYYMMDDHHmmss");

                if (type === '1') {
                    this.isPreview = true;
                    if (isencrypt) {
                        this.options.url = `ezopen://${validateCode}@open.ys7.com/${monitorSerial}/${channum}.live`;
                    } else {
                        this.options.url = `ezopen://open.ys7.com/${monitorSerial}/${channum}.live`;
                    }
                } else {
                    this.isPreview = false;
                    if (isencrypt) {
                        this.options.url = `ezopen://${validateCode}@open.ys7.com/${monitorSerial}/${channum}.rec?begin=${begin}&end=${end}`;
                    } else {
                        this.options.url = `ezopen://open.ys7.com/${monitorSerial}/${channum}.rec?begin=${begin}&end=${end}`;
                    }
                }
                resolve('success');
            });
        },
        // 获取单个监控点详细信息
        getMonitorInfo () {
            return new Promise((resolve, reject) => {
                let self = this;
                this.loading = false;
                this.$http({
                    method: "post",
                    url: this.$api.GET_CAMERA_DETAIL,
                    data: {
                        id: this.$route.query.id
                    }
                }).then((res) => {
                    this.videoInfo = res.data;
                    this.loading = false;
                    resolve('success');
                }).catch((err) => {
                    reject(err);
                    this.loading = false;
                });
            });
        },
        /**
         * 获取一段时间内的录像片段
         * start: 时间戳
         * end: 时间戳
         */
        getRecordList (start, end) {
            return new Promise((resolve, reject) => {
                let info = {
                    deviceSerial: this.$route.query.monitorSerial,
                    channelNo: this.$route.query.channum,
                    startTime: start || parseInt(this.$route.query.startTime),
                    endTime: end || parseInt(this.$route.query.endTime),
                    recType: 0
                };
                this.$store.dispatch("GetRecordList", info).then((res) => {
                    this.timeLineOpts.timeSection = [];
                    this.recList = res.data;
                    let playStartTime = '';
                    let playEndTime = '';
                    this.recList.forEach((item, i) =>{
                        let time_1 = item.startTime;
                        let time_2 = item.endTime;
                        let Time1 = info.startTime;
                        let Time2 = info.endTime;
                        if (i === 0) {
                            if (Time1 > time_1 && Time1 <= time_2) {
                                time_1 = Time1;
                            } else if (Time1 < time_1) {
                                playStartTime = time_1; // 把play的开始时间置为
                            }
                        }
                        if (i === this.recList.length - 1) {
                            if (Time2 > time_1 && Time2 <= time_2) {
                                time_2 = Time2;
                            } else if (Time2 > time_2) {
                                playEndTime = time_2;
                            }
                        }
                        this.timeLineOpts.timeSection.push({
                            time: [time_1, time_2]
                        });
                        this.timeLineOpts.time = this.$route.query.startTime;
                    });
                    // console.log(this.timeLineOpts.timeSection);
                    resolve('success');
                }).catch((err) => {
                    reject(err);
                });
            });
        },
        // 获取萤石小权限token
        getSmallToken () {
            let info = {
                dev: this.$route.query.monitorSerial
            };
            return new Promise((resolve, reject) => {
                this.$store.dispatch("GetSmallToken", info).then((res) => {
                    this.options.accessToken = res.data;
                    resolve();
                }).catch((err) => {
                    reject();
                });
            });
        },
        // 切换高清
        changeToHd () {
            if (!this.isLoaded) {
                return;
            }
            let validateCode = this.$route.query.validateCode;
            let isencrypt = this.$route.query.isencrypt;
            if (isencrypt) {
                this.options.url = `ezopen://${validateCode}@open.ys7.com/${this.videoInfo.monitorSerial}/${this.videoInfo.channum}.hd.live`;
            } else {
                this.options.url = `ezopen://open.ys7.com/${this.videoInfo.monitorSerial}/${this.videoInfo.channum}.hd.live`;
            }
            this.options.handleSuccess = this.previewSuccessFn;
            this.isLoaded = false;
            this.onResize().then(() => {
                this.$nextTick(() => {
                    this.switchStatus();
                });
            });
            this.isHd = true;
        },
        // 切换标清
        changeToSd () {
            if (!this.isLoaded) {
                return;
            }
            let validateCode = this.$route.query.validateCode;
            let isencrypt = this.$route.query.isencrypt;
            if (isencrypt) {
                this.options.url = `ezopen://${validateCode}@open.ys7.com/${this.videoInfo.monitorSerial}/${this.videoInfo.channum}.live`;
            } else {
                this.options.url = `ezopen://open.ys7.com/${this.videoInfo.monitorSerial}/${this.videoInfo.channum}.live`;
            }
            this.options.handleSuccess = this.previewSuccessFn;
            this.isLoaded = false;
            this.onResize().then(() => {
                this.$nextTick(() => {
                    this.switchStatus();
                });
            });
            this.isHd = false;
        },
        // 回放切换到预览
        changeToPreview () {
            if (!this.isLoaded) {
                return;
            }
            // 日志与历史记录
            if (this.isHas_video_preview) {
                clearInterval(this.timer);
                this.timer = null;
                this.isPreview = true;
                this.toggleToPreview = true;
                let validateCode = this.$route.query.validateCode;
                let isencrypt = this.$route.query.isencrypt;
                if (this.isHd) {
                    if (isencrypt) {
                        this.options.url = `ezopen://${validateCode}@open.ys7.com/${this.videoInfo.monitorSerial}/${this.videoInfo.channum}.hd.live`;
                    } else {
                        this.options.url = `ezopen://open.ys7.com/${this.videoInfo.monitorSerial}/${this.videoInfo.channum}.hd.live`;
                    }
                } else {
                    if (isencrypt) {
                        this.options.url = `ezopen://${validateCode}@open.ys7.com/${this.videoInfo.monitorSerial}/${this.videoInfo.channum}.live`;
                    } else {
                        this.options.url = `ezopen://open.ys7.com/${this.videoInfo.monitorSerial}/${this.videoInfo.channum}.live`;
                    }
                }
                this.onResize().then(() => {
                    this.$nextTick(() => {
                        this.switchStatus();
                    });
                });
            } else {
                return;
            }
        },
        /* 按钮事件 start */
        handleFullScreen () {
            if (!this.isLoaded || (this.isPreview && !this.isHas_video_preview) || (!this.isPreview && !this.isHas_video_replay)) {
                return;
            }
            this.$refs.hkvideo.fullScreen();
        },
        handleShot () {
            this.$refs.hkvideo.$screenShot();
        },
        handleRecord () {
            let self = this;
            if (this.isRecording) {
                clearTimeout(this.recordTimer);
                this.recordTimer = null;
                this.$refs.hkvideo.$stopRecord().then(
                    () => {
                        self.isRecording = false;
                    },
                    (err) => {
                        throw err;
                    }
                );
            } else {
                this.$refs.hkvideo.$startRecord().then(
                    ()=>{
                        self.isRecording = true;
                        self.recordTimer = setTimeout(() => {
                            self.$refs.hkvideo.$stopRecord().then(
                                () => {
                                    self.isRecording = false;
                                },
                                (err) => {
                                    throw err;
                                }
                            );
                        }, 20 * 60 * 1000);
                        // 默认20分钟
                    },
                    (err) => {
                        throw err;
                    }
                );
            }
        },
        handleZoom () {
            if (this.isZoom) {
                this.$refs.hkvideo.$stopZoom();
                this.isZoom = false;
            } else {
                this.$refs.hkvideo.$enableZoom();
                this.isZoom = true;
            }
        },
        handleScalar (type) {
            if (type === 'reduce') {
                this.$refs.scalarLine.$changeRange();
            } else {
                this.$refs.scalarLine.$changeRange(true);
            }
        },
        /* 按钮事件 end */
        onResize (initFlag) {
            let self = this;
            return new Promise((reslove, reject) => {
                // let windowWidth = document.body.clientWidth;
                // let windowWidth = document.querySelector('#garbageVideoDetail').clientWidth + 230;
                let windowWidth = self.$refs.garbageVideoDetail.$el.clientWidth + 230;
                let videoWidth, videoHeight;
                if (windowWidth >= 1900) {
                    this.$utils.removeClass(this.$refs.videoPage, "width-1600 width-1280");
                    videoWidth = 1426;
                    videoHeight = 765;
                } else if (windowWidth >= 1600) {
                    this.$utils.removeClass(this.$refs.videoPage, "width-1280");
                    this.$utils.addClass(this.$refs.videoPage, "width-1600");
                    videoWidth = 1142;
                    videoHeight = 614;
                } else {
                    this.$utils.removeClass(this.$refs.videoPage, "width-1600");
                    this.$utils.addClass(this.$refs.videoPage, "width-1280");
                    videoWidth = 822;
                    videoHeight = 434;
                }
                if (!this.isPreview) {
                    videoHeight = videoHeight - 48;
                }
                this.options.width = videoWidth;
                this.options.height = videoHeight;
                if (initFlag) {
                    if (!this.isPreview) {
                        this.timeLineOpts.width = videoWidth;
                    }
                    if (!this.videoInfo.onlineStatus) {
                        this.$message.error("监控点已离线");
                        this.isLoaded = false;
                        return;
                    }
                    // 获取token，修改options以后调用render播放
                    this.getSmallToken().then(() => {
                        if (this.isPreview) {
                            if (!this.isHas_video_preview) {
                                this.$message.error("无预览权限");
                                this.isLoaded = true;
                                return;
                            }
                            this.switchStatus();
                        } else {
                            if (!this.isHas_video_replay) {
                                this.$message.error("无回放权限");
                                this.isLoaded = true;
                                return;
                            }
                            this.switchStatus('playback', this.startTime, this.endTime);
                        }
                    });
                } else {
                    if (!this.isPreview) {
                        clearInterval(this.timer);
                        this.timer = null;
                    }
                    this.loading = false;
                    reslove();
                }
            });
        },
        // 预览回调
        previewSuccessFn () {
            this.isLoaded = true;
        },
        /*  回放弹窗start */
        openReplayDialog () {
            if (this.isHas_video_replay) {
                if (!this.isLoaded) {
                    return;
                }
                this.replayDialogVisible = true;
            } else {
                return;
            }
        },
        // 弹窗确定回调事件
        changeToReplay (val) {
            this.startTime = parseInt(val.startTime);
            this.endTime = parseInt(val.endTime);
            this.getRecordList(this.startTime, this.endTime).then((res)=>{
                console.log(res);
                this.isPreview = false;
                this.onResize().then(() => {
                    this.$nextTick(() => {
                        this.switchStatus('playback', parseInt(val.startTime), parseInt(val.endTime));
                    });
                });
            });
        },
        /*  回放弹窗 end */

        // 处理时间条拖动
        handleChange (arr) {
            // 新的时间，老的时间
            // clearInterval(this.timer);
            // this.timer = null;
            let self = this;

            if (!self.runTime && self.replayFinished) {
                self.realTime = arr[0];
                if (self.realTime < self.startTime || self.realTime > self.endTime) {
                    self.$alert('', '回放时间不能超过起止时间', {
                        confirmButtonText: '确定',
                        callback: () => {}
                    });
                } else {
                    clearInterval(self.timer);
                    self.timer = null;
                    console.log("结束回放后重新回放");
                    self.runTime = false;
                    self.switchStatus('playback', self.realTime, self.endTime);
                }
                return;
            }
            this.$refs.hkvideo.$getOSDTime(0, (time) => {
                self.realTime = arr[0]; // 拖动完时间条的时间条刻度时间
                arr[1] === 1
                    ? (self.oldTime = time)
                    : (self.oldTime = arr[1]);
                self.realTime - self.oldTime > 0
                    ? (self.isAhead = true)
                    : (self.isAhead = false);
                if (self.realTime < self.startTime || self.realTime > self.endTime) {
                    self.$alert('', '回放时间不能超过起止时间', {
                        confirmButtonText: '确定',
                        callback: () => {}
                    });
                } else {
                    clearInterval(self.timer);
                    self.timer = null;
                    console.log("重新去回放");
                    self.runTime = false;
                    self.switchStatus('playback', self.realTime, self.endTime);
                }
            }, (err) => {
                console.log(err);
                console.log("获取OSDTime失败");
            });
        },
        replaySuccessFun () {
            // 延迟2s执行,抵消视频约2秒之后才有画面
            this.isLoaded = true;
            setTimeout(() => {
                if (this.isPreview) {
                    // 在2秒等待内又切换成了预览
                    return;
                }
                let self = this;
                this.runTime = true;
                this.timer = setInterval(() => {
                    if (self.runTime) {
                        self.$refs.hkvideo.$getOSDTime(0, (time) => {
                            let tempTime = time;
                            // console.log(self.endTime - tempTime);
                            if (self.endTime - tempTime < 2000) {
                                self.runTime = false;
                                setTimeout(()=>{
                                    clearInterval(self.timer);
                                    self.timer = null;
                                    this.$message.info("回放播放结束");
                                    this.$refs.hkvideo.$closeVideo();
                                    this.replayFinished = true;
                                }, 1000);
                                self.$refs.timeLine.$run({
                                    time: self.endTime
                                });
                                return;
                            }
                            // console.log(format(time, "YYYY-MM-DD HH:mm:ss"));

                            // 防止拖动进度条时指针回跳
                            // if (self.realTime) {
                            //     if (self.isAhead) { // 往左拖了
                            //         if (tempTime < self.realTime) {
                            //             tempTime = self.realTime;
                            //         }
                            //     } else { // 往右拖了
                            //         if (tempTime > self.oldTime) {
                            //             // tempTime = self.realTime;
                            //         }
                            //     }
                            // }
                            self.$refs.timeLine.$run({
                                time: tempTime
                            });
                        }, (err) => {
                            console.log(err);
                        });
                    }
                }, 1000);
            }, 2000);
        },
        // 更新hover时间
        updateTime (time) {
            this.centerTime = format(time, "YYYY-MM-DD HH:mm:ss");
        },
        changeScalar (range) {
            if (this.$refs.timeLine) {
                this.$refs.timeLine.$run({
                    timeWidth: range
                });
                this.timeLineOpts.timeWidth = range;
            }
        },
        switchStatus (mode, startTime, endTime, recordLocation) {
            this.isLoaded = false;
            this.isRecording = false;
            this.isZoom = false;
            clearInterval(this.timer);
            this.timer = null;
            this.realTime = null;
            clearTimeout(this.recordTimer);
            this.recordTimer = null;
            let isencrypt = this.$route.query.isencrypt;
            let validateCode = this.$route.query.validateCode;

            if (mode === 'playback') {
                this.replayDialogVisible = false;
                this.runTime = false;
                this.timeLineOpts.time = startTime;
                this.timeLineOpts.width = this.options.width;
                this.isPreview = false;
                this.ptzShow = false;

                this.$nextTick(() => {
                    if (!this.$refs.scalarLine.hasInit) {
                        this.$refs.scalarLine.init();
                    }
                    if (this.isHas_video_replay) {
                        console.log("初始化timeLine");
                        this.$refs.timeLine.init();
                    }
                });
                let begin = format(startTime, "YYYYMMDDHHmmss");
                let end = format(endTime, "YYYYMMDDHHmmss");
                if (isencrypt) {
                    this.options.url = `ezopen://${validateCode}@open.ys7.com/${this.videoInfo.monitorSerial}/${this.videoInfo.channum}.rec?begin=${begin}&end=${end}`;
                } else {
                    this.options.url = `ezopen://open.ys7.com/${this.videoInfo.monitorSerial}/${this.videoInfo.channum}.rec?begin=${begin}&end=${end}`;
                }
                this.options.handleSuccess = this.replaySuccessFun;
                if (this.replayFinished) {
                    this.$refs.hkvideo.render();
                    this.replayFinished = false;
                } else {
                    this.$refs.hkvideo.$closeVideo().then(() => {
                        this.$refs.hkvideo.render();
                    }).catch(() => {
                        console.log("关闭视频失败");
                    });
                }
            } else {
                this.isPreview = true;
                this.options.handleSuccess = this.previewSuccessFn;
                this.$nextTick(() => {
                    if (this.replayFinished) {
                        this.$refs.hkvideo.render();
                        this.replayFinished = false;
                    } else {
                        this.$refs.hkvideo.$closeVideo().then(() => {
                            this.$refs.hkvideo.render();
                        }).catch(() => {
                            console.log("关闭视频失败");
                        });
                    }
                });
            }
        },
        /* PTZ云台 start */
        handlePtz () {
            if (this.isHas_video_ptz) {
                this.ptzShow = !this.ptzShow;
            } else {
                return;
            }
        }
        /* PTZ云台 end */
    },
    beforeDestroy () {
        if (this.timer) {
            clearInterval(this.timer);
            // this.runTime = false;
        }
        if (this.isRecording) {
            clearTimeout(this.recordTimer);
            this.recordTimer = null;
            this.$refs.hkvideo.$stopRecord().then(
                () => {
                    self.isRecording = false;
                },
                (err) => {
                    throw err;
                }
            );
        }
        if (this.$refs.hkvideo.vWindow) {
            this.$refs.hkvideo.$closeVideo();
        }
    }
};
</script>
<style lang="scss" scoped>
.video-detail-page {
    .g-main {
        background: #f5f5f5;
        font-size: 12px;
        overflow: hidden;
        .m-video {
            &.video-play {
                .container {
                    position: relative;
                    width: 1674px;
                    padding: 0;
                    margin: 0 auto;
                    display: flex;
                    .left-detail {
                        width: 240px;
                        height: 845px;
                        padding: 24px 10px 0 22px;
                        margin-right: 8px;
                        background-color: #FFF;
                        font-size: 12px;
                        .camera-status {
                            display: inline-block;
                            width: 12px;
                            height: 12px;
                            margin-right: 2px;
                            &.open {
                                background: url("~@/assets/icon/online1.png") no-repeat 0 1px;
                            }
                            &.close {
                                background: url("~@/assets/icon/online0.png") no-repeat 0 1px;
                            }
                        }
                        .base-item {
                            overflow: hidden;
                            margin-bottom: 16px;
                            word-break: break-all;
                            color: #999;
                            display: flex;
                            .base-title {
                                width: 48px;
                                text-align: right;
                            }
                            .base-middle {
                                color: #999;
                            }
                            .base-cont {
                                display: flex;
                                align-items: center;
                                width: 140px;
                                color: #4d4d4d;
                            }
                        }
                    }
                    .play-panal {
                        width: 1434px;
                        .tools-box {
                            margin: 0 8px;
                            float: left;
                            height: 40px;
                            line-height: 46px;
                            text-align: center;
                            .text {
                                font-size: 12px;
                                color: #fff;
                                display: block;
                                line-height: 40px;
                                height: 40px;
                            }
                            i.icon {
                                color: #fff;
                                font-size: 16px;
                            }
                            &:hover {
                                i.icon, .text {
                                    cursor: pointer;
                                    color: #fff;
                                }
                            }
                            &.active {
                                i.icon, .text {
                                    color: #2b89eb;
                                }
                            }
                            &.disabled {
                                i.icon, .text {
                                    // color: #4c4c4c;
                                    color: #828282;
                                    cursor: no-drop;
                                }
                            }
                        }
                        .play-window-bg {
                            background-color: #191919;
                        }
                        .play-window {
                            position: relative;
                            .tools-list {
                                height: 40px;
                                background: #3d3d3d;
                            }
                            .play-window-header {
                                .play-window-title {
                                    margin-left: 12px;
                                    color: #e5e5e5;
                                    float: left;
                                    font-size: 14px;
                                    line-height: 40px;
                                }
                            }
                            .play-window-footer {
                                #playback-timeline {
                                    background: #191919;
                                    position: relative;
                                    .mask {
                                        width: 100%;
                                        height: 48px;
                                        position: absolute;
                                        top: 0;
                                        left: 0;
                                        right: 0;
                                        cursor: no-drop;
                                        z-index: 10;
                                    }
                                }
                                .center-block {
                                    width: 630px;
                                    height: 40px;
                                    margin: 0 auto;
                                    .center-tools {
                                        width: 297px;
                                        height: 40px;
                                        margin: 0 auto;
                                        .showTime {
                                            width: 144px;
                                            height: 40px;
                                            margin: 0 auto;
                                            background-color: rgba(
                                                    255,
                                                    255,
                                                    255,
                                                    0.1
                                            );
                                            color: #FFF;
                                            font-weight: bold;
                                            line-height: 40px;
                                            text-align: center;
                                        }
                                    }
                                    .scalarBox {
                                        width: 136px;
                                        .tools-box {
                                            width: 24px;
                                            margin: 0;
                                        }
                                        .scalar-center {
                                            margin: 16px 36px;

                                            .center-line {
                                                width: 62px;
                                                height: 0;
                                                border: 1px solid #fff;
                                            }
                                        }
                                    }
                                }
                            }
                            //云台
                            .ptz-window {
                                position: absolute;
                                border-right: 1px solid #e6e6e6;
                                width: 247px;
                                height: 100%;
                                top: 0px;
                                left: -248px;
                                z-index: 100;
                                overflow: hidden;
                            }
                        }
                    }
                }
            }
            // 1600分辨率下
            &.width-1600 {
                .container {
                    width: 1390px;
                    .left-detail {
                        height: 694px;
                    }
                    .play-panal {
                        width: 1142px;
                    }
                }
            }
            // 1280分辨率下
            &.width-1280 {
                .container {
                    width: 1070px;
                    .left-detail {
                        height: 514px;
                    }
                    .play-panal {
                        width: 822px;
                    }
                }
            }
        }
    }
    .playback-hide {
        display: none;
    }

    .playback-show {
        display: block;
    }
}
</style>
