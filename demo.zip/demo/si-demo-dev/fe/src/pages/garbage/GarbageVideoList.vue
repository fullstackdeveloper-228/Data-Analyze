<template>
    <h-page-container class="video-list">
        <h-page-header slot="pageHeader" :breadcrumb="breadCrumbs"></h-page-header>
        <h-layout direction="vertical" class="video-org">
            <t-page-table @table-height-change="handleTableHeightChange">
                <template slot="hPageAction">
                    <h-page-search slot="hPageSearch" :options="options">
                        <h-page-search-item label="时间段" prop="keyWord" @keyup.enter.native="getUserList">
                            <el-date-picker
                                v-model="dateTime"
                                type="datetimerange"
                                placeholder="选择日期范围"
                                range-separator=" 至 ">
                            </el-date-picker>
                        </h-page-search-item>
                        <h-page-search-item label="关键字" prop="deviceNameOrSerial">
                            <el-input
                                class="search-input"
                                v-model="keyword"
                                placeholder="请输入"
                                clearable
                            >
                            </el-input>
                        </h-page-search-item>
                        <template slot="pageSearchAction">
                            <el-button type="primary" class="longbtn" @click="handleSearchTable">查询</el-button>
                            <el-button class="longbtn"  @click="resetSearch">重置</el-button>
                        </template>
                    </h-page-search>
                </template>
                <template slot="rightAction">
                    <el-radio-group v-model="tableType" type="simple" size="small" class="right-action">
                        <el-radio-button label="1">
                            <i class="lidaicon-thumbnail-f"></i>
                        </el-radio-button>
                        <el-radio-button label="2">
                            <i class="lidaicon-list"></i>
                        </el-radio-button>
                    </el-radio-group>
                </template>
                <template slot="hPageTable">
                    <div class="video-body" v-loading="loading2" element-loading-text="正在加载中">
                        <div class="video-content">
                            <el-scrollbar wrap-class="page-scrollbar__wrap" :size="8" v-if="tableType === '1'">
                                <div class="video-cards" ref="videoList" v-resize="onResize">
                                    <div class="m-card" v-for="(item, index) in videoList" :key="index">
                                        <div class="video-img">
                                            <img v-lazy="item.enThumbnailUrl || ''" :key="item.enThumbnailUrl" />
                                        </div>
                                        <div class="offline-status" v-show="!item.onlineStatus">离线</div>
                                        <div class="hover-body" @click="showMaskHandle(true, item)">
                                            <!-- <div class="detail">查看详情</div> -->
                                            <div class="detail"><i class="icon lidaicon-video-zoom-elc"></i></div>
                                        </div>
                                        <div class="video-info">
                                            <div class="name"  :title="item.monitorName">
                                                <i class="lidaicon-device-camera"></i>
                                                {{item.monitorName}}
                                            </div>
                                            <div class="orgName">
                                                <i class="lidaicon-h-clock"></i>
                                                {{item.enterAlarmTime | parseTime()}}  - {{item.exitAlarmTime | parseTime1()}}
                                            </div>
                                            <div class="orgName">
                                                <i class="lidaicon-map-local"></i>
                                                {{item.garbagePointName}}
                                            </div>
                                        </div>
                                        <el-row class="btn-con">
                                            <el-col :span="12" class="grid-content" :class="{disabled: !isHas_video_replay}" title="回放" @click.native="openReplayDialog(item)">
                                                回放
                                            </el-col>
                                            <el-col :span="12" class="grid-content" :class="{disabled: !isHas_video_preview}" title="预览" @click.native="openMiniVideo(item)">
                                                预览
                                            </el-col>
                                        </el-row>
                                    </div>
                                </div>
                            </el-scrollbar>
                            <el-table ref="multipleTable" :data="videoList" force-scroll v-else style="width:100;" :height="tableHeight">
                                <el-table-column type="index" label="序号" min-width="55"></el-table-column>
                                <el-table-column prop="monitorName" label="监控点名称" min-width="100"></el-table-column>
                                <el-table-column prop="deviceName" label="设备名称" min-width="100"></el-table-column>
                                <el-table-column prop="garbagePointName" label="垃圾点名称" min-width="100"></el-table-column>
                                <el-table-column prop="enterAlarmTime" label="进入时间" min-width="100">
                                    <template slot-scope="scope">{{ scope.row.enterAlarmTime | parseTime() }}</template>
                                </el-table-column>
                                <el-table-column prop="exitAlarmTime" label="离开时间" min-width="100">
                                    <template slot-scope="scope">{{ scope.row.exitAlarmTime | parseTime() }}</template>
                                </el-table-column>
                                <el-table-column prop="deviceOrgName" label="组织名称" min-width="100"></el-table-column>
                                <el-table-column label="操作" width="150">
                                    <template slot-scope="scope">
                                        <div class="page-table-operate">
                                            <el-button type="iconButton" icon="lidaicon-h-image" title="抓图详情"  @click="showMaskHandle(true, scope.row)"></el-button>
                                            <el-button type="iconButton" @click="openMiniVideo(scope.row)" icon="lidaicon-play" title="预览"></el-button>
                                            <el-button type="iconButton" @click="openReplayDialog(scope.row)" icon="lidaicon-playback" title="回放"></el-button>
                                        </div>
                                    </template>
                                </el-table-column>
                            </el-table>
                        </div>
                        <el-pagination
                            class="m-page"
                            @size-change="handleSizeChange"
                            @current-change="handlePageChange"
                            :current-page="pageNo"
                            :page-sizes="[10, 18, 60, 100]"
                            :page-size="pageSize"
                            layout="total, sizes, prev, pager, next, jumper"
                            :total="total">
                        </el-pagination>
                        <div class="noresult" v-if="noresult">
                            <div class="content">
                                <img src="../../assets/noresult.png" alt="">
                                <p>没有符合条件的数据</p>
                            </div>
                        </div>
                        <div class="nodata" v-if="nodata">
                            <div class="content">
                                <img src="../../assets/empty.png" alt="">
                                <p>暂无数据</p>
                            </div>
                        </div>
                        <div class="video-dialog" ref="videoDialog" v-if="dialogVisible" v-drag>
                            <eits-play-window ref="mini" v-bind="playInfo" @video-detail="videoDetailCb" @video-close="closeDialog">
                                <!-- <template slot="rightAction">
                                    <el-button>BTN</el-button>
                                </template> -->
                            </eits-play-window>
                        </div>
                        <eits-replay-time-picker :visible.sync="replayDialogVisible" :support-cloud="playInfo.supportCloud" @check-func="routeToDeatilReplay"></eits-replay-time-picker>
                        <eits-device-code-check :code="playInfo.validateCode" :check-visible.sync="codeCheckDialogVisible" @check-cb="checkCodeCb"></eits-device-code-check>
                    </div>
                </template>
            </t-page-table>
        </h-layout>
    </h-page-container>
</template>

<script>
/*
 * @Author: Sixiang Le 
 * @Date: 2019-07-23 10:59:41 
 * @Last Modified by: Sixiang Le
 * @Last Modified time: 2020-03-01 22:39:21
 */
import PlayWindow from "@/components/PlayWindow/index.vue";
import ReplayTimePicker from "@/components/ReplayTimePicker/index.vue";
import DeviceValidateCodeCheck from "./components/DeviceValidateCodeCheck.vue";
import VideoMask from "./components/VideoMask.vue";
import resize from "vue-resize-directive";
import { mapGetters } from "vuex";
import errorImg from "@/assets/icon/video-default-error.png";
import { startOfDay, endOfDay, format } from "date-fns";
export default {
    directives: {
        resize
    },
    name: "GarbageVideoList",
    props: {
        crumbs: {
            type: Array,
            default: () => []
        }
    },
    computed: {
        ...mapGetters([
            "operateCodes",
            "playStyle",
            "videoValidatedIds"
        ]),
        pageBodyStyle () {
            return "height: calc(100% - 48px); padding: 0;";
        },
        isHas_video_preview () {
            return this.operateCodes.includes("hikkan_video_preview");
        },
        isHas_video_replay () {
            return this.operateCodes.includes("hikkan_video_replay");
        }
    },
    filters: {
        parseTime1 (time) {
            return time ? format(time, 'HH:mm:ss') : '';
        },
        parseTime (time) {
            return time ? format(time, 'YYYY-MM-DD HH:mm:ss') : '';
        }
    },
    data () {
        return {
            options: {
                xl: 1408,
                lg: 1350,
                md: 708,
                sm: 650
            },
            tableHeight: 0,
            tableType: '1',
            // dateTime: [
            //     startOfDay(new Date()),
            //     endOfDay(new Date())
            // ],
            dateTime: [],
            keyword: "",
            errorImg: errorImg,
            playInfo: {},
            treeSearchKey: "",
            pageSize: 60,
            pageNo: 1,
            total: 10,
            obtainChild: true,
            treeData: [],
            deviceOrgId: "100000",
            loading1: false,
            loading2: false,
            dialogVisible: false, // mini视频弹窗
            replayDialogVisible: false, // 回放时间选择弹窗
            codeCheckDialogVisible: false, // 设备验证码校验弹窗
            clickType: '1', // 1是预览按钮，2是回放按钮
            noresult: false,
            nodata: false,
            videoList: [],
            showBigImg: false,
            curItem: {}
        };
    },
    created () {
        this.getList();
    },
    // mounted () {
    //     this.$nextTick(() => {
    //         this.resize();
    //     });
    // },
    components: {
        PlayWindow,
        ReplayTimePicker,
        DeviceValidateCodeCheck,
        VideoMask
    },
    methods: {
        handleTableHeightChange (h) {
            this.tableHeight = h;
        },
        showMaskHandle (flag, item) {
            this.showBigImg = flag;
            if (item) {
                this.curItem = Object.assign({}, { 
                    monitorName: item.monitorName,
                    monitorSerial: item.monitorSerial,
                    deviceOrgName: item.deviceOrgName,
                    onlineStatus: item.onlineStatus,
                    deviceName: item.deviceName,
                    channum: item.channum,
                    allocationStatusStr: item.allocationStatusStr,
                    osdName: item.osdName,
                    enUrl: item.enUrl,
                    enThumbnailUrl: item.enThumbnailUrl,
                    exUrl: item.exUrl,
                    exThumbnailUrl: item.exThumbnailUrl
                });
            }

        },
        resetSearch () {
            this.keyword = "";
            this.handleSearchTable();
        },
        handleSearchTable () {
            this.getList(true);
        },
        handleClearTable () {
            this.keyword = "";
            this.handleSearchTable();
        },
        handleSelectionChange (val) {
            this.multipleSelection = val;
        },
        // 根据树节点分页筛选获取监控点列表功能
        getList (isSearch) {
            this.loading2 = true;
            let data = {
                pageNo: this.pageNo,
                pageSize: this.pageSize,
                keyWord: this.keyword,
                enterAlarmTime: "",
                exitAlarmTime: ""
            };
            if (this.dateTime && this.dateTime[0]) {
                data.enterAlarmTime = format(this.dateTime[0]);
                data.exitAlarmTime = format(this.dateTime[1]);
            }
            this.$http({
                method: "post",
                url: this.$api.GET_GARBAGE_VIDEO_LIST,
                data: data
            }).then((res) => {
                if (isSearch) {
                    this.nodata = false;
                    this.noresult = res.data.total ? false : true;
                } else {
                    this.noresult = false;
                    this.nodata = res.data.total ? false : true;
                }
                this.videoList = res.data.list;
                this.total = res.data.total;
                this.$nextTick(() => {
                    this.loading2 = false;
                });
            }).catch((err) => {
                this.loading2 = false;
            });
        },
        handleSearch () {
            this.status = 1;
        },
        /* 分页相关 */
        handleSizeChange (val, oldVal) {
            this.pageSize = val;
            this.pageNo = 1;
            this.getList();
        },
        handlePageChange (val, oldVal) {
            this.pageNo = val;
            this.getList();
        },
        onResize () {
            this.$nextTick(() => {
                this.resize();
            });
        },
        resize (){
            let width_wrapper = this.$refs.videoList.clientWidth - 10;
            let width_card = 200;
            let count_max = Math.floor(width_wrapper / (width_card + 2 * 10));
            let margin_px = (width_wrapper - (width_card) * count_max) / count_max / 2;
            let cards = this.$refs.videoList.children;
            for (let i = 0; i < cards.length; i++){
                cards[i].style.marginLeft = `${margin_px}px`;
                cards[i].style.marginRight = `${margin_px}px`;
                cards[i].style.transition = `margin-left margin-right 0.3s`;
                cards[i].style.transitionTimingFunction = `linear`;
            }
        },
        closeDialog () {
            this.dialogVisible = false;
        },
        // 获取萤石小权限token
        getSmallToken (item) {
            let info = {
                dev: item.monitorSerial
            };
            return new Promise((resolve, reject)=> {
                this.$store.dispatch("GetSmallToken", info).then((res) => {
                    this.playInfo = {...this.playInfo, ...{accessToken: res.data}};
                    resolve();
                }).catch((err) => {
                    reject(err);
                });
            });
        },
        // 获取token并播放小窗口预览
        renderVideo (item) {
            this.getSmallToken(item).then(() => {
                this.$nextTick(() => {
                    this.dialogVisible = true;
                    this.$nextTick(() => {
                        this.$refs.videoDialog.style.top = document.documentElement.clientHeight - 360;
                        this.$refs.videoDialog.style.left = document.documentElement.clientWidth - 640;
                        this.$refs.mini.renderVideo();
                    });
                });
            });
        },
        openMiniVideo (item) {
            this.clickType = '1';
            if (!this.isHas_video_preview) {
                this.$message.error("无预览权限");
                return;
            }
            if (!item.onlineStatus) {
                this.$message.error('监控点已离线');
                return;
            }
            if (this.playStyle) {
                this.$store.dispatch('PlayVideoClient', { monitorId: item.monitorId, playType: 'Preview', msgHistoryId: item.id});
            } else {
                if (this.$isIE()) {
                    this.$message.error(this.$msgTxt.VIDEO_NOT_SUPPORT);
                    return;
                }
                this.playInfo = Object.assign({}, { 
                    monitorName: item.monitorName,
                    monitorSerial: item.monitorSerial,
                    channum: item.channum,
                    monitorId: item.monitorId,
                    validateCode: item.validateCode,
                    isencrypt: item.isencrypt
                });
                // 如果是不加密或者是 加密且验证了验证码的就去播放
                if (!item.isencrypt || (item.isencrypt && this.videoValidatedIds.includes(item.id))) {
                    if (this.dialogVisible) {
                        this.$refs.mini.closePreview().then(() => {
                            this.renderVideo(item);
                        });
                    } else {
                        this.renderVideo(item);
                    }
                } else {
                    this.codeCheckDialogVisible = true;
                }
            }
        },
        // 回放相关
        openReplayDialog (item) {
            this.clickType = '2';
            if (!this.isHas_video_replay) {
                this.$message.error("无回放权限");
                return;
            }
            if (!item.onlineStatus) {
                this.$message.error('监控点已离线');
                return;
            }
            if (this.playStyle) {
                this.$store.dispatch('PlayVideoClient', { monitorId: item.monitorId, playType: 'PlayBack', msgHistoryId: item.id});
            } else {
                if (this.$isIE()) {
                    this.$message.error(this.$msgTxt.VIDEO_NOT_SUPPORT);
                    return;
                }
                this.playInfo = Object.assign({}, { 
                    monitorName: item.monitorName,
                    monitorSerial: item.monitorSerial,
                    channum: item.channum,
                    monitorId: item.monitorId,
                    validateCode: item.validateCode,
                    isencrypt: item.isencrypt
                });
                if (!item.isencrypt || (item.isencrypt && this.videoValidatedIds.includes(item.id))) {
                    this.routeToDeatilReplay(item);
                } else {
                    this.codeCheckDialogVisible = true;
                }
            }
        },
        routeToDeatilReplay (item) {
            // let start = new Date(item.enterAlarmTime).getTime();
            // let end = new Date(item.exitAlarmTime).getTime() + 5 * 1000;
            // if (!item.exitAlarmTime) {
            //     end = new Date(item.enterAlarmTime).getTime() + 1 * 60 * 1000;
            // }
            let start = new Date(item.enterAlarmTime).getTime();
            let end = new Date(item.processedExitAlarmTime).getTime();
            this.$router.push({ 
                path: '/app/garbage/video/detail',
                query: {
                    id: this.playInfo.monitorId,
                    monitorSerial: this.playInfo.monitorSerial,
                    channum: this.playInfo.channum,
                    validateCode: this.playInfo.validateCode,
                    isencrypt: this.playInfo.isencrypt,
                    startTime: start,
                    endTime: end,
                    type: '2' // 回放
                } 
            });
        },
        // 设备校验码相关
        checkCodeCb (val) {
            let id = val.monitorId;
            let item = this.videoList.find((item) => item.id === id);
            if (this.clickType === '1') {
                this.openMiniVideo(item);
            } else {
                this.openReplayDialog(item);
            }
        }
    },
    // beforeDestroy () {
    //     if (this.dialogVisible) {
    //         this.$refs.mini.closePreview();
    //     }
    // },
    // activated在组件第一次渲染时会被调用，之后在每次缓存组件被激活时调用
    activated () {
        this.getList();
        if (this.tableType === '1') {
            this.$nextTick(() => {
                this.resize();
            });
        }
    },
    deactivated () {
        if (this.dialogVisible) {
            this.$refs.mini.closePreview();
        }
    }
};
</script>

<style lang="scss">
.video-list {
    position: relative;
    height: 100%;
    overflow: hidden;
    padding: 0;
    .row-amount-4, .row-amount-6 {
        .h-page-search-item {
            width: 30%;
        }
        .h-page-search__action {
            width: calc(40% - 10px)!important;
        }
    }
    .h-page-button-group {
        width: 100%;
    }
    .h-page-action__main {
        height: 97px;
        border: none;
        position: relative;
    }
    .h-page-search {
        border: none;
    }
    .h-page-action__right-action {
        position: absolute;
        right: 0;
        bottom: 10px;
        width: 60px;
    }
    .longbtn {
        width: 96px;
    }
}
.video-org {
    position: relative;
    height: 100%;
    display: flex;
    .m-content {
        height: 100%;
        width: 100%;
        background-color: #fff;
        margin: 8px;
    }
    .m-header {
        position: relative;
        height: 40px;
        line-height: 40px;
        // border-bottom: 1px solid #e5e5e5;
        margin: 0 16px;
        overflow: hidden;
        display: flex;
        justify-content: space-between;
        .right {
            text-align: right;
        }
        .search-input {
            width: 250px;
        }
    }
    .video-body {
        width: 100%;
        height: calc(100% - 8px);
        margin-top: 0px;
        position: relative;
        background: #ffffff;
        overflow: hidden;
        .video-content {
            position: relative;
            width: 100%;
            height: calc(100% - 48px);
        }
        .m-page {
            position: absolute;
            bottom: 0;
            width: calc(100% - 32px);
            left: 0;
            background-color: #fff;
            border-top: 1px solid #e5e5e5;
            margin: 0 16px;
        }
        &.history {
            .video-content {
                height: 100%;
            }
            .m-page {
                display: none;
            }
        }
    }
    .video-cards {
        border-top: 1px solid #e5e5e5;
        position: relative;
        padding: 10px 0;
        display: flex;
        flex-direction: row;
        justify-content: flex-start;
        flex-wrap: wrap;
        height: 100%;
        align-content: flex-start;
        overflow: hidden;
    }
    .m-card {
        margin: 0 12px;
        width: 240px;
        margin-bottom: 24px;
        height: 260px;
        position: relative;
        overflow: hidden;
        background-color: #fff;
        overflow: hidden;
        border: 1px solid #e8e8e8;
        .offline-status {
            position: absolute;
            top: 8px;
            right: 8px;
            width: 40px;
            height: 24px;
            background-color: #4D4D4D;
            border-radius: 2px;
            color: #fff;
            font-size: 12px;
            line-height: 24px;
            text-align: center;
        }
        .hover-body {
            position: absolute;
            width: 240px;
            height: 152px;
            top: 0;
            left: 0;
            background-color: rgba(0, 0, 0, 0.5);
            opacity: 0;
            filter: alpha(opacity = 0);
            cursor: pointer;
            // transition: opacity 0.3s ease-in-out;
            &.disabled {
                cursor: no-drop;
            }
            .detail {
                width: 20px;
                height: 20px;
                margin: 65px auto;
                display: block;
                font-size: 20px;
                color: #fff;
            }
        }
        .video-img {
            width: 240px;
            height: 152px;
            border-bottom: 1px solid #e5e5e5;
            img {
                width: 100%;
                height: 100%;
            }
        }
        .video-info {
            padding: 8px 8px;
        }
        .name, .orgName {
            line-height: 24px;
            height: 24px;
            font-size: 12px;
            color: #4D4D4D;
            width: 184px;
            text-overflow: ellipsis;
            overflow: hidden;
            white-space: nowrap;
            i {
               color: #999;
            }
        }
        .btn-con {
            // display: none;
            position: absolute;
            left: 0;
            right: 0;
            bottom: 0;
            .grid-content {
                height: 32px;
                line-height: 32px;
                text-align: center;
                background: #fff;
                font-size: 14px;
                color: #4d4d4d;
                position: relative;
                display: flex;
                align-items: center;
                justify-content: center;
                &.disabled {
                    cursor: no-drop;
                    color: #999;
                    &:hover {
                        color: #999;
                        cursor: no-drop;
                    }
                }
                &:hover {
                    // color: #2080F7;
                    cursor: pointer;
                }
                &:after {
                    content: " ";
                    position: absolute;
                    width: 2px;
                    top: 10px;
                    bottom: 10px;
                    right: 0;
                    background-color: #D8D8D8;
                }
                &:last-child {
                    &:after {
                        display: none;
                    }
                }
            }
        }
        &:hover {
            box-shadow: 0 3px 10px 2px rgba(0, 0, 0, 0.1);
            transform: scale(1.05);
            .hover-body {
                opacity: 1;
                filter: alpha(opacity = 1);
            }
            .btn-con {
                display: block;
            }
        }
    }
    .video-dialog {
        width: 640px;
        height: 360px;
        position: fixed;
        right: 0;
        bottom: 0;
        z-index: 10000;
    }
    .nodata, .noresult {
        position: absolute;
        top: 0;
        left: 0;
        background-color: #FFFFFF;
        width: 100%;
        z-index: 10;
        bottom: 50px;
        .content {
            position: absolute;
            left: 50%;
            top: 40%;
            margin-left: -200px;
            margin-top: -200px;
            width: 400px;
            height: 400px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            img {
                width: 240px;
                height: 200px;
            }
            p {
                font-size: 14px;
                color: #4C4C4C;
                margin-bottom: 22px;
            }
        }
    }
    .video-table {
    }
    .right-action {
        padding-top: 3px;
    }
}
</style>