<template>
    <div class="iframe-container">
        <!-- <iframe id="iframePage" ref="iframePage" class="sys-frame" src="" frameborder="0" sandbox="allow-same-origin allow-top-navigation allow-forms allow-scripts" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe> -->
        <iframe id="iframePage" ref="iframePage" class="sys-frame" src="" frameborder="0" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>
    </div>
</template>

<script>
import { mapGetters } from "vuex";
export default {
    name: "iframePage",
    components: {},
    props: {
        crumbs: {
            type: Array,
            default: () => []
        }
    },
    data () {
        return {
        };
    },
    mounted () {
        this.render();
    },
    watch: {
        // 针对不同路由使用同一组件iframe.vue之间的路由跳转处理，此时mounted不会执行
        $route (to, from) {
            if (to !== from) {
                this.changePath();
                // this.render();
            }
        }
    },
    computed: {
        ...mapGetters([
            "token"
        ])
    },
    methods: {
        changePath () {
            let self = this;
            let iframe = this.$refs.iframePage;
            let route = this.$route;
            self.settings(iframe.contentWindow, route, false);
        },
        render () {
            let self = this;
            let iframe = this.$refs.iframePage;
            let route = this.$route;
            iframe.src = process.env.SSOURL;
            if (iframe.attachEvent) {
                iframe.attachEvent("onload", function () {
                    self.settings(iframe.contentWindow, route, false);
                });
            } else {
                iframe.onload = function () {
                    self.settings(iframe.contentWindow, route, false);
                };
            }
        },
        settings (win, route, showMenu) {
            let data = {
                type: "settings",
                data: {
                    path: route.path,
                    crumbs: this.crumbs,
                    loginUrl: process.env.LOGINURL,
                    showMenu: showMenu,
                    skin: 1, // 0 是蓝白 1：红白
                    token: this.token,
                    productCode: 'demo'
                }
            };
            console.log(process.env.LOGINURL);
            win.postMessage(data, "*");
        }
    }
};
</script>
<style lang="scss">
.iframe-container {
    width: auto;
    height: 100%;
    overflow: hidden;
    transition: all 0.2s ease-in-out;
}
.sys-frame {
    width: 100%;
    height: 100%;
}
</style>
