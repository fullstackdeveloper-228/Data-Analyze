<template>
    <div class="video-search-history" id="video-search-history">
        <div class="line-txt">
             <p>共<span>{{total}}</span>条查询结果</p>
        </div>
        <div class="prouduct-body">
            <div class="product-content" v-loading="loading" element-loading-text="正在加载中">
                <el-scrollbar :size="4" wrap-class="page-scrollbar__wrap">
                    <div class="video-list" ref="videoList">
                        <div class="m-card" v-for="(item, index) in videoList" :key="index">
                            <div class="video-img">
                                <img :src="item.url || errorImg" :key="item.url" />
                                <div class="offline-status" v-show="!item.onlineStatus">离线</div>
                            </div>
                            <div class="video-info">
                                <div class="name" :title="item.monitorName">
                                    <i class="lidaicon-device-camera"></i>
                                    {{item.monitorName}}
                                </div>
                                <div class="orgName">
                                    <i class="lidaicon-tree-res"></i>
                                    {{item.deviceOrgName}}
                                </div>
                            </div>
                            <el-row class="btn-con">
                                <el-col :span="12" class="grid-content" :class="{disabled: !isHas_video_replay}" title="回放" @click.native="openReplayDialog(item)">
                                    <i class="lidaicon-playback"></i>
                                </el-col>
                                <el-col :span="12" class="grid-content" :class="{disabled: !isHas_video_preview}" title="预览" @click.native="openMiniVideo(item)">
                                    <i class="lidaicon-play"></i>
                                </el-col>
                            </el-row>
                        </div>
                    </div>
                </el-scrollbar>
            </div>
        </div>
        <!-- 占位图start -->
        <div class="noresult" v-if="noresult">
            <div class="content">
                <p>没有符合条件的数据</p>
            </div>
        </div>
        <!-- 占位图 end -->
        <eits-play-window v-if="dialogVisible" ref="mini" v-bind="playInfo" @video-detail="videoDetailCb" @video-close="closeDialog"></eits-play-window>
        <eits-replay-time-picker :visible.sync="replayDialogVisible" :support-cloud="playInfo.supportCloud" @check-func="routeToDeatilReplay"></eits-replay-time-picker>
        <eits-device-code-check :code="playInfo.validateCode" :check-visible.sync="codeCheckDialogVisible" @check-cb="checkCodeCb"></eits-device-code-check>
    </div>
</template>

<script>
import { mapGetters } from "vuex";
import errorImg from "@/assets/video-default-error.png";
export default {
    name: "VideoSearch",
    props: {
        crumbs: {
            type: Array,
            default: () => []
        }
    },
    computed: {
        ...mapGetters([
            "operateCodes",
            "videoValidatedIds"
        ]),
        isHas_video_preview () {
            return this.operateCodes.includes("hikkan_video_preview");
        },
        isHas_video_replay () {
            return this.operateCodes.includes("hikkan_video_replay");
        }
    },
    data () {
        return {
            errorImg: errorImg,
            playInfo: {}, // 视频信息
            keyword: "",
            pageSize: 20,
            pageNo: 1,
            total: 0,
            loading: false,
            dialogVisible: false, // mini视频弹窗
            replayDialogVisible: false, // 回放时间选择弹窗
            codeCheckDialogVisible: false, // 设备验证码校验弹窗
            noresult: false,
            videoList: [],
            playStyle: 0
        };
    },
    mounted () {
        this.handleSearch();
    },
    methods: {
        handleSearch () {
            this.loading = true;
            this.$http({
                method: "post",
                url: this.$api.RES_CAMERA_FINDPAGE_SDK,
                data: {
                    page: this.pageNo,
                    size: this.pageSize,
                    deviceOrgId: "",
                    openStatus: 1,
                    allocationStatus: 1,
                    containAllChildren: true,
                    model: 'CAMERA',
                    nameOrSerialOrDeviceName: this.keyword
                }
            }).then((res) => {
                if (res.data) {
                    this.videoList = res.data.list;
                    this.total = res.data.total;
                    this.$nextTick(() => {
                        this.resize();
                    });
                }
                this.noresult = res.data.total ? false : true;
                this.loading = false;
            }).catch((err) => {
                this.loading = false;
            });
        },
        /* 分页相关 */
        handleSizeChange (val, oldVal) {
            this.pageSize = val;
            this.pageNo = 1;
            this.handleSearch();
        },
        handlePageChange (val, oldVal) {
            this.pageNo = val;
            this.handleSearch();
        },
        onResize () {
            this.$nextTick(() => {
                this.resize();
            });
        },
        resize (){
            let width_wrapper = this.$refs.videoList.clientWidth - 10;
            let width_card = 200;
            let count_max = Math.floor(width_wrapper / (width_card + 2 * 10));
            let margin_px = (width_wrapper - (width_card) * count_max) / count_max / 2;
            let cards = this.$refs.videoList.children;
            for (let i = 0; i < cards.length; i++){
                cards[i].style.marginLeft = `${margin_px}px`;
                cards[i].style.marginRight = `${margin_px}px`;
                // cards[i].style.transition = `all 0.3s`;
                cards[i].style.transition = `margin-left margin-right 0.3s`;
                cards[i].style.transitionTimingFunction = `linear`;
            }
        },
        closeDialog () {
            this.dialogVisible = false;
        },
        // 获取萤石小权限token
        getSmallToken (item) {
            let info = {
                dev: item.monitorSerial
            };
            return new Promise((resolve, reject)=> {
                this.$store.dispatch("GetSmallToken", info).then((res) => {
                    this.playInfo = Object.assign({}, {
                        monitorName: item.monitorName,
                        monitorSerial: item.monitorSerial,
                        channum: item.channum,
                        monitorId: item.id,
                        validateCode: item.validateCode,
                        accessToken: res.data
                    });
                    // this.playInfo = {...this.playInfo, ...{accessToken: res.data}};
                    resolve();
                }).catch((err) => {
                    reject(err);
                });
            });
        },
        // 获取token并播放小窗口预览
        renderVideo (item) {
            this.getSmallToken(item).then(() => {
                this.$nextTick(() => {
                    this.dialogVisible = true;
                    this.$nextTick(() => {
                        this.$refs.mini.renderVideo();
                    });
                });
            });
        },
        openMiniVideo (item) {
            this.clickType = '1';
            if (!this.isHas_video_preview) {
                this.$message.error("无预览权限");
                return;
            }
            if (!item.onlineStatus) {
                this.$message.error('监控点已离线');
                return;
            }
            if (this.$utils.isIE() && !this.playStyle) {
                this.$message.error('该浏览器不支持使用h5播放器，请使用平台播放器');
                return;
            }
            if (this.playStyle) {
                this.$store.dispatch('PlayVideoClient', { id: item.id, playType: 'Preview'});
            } else {
                // 如果是不加密或者是 加密且验证了验证码的就去播放
                if (!item.isencrypt || (item.isencrypt && this.videoValidatedIds.includes(item.id))) {
                    if (this.dialogVisible) {
                        this.$refs.mini.closePreview().then(() => {
                            this.renderVideo(item);
                        });
                    } else {
                        this.renderVideo(item);
                    }
                } else {
                    this.codeCheckDialogVisible = true;
                }
            }
        },
        // 回放相关
        openReplayDialog (item) {
            this.clickType = '2';
            if (!this.isHas_video_replay) {
                this.$message.error("无回放权限");
                return;
            }
            if (!item.onlineStatus) {
                this.$message.error('监控点已离线');
                return;
            }
            if (this.$utils.isIE() && !this.playStyle) {
                this.$message.error('该浏览器不支持使用h5播放器，请使用平台播放器');
                return;
            }
            if (this.playStyle) {
                this.$store.dispatch('PlayVideoClient', { id: item.id, playType: 'PlayBack'});
            } else {
                let playInfo = {
                    monitorName: item.monitorName,
                    monitorSerial: item.monitorSerial,
                    channum: item.channum,
                    monitorId: item.id,
                    validateCode: item.validateCode,
                    supportCloud: item.supportCloud,
                    accessToken: this.playInfo.accessToken
                };
                this.playInfo = playInfo;
                // 如果是不加密或者是 加密且验证了验证码的就去播放
                if (!item.isencrypt || (item.isencrypt && this.videoValidatedIds.includes(item.id))) {
                    this.replayDialogVisible = true;
                } else {
                    this.codeCheckDialogVisible = true;
                }
            }
        },
        videoDetailCb () {
            this.$router.push({
                path: "/app/videodemo/detail",
                query: {
                    id: this.playInfo.monitorId,
                    monitorSerial: this.playInfo.monitorSerial,
                    channum: this.playInfo.channum,
                    validateCode: this.playInfo.validateCode,
                    type: "1" // 预览
                }
            });
        },
        routeToDeatilReplay (val) {
            let start = val.startTime;
            let end = val.endTime;
            let recType = val.recType;
            let videoInfo = {
                deviceSerial: this.playInfo.monitorSerial,
                channelNo: this.playInfo.channum,
                startTime: start,
                endTime: end,
                recType: recType
            };
            this.$http({
                method: "post",
                url: this.$api.GET_RECORD_LIST,
                data: videoInfo
            }).then((res) => {
                if (res.data && res.data.length) {
                    this.$router.push({
                        path: '/app/videodemo/detail',
                        query: {
                            id: this.playInfo.monitorId,
                            monitorSerial: this.playInfo.monitorSerial,
                            channum: this.playInfo.channum,
                            validateCode: this.playInfo.validateCode,
                            startTime: start,
                            endTime: end,
                            recType: recType,
                            type: '2' // 回放
                        }
                    });
                } else {
                    this.$alert("", "该时间段没有录像片段", {
                        confirmButtonText: "确定",
                        callback: () => {}
                    });
                }
            }).catch((err) => {
                console.log(err);
            });
        },
        // 设备校验码回调
        checkCodeCb (val) {
            let id = val.monitorId;
            let item = this.videoList.find((item) => item.id === id);
            if (this.clickType === '1') {
                this.openMiniVideo(item);
            } else {
                this.openReplayDialog(item);
            }
        }
    },
    beforeDestroy () {
        if (this.dialogVisible) {
            this.$refs.mini.closePreview();
        }
    }
};
</script>
<style lang="scss">
.video-search-history .search-input .el-input__inner {
    height: 40px;
}
</style>
<style lang="scss" scoped>
.video-search-history {
    position: relative;
    height: calc(100% - 40px);
    .m-header {
        width: 100%;
        text-align: center;
        padding: 24px 0 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        .search-input {
            width: 536px;
            height: 40px;
        }
        .longbtn {
            width: 96px;
            height: 40px;
        }
    }
    .line-txt {
        font-size: 12px;
        padding: 5px 0;
        margin: 0 20px;
        border-bottom: 1px solid #eee;
        color: #999;
        span {
            line-height: 12px;
            color: #ff952c;
            font-size: 14px;
        }
    }
    .prouduct-body {
        width: 100%;
        height: calc(100% - 100px);
        margin-top: 0px;
        position: relative;
        .product-content {
            position: relative;
            width: 100%;
            height: 100%;
        }
    }
    .video-list {
        position: relative;
        padding: 16px 0;
        display: flex;
        flex-direction: row;
        justify-content: flex-start;
        flex-wrap: wrap;
        height: 100%;
        align-content: flex-start;
        overflow: hidden;
    }
    .m-card {
        margin: 0 12px;
        width: 200px;
        margin-bottom: 24px;
        height: 176px;
        position: relative;
        overflow: hidden;
        background-color: #fff;
        overflow: hidden;
        border: 1px solid #e8e8e8;
        .offline-status {
            position: absolute;
            top: 8px;
            right: 8px;
            width: 40px;
            height: 24px;
            background-color: #4D4D4D;
            border-radius: 2px;
            color: #fff;
            font-size: 12px;
            line-height: 24px;
            text-align: center;
        }
        .hover-body {
            position: absolute;
            width: 200px;
            height: 112px;
            top: 0;
            left: 0;
            background-color: rgba(0, 0, 0, 0.5);
            opacity: 0;
            filter: alpha(opacity = 0);
            cursor: pointer;
            // transition: opacity 0.3s ease-in-out;
            &.disabled {
                cursor: no-drop;
            }
            img {
                width: 40px;
                height: 40px;
                margin: 36px auto;
                display: block;
            }
        }
        .video-img {
            width: 200px;
            height: 112px;
            border-bottom: 1px solid #e5e5e5;
            img {
                width: 100%;
                height: 100%;
            }
        }
        .video-info {
            padding: 8px 8px;
        }
        .name, .orgName {
            line-height: 24px;
            height: 24px;
            font-size: 12px;
            color: #4D4D4D;
            width: 184px;
            text-overflow: ellipsis;
            overflow: hidden;
            white-space: nowrap;
            i {
               color: #999;
            }
        }
        .btn-con {
            display: none;
            position: absolute;
            left: 0;
            right: 0;
            bottom: 0;
            .grid-content {
                height: 32px;
                line-height: 32px;
                text-align: center;
                background: #fff;
                font-size: 14px;
                color: #4d4d4d;
                position: relative;
                display: flex;
                align-items: center;
                justify-content: center;
                &.disabled {
                    cursor: no-drop;
                    color: #999;
                    &:hover {
                        color: #999;
                        cursor: no-drop;
                    }
                }
                &:hover {
                    // color: #2080F7;
                    cursor: pointer;
                }
                &:after {
                    content: " ";
                    position: absolute;
                    width: 2px;
                    top: 10px;
                    bottom: 10px;
                    right: 0;
                    background-color: #D8D8D8;
                }
                &:last-child {
                    &:after {
                        display: none;
                    }
                }
            }
        }
        &:hover {
            box-shadow: 0 3px 10px 2px rgba(0, 0, 0, 0.1);
            transform: scale(1.05);
            .hover-body {
                opacity: 1;
                filter: alpha(opacity = 1);
            }
            .btn-con {
                display: block;
            }
        }
    }
    .video-dialog {
        width: 640px;
        height: 360px;
        position: fixed;
        right: 0;
        bottom: 0;
        z-index: 10000;
    }
    .noresult {
        position: absolute;
        top: 146px;
        left: 0;
        background-color: #FFFFFF;
        width: 100%;
        z-index: 10;
        bottom: 57px;
        .content {
            position: absolute;
            left: 50%;
            top: 40%;
            margin-left: -200px;
            margin-top: -200px;
            width: 400px;
            height: 400px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            img {
                width: 240px;
                height: 200px;
            }
            p {
                font-size: 14px;
                color: #4C4C4C;
                margin-bottom: 22px;
            }
        }
    }
}
</style>
