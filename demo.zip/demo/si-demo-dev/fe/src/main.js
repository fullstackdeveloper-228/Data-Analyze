import Vue from "vue";
import App from "./App";
import router from "./router";
import store from "./store";
import HUI from "hui";
import Page from '@hui-pro/page';
import Layout from '@hui-pro/layout';
import http from "@/config/http.js";
import msgTxt from "@/config/msgTxt";
import hkReg from "@/utils/reg";
import api from "./api/index";
// import "./sso"; // 第三方登录处理
import Eits from "eits";
import VueLocalStorage from 'vue-localstorage';
import "eits/lib/eits.css";
import EZUIKit from "../static/ezuikit/ezuikit.js";
import VueLazyLoad from "vue-lazyload";
import errorImg from "@/assets/icon/video-default-error.png";
import loaindImg from "@/assets/icon/video-default.png";
import hkDrag from "@/directives/drag.js";
import hkResize from "@/directives/resize.js";
import TM from "./components/index.js";
import Utils from './utils/install.js';

import "hui/lib/hui.css";
import "@hui-pro/page/theme/index.scss";
import "@hui-pro/layout/theme/index.scss";
import "../static/base.css";
import "../static/cover.css";
import "../static/common.css";
import "../static/theme/blue.scss";
import "./permission"; // 登录权限校验
Vue.config.productionTip = false;

Vue.use(HUI);
Vue.use(Layout);
Vue.use(Page);
Vue.use(api);
Vue.use(hkResize);
Vue.use(TM);
Vue.use(Utils);
Vue.use(VueLazyLoad, {
    error: errorImg,
    loading: loaindImg,
    attempt: 1
});
Vue.use(hkDrag);

Vue.use(Eits);
Vue.use(VueLocalStorage);
window.EZUIKit = EZUIKit;

Vue.mixin({
    computed: {
        breadCrumbs () {
            if (this.crumbs) {
                let breadcrumbList = this.crumbs;
                return breadcrumbList.map((item) => ({
                    title: item
                }));
            } else {
                return [];
            }
        }
    }
});

router.beforeEach((to, from, next) => {
    if (to.matched.length === 0) {
        from.name ? next({
            name: from.name
        }) : next("/404");
    } else {
        next(); // 如果匹配到正确跳转
    }
});

new Vue({
  	el: "#app",
  	router,
    store,
  	components: {App},
  	template: "<App/>"
});
