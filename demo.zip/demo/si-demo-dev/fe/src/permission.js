import router from "./router";
import store from "./store";

const whiteList = ["/login", "/404", "/forgetPass", "/resetPassword", "/modifyPassword"];// no redirect whitelist

router.beforeEach((to, from, next) => {
    if (store.getters.token) { // 存在token的情况下
        if (to.path === "/login") { // 若在存在token的情况下，路由为登录时直接进入首页
            next({ path: "/" });
        } else {
            if (store.getters.userInfo.userId == null) { // 判断当前用户是否已拉取完user_info信息
                store.dispatch("GetUserInfo").then((res) => { // 拉取user_info
                    const userInfo = res.data; // note: roles must be a array! such as: ['editor','develop']
                    store.dispatch("GenerateRoutes", userInfo).then(() => { // 根据roles权限生成可访问的路由表
                        router.addRoutes(store.getters.addRouters); // 动态添加可访问路由表
                        store.dispatch("GetSkinAndRequire").then(() => { // 获取主题色并require主题文件
                            next({ ...to, replace: true }); // hack方法 确保addRoutes已完成 ,set the replace: true so the navigation will not leave a history record
                        });
                    });
                }).catch((err) => {
                    store.dispatch("FedLogOut").then(() => {
                        next({ path: "/login" });
                    });
                });
            } else { // 已存在用户信息时，直接进入路由
                next();
            }
        }
    } else {
        // token不存在时
        if (whiteList.indexOf(to.path) !== -1) { // 在免登录白名单，直接进入
            next();
        } else {
            next("/login");
        }
    }
});

router.afterEach(() => {
});
