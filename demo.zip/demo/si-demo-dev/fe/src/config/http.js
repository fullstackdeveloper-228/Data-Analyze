import axios from "axios";
import Vue from "vue";
import serviceCode from "./serviceCode";
import store from "../store";
import router from "../router";
const Qs = require("qs");
import { Message } from "hui";
import Token from "@/utils/token";

// 创建请求实例
const req = axios.create({
    baseURL: process.env.NODE_ENV === "development" ? "" : process.env.HOST,
    timeout: 20000,
    headers: {"X-Requested-With": "XMLHttpRequest"}
});

// 添加请求拦截器

req.interceptors.request.use((req) => {
    if (!req.data) {
        req.data = {};
    }
    if (req.reqType === "import") {
        req.headers["Content-Type"] = "multipart/form-data";
    } else {
        // req.data = Qs.stringify(req.data, { indices: false });
    }

    if (store.getters.token) {
        // 让每个请求携带token信息
        req.headers["Authorization"] = Token.getToken();
    }
    return req;
}, (err) => {
    // 对请求错误做些什么
    // TODO 根据后台规则
    console.log(err);
    return Promise.reject(err);
});

// 添加响应拦截器
req.interceptors.response.use((res) => {
    
    if (res.config.responseType === "blob" && res.status === 200){
        return res;
    }
    if (serviceCode.noHandle.includes(res.data.code)) {
        return res.data;
    } 
    if (res.data.code === "401"){ // token失效的具体原因
        store.dispatch("FedLogOut").then(() => {
            router.push({ path: "/login" });
            Message.error(res.data.msg);
        });
        return Promise.reject("error");
    } else {
        // 需要弹窗提示的业务
        store.commit("SET_ERR_MSG", res.data.msg);
        if (res.data.code !== "200") return Promise.reject(res.data);
        else return new Promise(() => {});
    }
}, (err) => {
    // 对请求错误做些什么
    // TODO 根据后台规则
    console.log(err);
    return Promise.reject(err);
});

Vue.prototype.$http = req;

export default req;
