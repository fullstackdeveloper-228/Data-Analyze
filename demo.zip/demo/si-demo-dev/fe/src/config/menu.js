// 前端菜单配置
const menuConf = [
    {
        "title": "应用中心",
        "router": "/app",
        "icon": "h-icon-menu",
        "group": "0",
        "code": "",
        "children": [
            {
                "title": "全天视频监控",
                "router": "/app/video",
                "code": "hikkan_application_video"
            },
            {
                "title": "垃圾投放监控",
                "router": "/app/garbage/video",
                "code": "hikkan_application_video"
            },
            {
                "title": "视频直播",
                "router": "/app/live",
                "code": "hikkan_application_live"
            },
            {
                "title": "视频SDK",
                "router": "/app/videodemo",
                "code": "hikkan_application_video"
            }
        ]
    },
    {
        "title": "资源中心",
        "router": "/res",
        "icon": "h-icon-internet",
        "group": "0",
        "code": "",
        "children": [
            {
                "title": "组织管理",
                "router": "/res/org",
                "code": "hikkan_res_org"
            },
            {
                "title": "萤石设备",
                "router": "/res/vdevice",
                "code": "hikkan_res_device"
            },
            {
                "title": "NB设备",
                "router": "/res/nbdevice",
                "code": "hikkan_res_nbDevice"
            },
            {
                "title": "垃圾投放点管理",
                "router": "/res/point/list",
                "code": "hikkan_application_video"
            },
            {
                "title": "门禁设备",
                "router": "/res/acdevice",
                "code": "hikkan_res_acDevice"
            },
            {
                "title": "直播设备",
                "router": "/res/live",
                "code": "hikkan_res_live"
            }
        ]
    },
    {
        "title": "用户中心",
        "router": "/user",
        "icon": "h-icon-users",
        "group": "0",
        "code": "hikkan_user",
        "children": [
            {
                "title": "用户管理",
                "router": "/user/management",
                "code": "hikkan_user_list"
            },
            {
                "title": "角色管理",
                "router": "/user/role",
                "code": "hikkan_user_role"
            },
            {
                "title": "部门管理",
                "router": "/user/department",
                "code": "hikkan_user_dept"
            }
        ]
    },
    {
        "title": "管理中心",
        "router": "/dc",
        "icon": "h-icon-histogram",
        "group": "0",
        "code": "hikkan_data",
        "children": [
            {
                "title": "操作日志",
                "router": "/dc/log",
                "code": "hikkan_data_log"
            },
            {
                "title": "批量操作记录",
                "router": "/dc/ioLog",
                "code": "hikkan_data_impExp"
            },
            {
                "title": "卡密管理",
                "router": "/dc/cdkey",
                "code": "hikkan_data_card"
            },
            {
                "title": "数据摆渡",
                "router": "/dc/dataferry",
                "code": "hikkan_data_ferry"
            }, 
            {
                "title": "平台服务",
                "router": "/dc/service",
                "code": "hikkan_data_service"
            }
        ]
    },
    {
        "title": "个人中心",
        "router": "/personal",
        "icon": "h-icon-user",
        "group": "0",
        "code": "hikkan_personal",
        "children": [
            {
                "title": "个人资料",
                "router": "/personal/info",
                "code": "hikkan_personal_info"
            }
        ]
    }
    // {
    //     "title": "应用中心",
    //     "router": "/manage",
    //     "icon": "h-icon-user",
    //     "group": "0",
    //     "code": "voperat_manage",
    //     "children": [
    //         {
    //             "title": "产品管理",
    //             "router": "/manage/product",
    //             "code": "voperat_manage_product"
    //         },
    //         {
    //             "title": "项目管理",
    //             "router": "/manage/project",
    //             "code": "voperat_manage_product"
    //         }
    //     ]
    // },
    , {
        "title": "新Tab打开租户",
        "router": "/open",
        "icon": "h-icon-link",
        "group": "0",
        "code": ""
    }
];

/**
 * 递归过滤动态菜单，返回符合用户角色权限的菜单
 * @param menus 菜单配置数据
 * @param auth 用户有权限的菜单编码数组
 */
function filterDynamicMenu (menus, menuCodes) {
    const res = [];
    menus.forEach((menu) => {
        const tmp = { ...menu };
        // menuCodes中包含code或者code为空则放行
        if (menuCodes.includes(tmp.code) || tmp.code === '') {
            if (tmp.children) {
                tmp.children = filterDynamicMenu(tmp.children, menuCodes);
            }
            res.push(tmp);
        }
    });
    return res;
}

// 根据用户信息生成用户菜单
export function generateMenu (userInfo) {
    // 菜单权限处理
    let menuCodes = userInfo.menuCodes;
    return filterDynamicMenu(menuConf, menuCodes);
}
