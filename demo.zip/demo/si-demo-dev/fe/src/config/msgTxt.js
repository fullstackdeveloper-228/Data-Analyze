import Vue from "vue";

const msgTxt = {
    ADD_SUCCESS: "添加成功",
    EDIT_SUCCESS: "编辑成功",
    VIDEO_NOT_SUPPORT: "该浏览器不支持使用h5播放器，请使用平台播放器",
    PROMOTE_SUCCESS: "升级成功",
    DOWNLOAD_SUCCESS: "下载成功,请到操作记录中查看",
    EXPORT_ORG_SUCCESS: "组织导出成功,请到操作记录中查看",
    EXPORT_DEVICE_SUCCESS: "设备导出成功,请到操作记录中查看",
    IMPORT_SUCCESS: "导入成功",
    EXPORT_FAIL: "导出失败",
    IMPORT_FAIL: "导入失败",
    ADD_DEVICE_SERAIL: "请输入设备序列号",
    ADD_DEVICE_CODE: "请输入设备验证码",
    ADD_DEVICE_NAME: "请输入设备名称",
    SEL_TELOPERATOR: "请选择运营商",
    SEL_NBDEVICE_TYPE: "请选择设备类型",
    SEL_MANUFACTURER: "请选择设备厂商",
    ADD_DEVICE_TYPE: "如未选择，设备可根据设备序列号和验证码自动识别",
    SEL_DEVICE_CHECK: "请先选择设备",
    SEL_CAMERA_CHECK: "请先选择监控点",
    SEL_CHECK: "请先进行选择",
    OPT_DEVICE_SUCCESS: "操作成功",
    CHA_DEVICE_SUCCESS: "设备更改成功",
    DEL_DEVICE_SUCCESS: "设备删除成功",
    CHANGE_DEVICE_ORG: "请先选择设备再进行变更",
    DEL_SUCCESS: "删除成功",
    SPECIAL_TEXT: `不能包含 ' / \\ \: * ? " < > | 特殊字符`,
    // ILLLEGAL_CHAR_TXT: "不能包含'/\:*?\"<>|~`!$%^&()+=特殊字符",
    ILLLEGAL_CHAR_TXT: "不能包含 ' / \\ \: * ? \" < > | 特殊字符",
    BEFORE_ORG_DEL: "若删除该组织，组织下的资源也将被删除，确认删除吗？",
    BEFORE_DEVICE_DEL: "是否确定删除该设备？",
    PHONE_ERROR: `请输入11位正确手机号`,
    ORG_UPLOAD_TXT: "父组织序号：必填，1~2000000000之间的整数",
    ORG_UPLOAD_TXT2: "组织序号：  必填，1~2000000000之间的整数",
    ORG_UPLOAD_TXT3: "组织名称：  必填，1～32个字符；不能包含 ' / : * ? \" < > | 这些特殊字符",

    DEVICE_UPLOAD_TXT: "设备序列号：必填，1～32个字符；不能包含 ' / : * ? \" < > | 这些特殊字符",
    DEVICE_UPLOAD_TXT2: "设备名称：  必填，1～32个字符；不能包含 ' / : * ? \" < > | 这些特殊字符",
    DEVICE_UPLOAD_TXT3: "设备验证码：必填，1～32个字符；不能包含 ' / : * ? \" < > | 这些特殊字符",
    DEVICE_UPLOAD_TXT4: "设备类型：  必填，目前支持CAMERA（视频设备）、ALARM（报警设备）、ACCESS（门禁设备）三种",
    CAMERA_UPLOAD_TXT: "监控点编号：必填，1～32个字符；不能包含 ' / : * ? \" < > | 这些特殊字符",
    CAMERA_UPLOAD_TXT2: "监控点名称：非必填，1～32个字符；不能包含 ' / : * ? \" < > | 这些特殊字符",
    CAMERA_UPLOAD_TXT3: "OSD信息：非必填，1～32个字符；不能包含 ' / : * ? \" < > | 这些特殊字符",
    CAMERA_UPLOAD_TXT4: "分配状态：非必填，0：未分配；1：已分配",
    NO_RESULT_DATA: "暂无数据",
    NO_FIND_DATA: "没有符合条件的数据",
    ING_QUERY_DATA: "正在查询数据..."
};

Vue.prototype.$msgTxt = msgTxt;

export default msgTxt;

