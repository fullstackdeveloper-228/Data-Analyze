import uTils from "./index.js";

const _uTils = Object.create({});
for (let obj in uTils) {
    for (let key in uTils[obj])
        _uTils[key] = uTils[obj][key];
}

const install = (Vue) => {
    Vue.prototype.$utils = _uTils;
};

export default {
    install
};