import util from "./util.js";
import dom from "./dom.js";
import token from "./token.js";

export default {
    util,
    dom,
    token
};
