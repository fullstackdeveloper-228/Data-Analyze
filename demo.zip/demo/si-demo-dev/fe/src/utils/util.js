import CryptoJS from "crypto-js";

export default {
    /**
     * 获取密码的强度
     * 等级0（风险密码）：密码长度小于8位，或者只包含4类字符中的任意一类，或者密码与用户名一样，或者密码是用户名的倒写。
     * 等级1（弱密码）：包含两类字符，且组合为（数字+小写字母）或（数字+大写字母），且长度大于等于8位。
     * 等级2（中密码）：包含两类字符，且组合不能为（数字+小写字母）和（数字+大写字母），且长度大于等于8位。
     * 等级3（强密码）：包含三类字符及以上，且长度大于等于8位。
     * @author chenguanbin
     * @date   2016-01-27
     * @param  {String}   szPwd 密码
     * @param  {String}   szUser 用户名
     * @return {Number}     密码强度
     */
    getPwdRank (szPwd, szUser) {
        let iRank = 0;
        szPwd.match(/[a-z]/g) && iRank++;
        szPwd.match(/[A-Z]/g) && iRank++;
        szPwd.match(/[0-9]/g) && iRank++;
        szPwd.match(/[^a-zA-Z0-9]/g) && iRank++;
        iRank = iRank > 3 ? 3 : iRank;
        if (
            szPwd.length < 8 ||
            iRank === 1 ||
            szPwd === szUser ||
            szPwd === szUser.split("").reverse().join("")
        ) {
            iRank = 0;
        }
        if (iRank === 2) {
            if (
                (szPwd.match(/[0-9]/g) && szPwd.match(/[a-z]/g)) ||
                (szPwd.match(/[0-9]/g) && szPwd.match(/[A-Z]/g))
            ) {
                iRank = 1;
            }
        }
        return iRank;
    },

    /**
     * 通用用户密码SHA256加密方法，用于验证密码
     * @param password 密码
     * @param salt 加密的盐
     * @param vCode 挑战码
     * @returns {String}  加密后密码
     */
    pwdHashEncryptVerify (password, salt, vCode) {
        return CryptoJS.SHA256(CryptoJS.SHA256(password + salt).toString() + vCode).toString();
    },
    /**
     * 通用用户密码SHA256加密方法，用于保存密码
     * @param password 密码
     * @param salt 加密的盐
     * @returns {String}  加密后密码
     */
    pwdHashEncryptSave (password, salt) {
        return CryptoJS.SHA256(password + salt).toString();
    },
    /**
     * 通用用户密码SHA256加密方法
     * @param password 密码
     * @param salt 加密的盐（可不传）
     * @returns {String}  加密后密码
     */
    pwdHashEncrypt (password, salt) {
        salt = salt ? salt : "hikyun";
        return CryptoJS.SHA256(CryptoJS.SHA256(password + salt).toString()).toString();
    },
    /**
     * 用户密码AES加密方法
     * @param password 密码
     * @param aesKey 密钥（可传用户名）
     * @returns {String}  加密后密码
     */
    pwdAesEncrypt (password, aesKey, salt) {
        let key = CryptoJS.SHA256(CryptoJS.SHA256(aesKey).toString() + salt).toString().substr(0, 16);
        let vi = CryptoJS.SHA256(key).toString().substr(0, 16);
        key = CryptoJS.enc.Utf8.parse(key);
        vi = CryptoJS.enc.Utf8.parse(vi);
        let encryptedPwd = CryptoJS.AES.encrypt(password, key, { iv: vi, mode: CryptoJS.mode.CFB, padding: CryptoJS.pad.ZeroPadding }).toString();
        return encryptedPwd;
    },

    /**
     * 判断是否为ie浏览器
     * @author Le Sixiang
     * @return {Boolean}
     */
    isIE () {
        if (!!window.ActiveXObject || "ActiveXObject" in window) {
            return true;
        } else {
            return false;
        }
    },
    /**
     * [getDefaultTreeNodeData 获得树组织初始化可选节点数据]
     * @author Pengfei Lei
     * @date   2019-01-31T19:52:36+0800
     * @param  {Array}                 treeData [树形原始数据]
     * @param  {String}                 key      [关键字]
     * @param  {String or Boolean}                 value    [关键字的值]
     * @return {Object}                          [返回数组织任意一可选节点，采用BFS策略]
     */
    getDefaultTreeNodeData (treeData, key, value) {
        let flag;
        treeData.forEach((node) => {
            if (node[key] === value) {
                flag = node;
                return;
            }
            flag = this.getDefaultTreeNodeData(node.children, key, value);
        });
        return flag;
    },
    /**
     * [getRandomNum0to9 生成0-9随机数]
     * @author Pengfei Lei
     * @date   2018-11-29T19:32:36+0800
     * @return {[type]}                 [description]
     */
    getRandomNum0to9 () {
        return (Math.floor(10 * Math.random())).toString();
    },

    /**
     * [getIndexCode 生成n位随机数]
     * @author Pengfei Lei
     * @date   2018-11-29T19:31:30+0800
     * @param  {Number}                 x [随机数位数]
     * @return {String}                   [x位随机数]
     */
    getIndexCode (x = 16) {
        let d = (new Date()).getTime().toString();
        let r = "";
        if (x <= 13) {
            return d.substr(0, x);
        }
        do {
            x--;
            r += this.getRandomNum0to9();
        } while (x > 13);
        return d + r;
    },

    /**
     * [getCSTime China Standard Time 获得中国标准时]
     * @author Pengfei Lei
     * @date   2019-01-09T19:36:32+0800
     * @param  {Object}                 date [时间对象new Date()]
     * @return {String}                      [中国标准时]
     */
    getCSTime (date) {
        let arr = date.toString().split(" ");
        return arr[0] + " " + arr[1] + " " + arr[2] + " " + arr[4] + " CST " + arr[3];
    },

    /**
     * [getGMTime 获得GMT时间]
     * @author Pengfei Lei
     * @date   2019-03-19T10:39:05+0800
     * @param  {Object}                 date [时间对象new Date()]
     * @return {String}                      [GMTime]
     */
    getGMTime (val) {
        if (val) {
            val = val.toString();
            let arr = val.split(" ");
            arr.splice(6, 1);
            let result = arr.join(" ");
            return result;
        }
    },

    /**
     * [getNORTime 获得云曜平台时间格式]
     * @author Pengfei Lei
     * @date   2019-04-18T11:05:11+0800
     * @param  {Object}                 date [时间对象new Date()]
     * @return {String}                      [yyyy-MM-dd'T'HH:mm:ss:SSS+08:00]
     */
    getNORTime (date) {
        let pad = (str) => {
            if (typeof str !== "string")
                str = str.toString();
            return str.padStart(2, "0");
        };
        return date.getFullYear() + "-" + pad(date.getMonth() + 1) + "-" + pad(date.getDate()) + "T" + pad(date.getHours()) + ":" + pad(date.getMinutes()) + ":" + pad(date.getSeconds()) + "." + pad(date.getMilliseconds()) + "0+08:00";
    },

    /**
     * [getTodayTime 获得云曜平台当天时间格式]
     * @author Pengfei Lei
     * @date   2019-04-18T11:55:24+0800
     * @return {Array}                 [起始时间, 结束时间]
     */
    getTodayTime () {
        let time = this.getNORTime(new Date());
        let startTime = time.substr(0, 11) + "00:00:00.000+08:00";
        let endTime = time.substr(0, 11) + "23:59:59.000+08:00";
        return [startTime, endTime];
    },

    /**
     * [getTodayTime 下载文件]
     * @author Pengfei Lei
     * @date   2019-02-07T11:55:24+0800
     */
    downLoadFile (blob, fileName) {
        if ("download" in document.createElement("a")) {
            let downloadElement = document.createElement("a");
            let href = "";
            if (window.URL)
                href = window.URL.createObjectURL(blob);
            else
                href = window.webkitURL.createObjectURL(blob);
            downloadElement.href = href;
            downloadElement.download = fileName;
            document.body.appendChild(downloadElement);
            downloadElement.click();
            if (window.URL)
                window.URL.revokeObjectURL(href);
            else
                document.body.removeChild(downloadElement);
        } else {
            navigator.msSaveBlob(blob, fileName);
        }
    },
    /**
     * [getIndexCode 生成n位随机数]
     * @author Pengfei Lei
     * @date   2018-11-29T19:31:30+0800
     * @param  {Number}                 x [随机数位数]
     * @return {String}                   [x位随机数]
     */
    getIndexCode (x = 16) {
        let d = (new Date()).getTime().toString();
        let r = "";
        if (x <= 13) {
            return d.substr(0, x);
        }
        do {
            x--;
            r += this.getRandomNum0to9();
        } while (x > 13);
        return d + r;
    }
};


