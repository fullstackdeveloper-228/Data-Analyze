import Vue from "vue";

const hkReg = {
    deviceName: /^[a-zA-Z0-9~`!@#\$%^&*()_+\-=\[\];',<.>/|?]{1,32}$/,

    specail: /^[^'\/\\:\*\?"<>\|]*$/,

    // illegalChar: /^[^'\/\\:：\*\?？&$%!！~()（）=+~`"<>\|]*$/, // 留着日后用
    illegalChar: /^[^'\/\\:\*\?"<>\|]*$/,

    email: /(^\w+((-\w+)|(\.\w+))*@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$)|(^$)/,

    phoneNum: /^1\d{10}$/
};

Vue.prototype.$hkReg = hkReg;

export default hkReg;

