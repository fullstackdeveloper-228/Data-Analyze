/* istanbul ignore next */
export default {
    /**
     * @desc 判断DOM元素是否具有指定的class
     * @author lesixiang
     * @param {Document} el DOM元素
     * @param {String} cls 样式类
     */
    hasClass (el, cls) {
        if (!el || !cls) return false;
        if (cls.indexOf(" ") !== -1)
            throw new Error("className should not contain space.");
        if (el.classList) {
            return el.classList.contains(cls);
        } else {
            return (" " + el.className + " ").indexOf(" " + cls + " ") > -1;
        }
    },

    /**
     * @desc 为 DOM 元素添加 class
     * @author lesixiang
     * @param {Document} el DOM元素
     * @param {String} cls 样式类
     */
    addClass (el, cls) {
        if (!el) return;
        let curClass = el.className;
        let classes = (cls || "").split(" ");

        for (let i = 0, j = classes.length; i < j; i++) {
            let clsName = classes[i];
            if (!clsName) continue;

            if (el.classList) {
                el.classList.add(clsName);
            } else {
                if (!this.hasClass(el, clsName)) {
                    curClass += " " + clsName;
                }
            }
        }
        if (!el.classList) {
            el.className = curClass;
        }
    },

    /**
     * @desc 为 DOM 元素删除 class
     * @author lesixiang
     * @param {Document} el DOM元素
     * @param {String} cls 样式类
    */
    removeClass (el, cls) {
        if (!el || !cls) return;
        let classes = cls.split(" ");
        let curClass = " " + el.className + " ";

        for (let i = 0, j = classes.length; i < j; i++) {
            let clsName = classes[i];
            if (!clsName) continue;

            if (el.classList) {
                el.classList.remove(clsName);
            } else {
                if (this.hasClass(el, clsName)) {
                    curClass = curClass.replace(" " + clsName + " ", " ");
                }
            }
        }
        if (!el.classList) {
            el.className = trim(curClass);
        }
    },

    /**
     * @desc 返回滚动条的滚动高度
     * @author lesixiang
     * @param {Boolean} top 是否是获取顶部的左上角的Y坐标
     */
    getScroll (top) {
        let ret = window["page" + (top ? "Y" : "X") + "Offset"];
        let method = "scroll" + (top ? "Top" : "Left");
        if (typeof ret !== "number") {
            let d = window.document;
            // ie6,7,8 standard mode
            ret = d.documentElement[method];
            if (typeof ret !== "number") {
                // quirks mode
                ret = d.body[method];
            }
        }
        return ret;
    },

    /**
     * @desc 返回当前页面相对于窗口显示区左上角的 X ，Y 的位置
     * @author lesixiang
     * @param {Document} el 需要获取位置的元素
     * @param {Document} container 容器元素
     */
    getOffset (el, container = document.body) {
        const elRect = el.getBoundingClientRect();
        const containerRect = container.getBoundingClientRect();
        const clientTop = el.clientTop || container.clientTop || 0;
        const clientLeft = el.clientLeft || container.clientLeft || 0;
        let top, left;

        if (container === document.body) {
            top = this.getScroll(true);
            left = this.getScroll();
        } else {
            top = container.scrollTop - containerRect.top;
            left = container.scrollLeft - containerRect.left;
        }

        return {
            top: elRect.top + top - clientTop,
            left: elRect.left + left - clientLeft,
            right: elRect.right + left - clientLeft,
            bottom: elRect.bottom + top - clientTop
        };
    }
};
