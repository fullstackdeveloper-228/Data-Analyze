const TokenKey = "Hikkan-Token";

export default {
    getToken () {
        return sessionStorage.getItem(TokenKey);
    },
    setToken (token) {
        return sessionStorage.setItem(TokenKey, token);
    },
    removeToken () {
        return sessionStorage.removeItem(TokenKey);
    }
};