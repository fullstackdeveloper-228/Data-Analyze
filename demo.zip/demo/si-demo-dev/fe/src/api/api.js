/** 登录相关接口**/
// const LOGIN = "/garbage/web/login";
// const LOGOUT = "/garbage/web/logout";
// const VERIFY_CODE = "/garbage/web/verifyCode"; // 滑动检测codeId
// const UPDATE_PSWD = "/garbage/web/updatePwd"; // 右上角登录用户的modify修改密码弹窗组件，首次登录强制modify修改密码
// const GET_USER_INFO = "/garbage/web/auths"; // 登录用户的基础信息和权限信息
// const PHONE_STATUS = "/garbage/web/user/phone/status"; // (忘记)找回密码: 判断手机号是否已绑定账户
// const GET_VERIFYCODE = "/garbage/web/phone/verifyCode"; // 获取手机验证码
// const CHECK_VERIFYCODE = "/garbage/web/phone/checkCode"; // 手机验证码验证
// const CHANGE_PWD = "/garbage/web/changePwd"; // （忘记）找回密码的reset密码
// const CHALLENGE_CODE = "/garbage/web/challengeCode"; // 登录挑战码
// const GET_SKIN = "/garbage/web/productService/products/skin"; // 获取产品皮肤主题

        
/* *************** 垃圾投放监控start ********************/
const GET_GARBAGE_VIDEO_LIST = "/garbage/web/msg/page"; // 分页获取垃圾抓拍列表
const GET_CAMERA_DETAIL = "/garbage/web/monitor/find/by/id"; // 单个监控点详情
const GET_RECORD_LIST = "/garbage/web/monitor/video/by/time"; // 获取一段时间内的视频片段列表
const GET_SMALL_TOKEN = "/garbage/web/user/ys/restricted/token/get"; // 获取萤石小token
const PTZ_CONTROL = "/garbage/web/monitor/ptz"; // 云台操作相关
const VIDEO_XML_GET = "/garbage/web/monitor/play/xml/get"; // 平台播放器监控点xml信息
/* *************** 垃圾投放监控 end  *********************/


/* *************** 垃圾点管理 start ********************/
const GET_POINT_LIST = "/garbage/web/point/page"; // 分页获取垃圾点列表
const GET_ORG_TREE = "/garbage/web/org/tree"; // 全局组织树
const MOD_POINT = "/garbage/web/point/save"; // 新增或者修改垃圾点
const GET_POINT_BYID = "/garbage/web/point/get"; // 垃圾点基本信息（监控点id数组，NB设备id数组）
const GET_MONITOR_PAGE = "/garbage/web/monitor/page"; // 分页获取某组织下的监控点列表
const GET_NB_PAGE = "/garbage/web/device/nb/page"; // 分页获取某组织下的nb设备列表
const DEL_POINT = "/garbage/web/point/delete"; // 批量删除垃圾点
/* *************** 垃圾点管理 end ********************/

/* *************** 视频SDK Demo start ********************/
const RES_CAMERA_FINDPAGE_SDK = "/eits/video/monitor/find/page"; // 全局查询可播放的视频列表
const GET_RECORD_LIST_SDK = "/eits/video/by/time"; // 获取一段时间内的视频片段列表
const GET_SMALL_TOKEN_SDK = "/eits/video/restricted/token/get"; // 获取萤石小token
const PTZ_CONTROL_SDK = "/eits/video/device/ptz"; // 云台操作相关
const RES_CAMERA_DETAIL_SDK = "/eits/video/monitor/find/by/id"; // 获取单个视频信息
/* *************** 视频SDK Demo end ********************/

/* *************** loginSDK Demo start ********************/
const LOGIN_SDK = "/eits/login"; // 登录
const VERIFY_CODE_SDK = "/eits/login/verifyCode"; // 滑动检测
const CHALLENGE_CODE_SDK = "/eits/login/challengeCode"; // 请求挑战码
const PHONE_STATUS_SDK = "/eits/login/phone/status"; // 手机认证状态校验
const GET_FORCE_VERIFYPHONENO_VERIFYCODE = "/eits/login/user/phone/verifyCode"; // 登录的强制认证手机号获取验证码接口
const CHECK_FORCE_VERIFYPHONENO_VERIFYCODE = "/eits/login/user/phone/checkCode"; // 登录的强制认证手机号校验验证码接口
const CHANGE_WEAK_PWD = "/eits/login/user/pwd/update"; //  修改密码接口（需要token）用于首次登陆或者弱密码

const PHONE_VERIFY_CODE_SDK = "/eits/login/phone/verifyCode"; // 忘记密码请求手机验证码
const CHECK_CODE_SDK = "/eits/login/phone/checkCode "; // 忘记密码的校验手机验证码
const CHANGE_PWD_SDK = "/eits/login/changePwd"; // 修改密码 (忘记密码去重置的时候)
const UPDATE_PWD_SDK = "/eits/login/user/pwd/update"; // 修改密码接口（需要token）用于首次登陆或者弱密码，或者右上角主动修改密码,用户列表右侧修改密码的情况
const LOGOUT_SDK = "/eits/logout";
/* *************** login Demo end ********************/
const GET_USER_INFO = "/garbage/web/auths"; // 登录用户的基础信息和权限信息


export default {
    /* LOGIN,
    LOGOUT,
    VERIFY_CODE,
    UPDATE_PSWD,
    GET_USER_INFO,
    PHONE_STATUS,
    GET_VERIFYCODE,
    CHECK_VERIFYCODE,
    CHANGE_PWD,
    CHALLENGE_CODE,
    GET_SKIN,*/
    GET_GARBAGE_VIDEO_LIST,
    GET_CAMERA_DETAIL,
    GET_RECORD_LIST,
    GET_SMALL_TOKEN,
    PTZ_CONTROL,
    VIDEO_XML_GET,
    GET_USER_INFO,
    // point
    GET_POINT_LIST,
    GET_ORG_TREE,
    MOD_POINT,
    GET_POINT_BYID,
    GET_MONITOR_PAGE,
    GET_NB_PAGE,
    DEL_POINT,
    // video sdk
    RES_CAMERA_FINDPAGE_SDK,
    GET_RECORD_LIST_SDK,
    GET_SMALL_TOKEN_SDK,
    PTZ_CONTROL_SDK,
    RES_CAMERA_DETAIL_SDK,
    // login sdk
    LOGIN_SDK,
    LOGOUT_SDK,
    VERIFY_CODE_SDK,
    CHALLENGE_CODE_SDK,
    PHONE_VERIFY_CODE_SDK,
    CHECK_CODE_SDK,
    CHANGE_PWD_SDK,
    UPDATE_PWD_SDK,
    PHONE_STATUS_SDK,
    GET_FORCE_VERIFYPHONENO_VERIFYCODE,
    CHECK_FORCE_VERIFYPHONENO_VERIFYCODE,
    CHANGE_WEAK_PWD
};


