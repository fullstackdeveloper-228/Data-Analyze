const getters = {
    token: (state) => state.user.token,
    userInfo: (state) => state.user,
    operateCodes: (state) => state.user.operateCodes,
    skin: (state) => {
        if (sessionStorage.getItem("Hikkan-Skin")) {
            state.skin = sessionStorage.getItem("Hikkan-Skin");
        }
        return state.skin;
    },
    addRouters: (state) => state.permission.addRouters,
    playStyle: (state) => state.video.playStyle,
    videoValidatedIds: (state) => state.video.videoValidatedIds
};
export default getters;
