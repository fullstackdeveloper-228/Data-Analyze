const mutations = {
    SET_ERR_MSG (state, msg) {
        state.errMsg = msg;
    },
    CLR_ERR_MSG (state) {
        state.errMsg = null;
    },
    SET_LOGIN_URL (state, url) {
        state.loginUrl = url;
    },
    SET_MENU_SHOW (state, menuShow) {
        state.menuShow = menuShow;
    },
    SET_MENU_ISCOLLAPSE (state, isCollapse) {
        state.isCollapse = isCollapse;
    }
};

export default mutations;
