import http from "@/config/http";
import api from "@/api/api";

const info = {
    state: {
        expireInfo: ""
    },
    mutations: {
        SET_EXPIREINFO: (state, expireInfo) => {
            state.expireInfo = expireInfo;
        }
    },
    actions: {
        GetExpireInfo ({ commit }, expireInfo) {
            return new Promise((resolve, reject) => {
                http({
                    method: "post",
                    url: api.GET_EXPIRE_INFO
                }).then((res) => {
                    if (res.code === "200") {
                    	if (res.data) {
                            commit("SET_EXPIREINFO", res.data + "，请联系管理员");
                    	} else {
                    		commit("SET_EXPIREINFO", "");
                    	}
                    	resolve(res);
                    } else {
                    	reject(res);
                    }
                }).catch((err) => {
                    console.log(err);
                });
            });
        }
    }
};

export default info;