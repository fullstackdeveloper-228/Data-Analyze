import { dynamicRouters, constantRouters } from "@/router";


/**
 * 通过meta.authCode判断是否与当前用户权限匹配
 * @param roles
 * @param route
 */
function hasPermission (menuCodes, route) {
    if (route.meta && route.meta.authCode) {
        return menuCodes.includes(route.meta.authCode);
    } else { // 未设置authCode默认有权限
        return true;
    }
}

/**
 * 递归过滤动态路由表，返回符合用户角色权限的路由表
 * @param routes dynamicRouters
 * @param auth 用户有权限的菜单编码数组
 */
function filterDynamicRouter (routes, authCodes) {
    const res = [];
    routes.forEach((route) => {
        const tmp = { ...route };
        if (hasPermission(authCodes, tmp)) {
            if (tmp.children) {
                tmp.children = filterDynamicRouter(tmp.children, authCodes);
            }
            res.push(tmp);
        }
    });
    return res;
}

const permission = {
    state: {
        routers: constantRouters,
        addRouters: []
    },
    mutations: {
        SET_ROUTERS: (state, routers) => {
            state.addRouters = routers.menu;
            // 自动增加有权限的第一个路由作为默认路由
            let defaultPath = "";

            if (routers.menu && routers.menu.length > 0){
                for (let key in routers.menu) {
                    if (routers.menu[key].children) {
                        for (let i in routers.menu[key].children) {
                            if (routers.code.includes(routers.menu[key].children[i].meta.authCode) && defaultPath === "") {
                                defaultPath = routers.menu[key].children[i].path;
                            }
                        }
                    }

                }
                let defaultRouter = {
                    path: "/",
                    redirect: defaultPath
                };
                routers.menu.push(defaultRouter);
            } else {
                let defaultRouter = {
                    path: "/",
                    redirect: "/404"
                };
                routers.menu.push(defaultRouter);
            }
            state.routers = constantRouters.concat(routers.menu);
        }
    },
    actions: {
        GenerateRoutes ({ commit }, data) {
            return new Promise((resolve) => {
                const { menuCodes, operateCodes } = data;
                let accessedRouters;
                let authCodes = menuCodes.concat(operateCodes);
                accessedRouters = filterDynamicRouter(dynamicRouters, authCodes);
                let obj = {
                    menu: accessedRouters,
                    code: authCodes
                };
                commit("SET_ROUTERS", obj);
                resolve();
            });
        }
    }
};

export default permission;
