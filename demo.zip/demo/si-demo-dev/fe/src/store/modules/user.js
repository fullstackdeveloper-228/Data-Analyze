import http from "@/config/http";
import api from "@/api/api";
import Token from "@/utils/token";

const user = {
    state: {
        token: Token.getToken(),
        type: null,
        userName: null,
        userId: null,
        menuCodes: [],
        operateCodes: [],
        logo: null,
        title: null,
        skin: "0",
        // productCode: 'garbage'
        productCode: 'demo'
    },

    mutations: {
        SET_TOKEN (state, token) {
            state.token = token;
            Token.setToken(token);
        },
        // 获取皮肤
        SET_SKIN (state, skin) {
            sessionStorage.setItem("Hikkan-Skin", skin);
            state.skin = skin;
        },
        DEL_SKIN (state) {
            sessionStorage.removeItem("Hikkan-Skin");
            state.skin = "0";
        },
        DEL_TOKEN (state) {
            state.token = null;
            Token.removeToken();
        },
        SET_USER_INFO (state, userInfo) {
            state.type = userInfo.type;
            state.userId = userInfo.userId;
            state.userName = userInfo.userName;
            state.menuCodes = userInfo.menuCodes;
            state.operateCodes = userInfo.operateCodes;
            state.logo = userInfo.logo;
            state.title = userInfo.title;
        },
        DEL_USER_INFO (state) {
            state.type = null;
            state.userId = null;
            state.userName = null;
            state.menuCodes = [];
            state.operateCodes = [];
        }
    },

    actions: {
        GetSkinAndRequire ({commit}) {
            // 等获取皮肤的垃圾项目专用接口
            // return new Promise((resolve, reject) => {
            //     http({
            //         method: "post",
            //         url: api.GET_SKIN
            //     }).then((res) => {
            //         if (res.code === "200" && res.data){
            //             let skinType = Number(res.data);
            //             if (skinType) {
            //                 require("../../../static/theme/red.scss");
            //             }
            //             resolve();
            //         }
            //     });
            // });
            let skinType = 1;
            if (skinType) {
                require("../../../static/theme/red.scss");
            }
        },
        commitSkin ({commit}, skin) {
            commit("SET_SKIN", skin);
        },
        // 用户登录操作
        Login ({commit}, userInfo) {
            userInfo.name = userInfo.name.trim();
            return new Promise((resolve, reject) => {
                http({
                    method: "post",
                    url: api.LOGIN,
                    data: userInfo
                }).then((res) => {
                    if (res.code === "200" || res.code === "1016" || res.code === "1018") {
                        let token = res.data.Authorization;
                        commit("SET_TOKEN", token);
                    }
                    resolve(res);
                }).catch((error) => { // 请求失败就会捕获报错信息
                    reject(error);
                });
            });
        },

        // 用户登出操作
        LogOut ({commit, state}) {
            return new Promise((resolve, reject) => {
                http({
                    method: "post",
                    url: api.LOGOUT_SDK
                }).then(() => {
                    commit("DEL_TOKEN");
                    commit("DEL_USER_INFO");
                    commit("DEL_SKIN");
                    commit("CLEAR_VIDEO_VIDEO_VALIDATE_IDS");
                    resolve();
                }).catch((error) => { // 请求失败就会捕获报错信息
                    reject(error);
                });
            });
        },
        // 仅前端登出，在token过期时调用
        FedLogOut ({commit}) {
            return new Promise((resolve) => {
                commit("DEL_TOKEN");
                commit("DEL_USER_INFO");
                commit("DEL_SKIN");
                commit("CLEAR_VIDEO_VIDEO_VALIDATE_IDS");
                resolve();
            });
        },
        // 获取用户信息
        GetUserInfo ({commit, state}) {
            return new Promise((resolve, reject) => {
                http({
                    method: "post",
                    url: api.GET_USER_INFO
                }).then((response) => {
                    const userInfo = response.data;
                    if (userInfo) {
                        commit("SET_USER_INFO", userInfo);
                        commit("SET_PLAY_STYLE", userInfo.playStyle);
                    } else {
                        reject("getInfo: roles must be a non-null array !");
                    }
                    resolve(response);
                }).catch((error) => {
                    reject(error);
                });
            });
        }
    }
};

export default user;
