import http from "@/config/http";
import api from "@/api/api";
import { Base64 } from 'js-base64';
import { MessageBox, Message } from 'hui';
import router from "@/router";

const user = {
    state: {
        videoValidatedIds: [], // 加密监控点中已经验证过验证码的监控点id
        socketClient: null,
        hasClientExe: false,
        playStyle: 0 // 0: 表示h5播放； 1： 平台播放器播放
    },
    mutations: {
        SET_VIDEO_VALIDATE_IDS (state, id) {
            state.videoValidatedIds.push(id);
            state.videoValidatedIds = [...new Set(state.videoValidatedIds)];
        },
        CLEAR_VIDEO_VIDEO_VALIDATE_IDS (state) {
            state.videoValidatedIds = [];
        },
        SET_PLAY_STYLE (state, type) {
            state.playStyle = type;
        },
        UPDATE_PLAY_STYLE (state, type) {
            state.playStyle = type;
            http({
                method: "post",
                url: api.SET_PLAY_STYLE,
                data: {
                    playStyle: type
                }
            });
        },
        // 检测是否安装平台播放器
        CHECK_APP_EXIT (state, data) {
            // 过滤网格追踪返回的消息事件
            if (data.indexOf("ClosePlayBackGridTrack") > -1 || data.indexOf("ClosePlayRealGridTrack") > -1) {
                state.hasClientExe = true;
            }
            let resultCode = 0;
            let resultJson = JSON.parse(data);
            if (resultJson) {
                resultCode = resultJson.comment.resultCode;
                if (resultCode === '1') {
                    state.hasClientExe = true;
                } else {
                    state.hasClientExe = false;
                }
            } else {
                state.hasClientExe = false;
            }
        }
    },
    actions: {
        // 触发video客户端播放
        PlayVideoClient ({dispatch, commit, state}, payload) {
            let hikUrl = "";
            http({
                method: "post",
                url: api.VIDEO_XML_GET,
                data: payload
            }).then((res) => {
                let dataXml = res.data;
                hikUrl = Base64.encode(dataXml.replace(/\r\n\s+/g, '').replace("\\", '').replace(/\"/g, "'"));
                let clientCheck = '{"comment":{"commenttype":"checkapp", "context":"HikVideoClient:"}}';
                dispatch('WebSocketConnect', clientCheck).then((data) => {
                    commit("CHECK_APP_EXIT", data);
                    if (state.hasClientExe) {
                        let startCommand = '{"comment":{"commenttype":"startapp", "context":"hikvideoclient:", "commentcmd":"' + hikUrl + '"}}';
                        state.socketClient.send(startCommand);
                    } else {
                        MessageBox.confirm(
                            `
                            <div style="display:flex;align-items:center;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA0AAAANCAYAAABy6+R8AAAAAXNSR0IArs4c6QAAAWFJREFUKBVjZEACtuf7vf/9+58HFDJmZPjP/Z+B8SGQvYlTgLt1j3L6R5hSRhDD4epUnr8/f0759/9/PEwCmWZkZHzCwMCYeMSocA9InAlE4NMAkv///78MEG+0Oz9RFcRnAjsJhw0gBQjwn+vf/z8LQHwmqB8QcmisGAkzBjkOQbDo//8MVg7n+kyYGBgZTGDqJNn5YUwwHSdhzvD850eGRz/ew8V///9vzMT4/z8XTMSWX5nBXVgLruHpzw8Me9/fhEmDaUZGJm4maLCCBVa9OscgxMLF0KTow4BNA0gRI8O/hyxAehMQl4IEQGD5yzMMYmy8DK9+fYYIoJCM35gZGfcygSIOEg8IWewagKHGyFhxwLDwAxMkphkTgRZ/Q2jDZAFTwZZDhgVTQDLgyAXFNDMTswEjI8MxLMq/MTEy5R02KvIDuug/SB6cjJAVguIBFKygUAJ5mpmRaS/ISchqAHQSgA/qTskyAAAAAElFTkSuQmCC" /><span style="padding-left: 5px;">已安装</span><span style="color: #2080F7;cursor: pointer;padding: 2px;" onclick="window.location.href = 'https://hik-cloud-oss.oss-cn-beijing.aliyuncs.com/imexport/previewExeTemplate/ChromeExpansionPack.exe'">视频插件</span></div>
                            <div style="display:flex;align-items:center;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAwAAAAMCAYAAABWdVznAAAAAXNSR0IArs4c6QAAAR1JREFUKBV9kj1Ow0AQhd9bu4hEJBBUnCEdpkuDKLgAoUtH4ApwhHACCkJnUXEEhBANDe6IxA2oQCAkIEgwzIy9q2AhprA9b7/58ewQjYkIMShGIHcB6dUypxA5xXk1ISmm0R4yLFbxgVKDNs1vm8KX6GDIsnoInvkf2II90SycGRusjZiZ/S1wcTkV4NIKTPOg768NY0Pdc8NMK2DvEA4qjNEBcHebEiDP9ymDtVcRdKNqsIMmnIwhL0/xCMyy95C8vz7oM/l1ogE6usZSds2MyZFXci0CWX4ffM5R6BWpDXl+rINMi/Y5O6aPdWf9Ik4qnrXf7CzcoLzuB79Bu5SQXbWh6DvMt21j0195JVsNHZ22Wa+G9gxtY341fgDjP3AqDTr+KwAAAABJRU5ErkJggg==" /><span style="padding-left: 5px;">未检测到</span><span style="color: #2080F7;cursor: pointer;padding: 2px;" onclick="window.location.href = 'https://hik-cloud-oss.oss-cn-beijing.aliyuncs.com/imexport/previewExeTemplate/VideoClientSetup.exe'">平台播放器</span></div>
                            `,
                            '请安装播放工具后，刷新本页面', {
                                confirmButtonText: '前往下载',
                                cancelButtonText: '取消',
                                dangerouslyUseHTMLString: true,
                                customClass: 'client-download-confirm',
                                type: 'question'
                            }).then(() => {
                            router.push({path: '/download'});
                        }).catch(() => {});
                    }
                });
            }).catch((err) => {
                console.log(err);
            });
        },
        // chrome检测工具包括后续工具通信
        WebSocketConnect ({commit, state}, checkMsg) {
            return new Promise((resolve, reject) => {
                let host = "wss://127.0.0.1:18001/WebS_Js";
                try {
                    if (!state.socketClient) {
                        try {
                            state.socketClient = new WebSocket(host);
                        } catch (e) {
                            Message.error(e);
                        }
                    } else {
                        state.socketClient.send(checkMsg);
                    }
                    state.socketClient.onopen = () => {
                        state.socketClient.send(checkMsg);
                    };
                    state.socketClient.onmessage = (msg) => {
                        let data = msg.data;
                        resolve(data);
                    };
                    state.socketClient.onerror = (e) => {
                        MessageBox.confirm(
                            `
                            <div style="display:flex;align-items:center;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAwAAAAMCAYAAABWdVznAAAAAXNSR0IArs4c6QAAAR1JREFUKBV9kj1Ow0AQhd9bu4hEJBBUnCEdpkuDKLgAoUtH4ApwhHACCkJnUXEEhBANDe6IxA2oQCAkIEgwzIy9q2AhprA9b7/58ewQjYkIMShGIHcB6dUypxA5xXk1ISmm0R4yLFbxgVKDNs1vm8KX6GDIsnoInvkf2II90SycGRusjZiZ/S1wcTkV4NIKTPOg768NY0Pdc8NMK2DvEA4qjNEBcHebEiDP9ymDtVcRdKNqsIMmnIwhL0/xCMyy95C8vz7oM/l1ogE6usZSds2MyZFXci0CWX4ffM5R6BWpDXl+rINMi/Y5O6aPdWf9Ik4qnrXf7CzcoLzuB79Bu5SQXbWh6DvMt21j0195JVsNHZ22Wa+G9gxtY341fgDjP3AqDTr+KwAAAABJRU5ErkJggg==" /><span style="padding-left: 5px;">未检测到</<span><span style="color: #2080F7;cursor: pointer;padding: 2px;" onclick="window.location.href = 'https://hik-cloud-oss.oss-cn-beijing.aliyuncs.com/imexport/previewExeTemplate/ChromeExpansionPack.exe'">视频插件</span></div>
                            <div style="display:flex;align-items:center;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAwAAAAMCAYAAABWdVznAAAAAXNSR0IArs4c6QAAAR1JREFUKBV9kj1Ow0AQhd9bu4hEJBBUnCEdpkuDKLgAoUtH4ApwhHACCkJnUXEEhBANDe6IxA2oQCAkIEgwzIy9q2AhprA9b7/58ewQjYkIMShGIHcB6dUypxA5xXk1ISmm0R4yLFbxgVKDNs1vm8KX6GDIsnoInvkf2II90SycGRusjZiZ/S1wcTkV4NIKTPOg768NY0Pdc8NMK2DvEA4qjNEBcHebEiDP9ymDtVcRdKNqsIMmnIwhL0/xCMyy95C8vz7oM/l1ogE6usZSds2MyZFXci0CWX4ffM5R6BWpDXl+rINMi/Y5O6aPdWf9Ik4qnrXf7CzcoLzuB79Bu5SQXbWh6DvMt21j0195JVsNHZ22Wa+G9gxtY341fgDjP3AqDTr+KwAAAABJRU5ErkJggg==" /><span style="padding-left: 5px;">未检测到</span><span style="color: #2080F7;cursor: pointer;padding: 2px;" onclick="window.location.href = 'https://hik-cloud-oss.oss-cn-beijing.aliyuncs.com/imexport/previewExeTemplate/VideoClientSetup.exe'">平台播放器</span></div>
                            <div style="color: #999;">（如果已安装，请检查视频插件是否安装）</div>
                            `,
                            '请安装播放工具后，刷新本页面', {
                                confirmButtonText: '前往下载',
                                cancelButtonText: '取消',
                                dangerouslyUseHTMLString: true,
                                customClass: 'client-download-confirm',
                                type: 'question'
                            }).then(() => {
                            router.push({path: '/download'});
                        }).catch(() => {});
                    };
                    state.socketClient.onclose = function (e) {
                        state.socketClient = null;
                    };
                } catch (e) {
                    reject(e);
                }
            });
        },
        // 获取一段时间内的录像片段列表
        GetRecordList ({commit}, payload) {
            return new Promise((resolve, reject) => {
                http({
                    method: "post",
                    // url: api.GET_RECORD_LIST,
                    url: api.GET_RECORD_LIST_SDK,
                    data: payload
                }).then((res) => {
                    resolve(res);
                }).catch((error) => { // 请求失败就会捕获报错信息
                    reject(error);
                });
            });
        },
        GetSmallToken ({commit}, payload) {
            return new Promise((resolve, reject) => {
                http({
                    method: "post",
                    // url: api.GET_SMALL_TOKEN,
                    url: api.GET_SMALL_TOKEN_SDK,
                    data: payload
                }).then((res) => {
                    resolve(res);
                }).catch((error) => { // 请求失败就会捕获报错信息
                    reject(error);
                });
            });
        },
        SaveVideoLog ({commit}, payload) {
            return new Promise((resolve, reject) => {
                http({
                    method: "post",
                    url: api.SAVE_VIDEO_LOG,
                    data: {
                        monitorOperationContent: {
                            direction: payload.direction,
                            monitorCode: payload.monitorCode
                        },
                        monitorOperationType: payload.monitorOperationType
                    }
                }).then((res) => {
                    resolve(res);
                }).catch((error) => {
                    reject(error);
                });
            });
        }
    }
};

export default user;
