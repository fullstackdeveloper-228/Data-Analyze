const iframe = {
    state: {
    },
    mutations: {
    },
    actions: {
    }
};

export default iframe;
