import Vue from "vue";
import Vuex from "vuex";
import getters from "./getters";
import mutations from "./mutations";
import actions from "./actions";
import permission from "./modules/permission";
import user from "./modules/user";
import info from "./modules/info";
import video from "./modules/video/video";
import iframe from "./modules/iframe";
Vue.use(Vuex);

const state = {
    errMsg: null,
    isCollapse: false // 菜单是否折叠
};


export default new Vuex.Store({
    state,
    mutations,
    actions,
    getters,
    modules: {
        permission,
        user,
        info,
        video,
        iframe
    }
});
