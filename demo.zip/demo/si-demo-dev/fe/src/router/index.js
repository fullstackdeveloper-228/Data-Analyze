import Vue from "vue";
import Router from "vue-router";
import login from "@/pages/login/login";
import forgetPassword from "@/pages/login/forgetPassword";
import resetPassword from "@/pages/login/resetPassword";
import modifyPassword from "@/pages/login/modifyPassword";
import layout from "@/pages/layout/layout";
import page404 from "@/pages/error/404";

import iframe from "@/pages/iframe";

import GarbageVideoList from "@/pages/garbage/GarbageVideoList";
import GarbageVideoDetail from "@/pages/garbage/GarbageVideoDetail";
import VideoList from "@/pages/video/VideoList";
import VideoDetail from "@/pages/video/VideoDetail";
import PointList from "@/pages/point/PointList";
import PointAdd from "@/pages/point/PointAdd";
import PointEdit from "@/pages/point/PointEdit";

import Open from "@/pages/open";


Vue.use(Router);

// 固定的路由，跟用户权限无关
export const constantRouters = [
    {
        path: "/download",
        component: layout,
        children: [
            {
                path: "/download",
                name: "Download",
                component: iframe
            }
        ]
    },
    {
        path: "/login",
        name: "login",
        component: login
    },
    {
        path: "/forgetPass",
        name: "forgetPassword",
        component: forgetPassword
    },
    {
        path: "/resetPassword",
        name: "resetPassword",
        component: resetPassword
    },
    {
        path: "/modifyPassword",
        name: "modifyPassword",
        component: modifyPassword
    },
    {
        path: "/404",
        name: "page404",
        component: page404
    }
];

// 动态路由，根据用户权限动态添加
export const dynamicRouters = [
    { // 应用中心
        path: "/app",
        component: layout,
        redirect: "/app/video",
        meta: { authCode: "hikkan_application" },
        children: [
            {
                path: "/app/video",
                name: "VideoIndex",
                component: iframe,
                props: {
                    crumbs: ["应用中心", "全天视频监控"]
                },
                meta: { authCode: "hikkan_application_video" }
            },
            {
                path: "/app/live",
                name: "LiveList",
                component: iframe,
                props: {
                    crumbs: ["应用中心", "视频直播"]
                },
                meta: { authCode: "hikkan_application_live" }
            },
            {
                path: "/app/videodemo",
                name: "VideoList",
                component: VideoList,
                props: {
                    crumbs: ["应用中心", "视频demo"]
                },
                meta: { authCode: "hikkan_application_video" }
            },
            {
                path: "/app/videodemo/detail",
                name: "VideoDetail",
                component: VideoDetail,
                props: {
                    crumbs: ["应用中心", "视频demo", "视频详情"]
                },
                meta: { authCode: "hikkan_application_video" }
            }
        ]
    },
    { // 应用中心
        path: "/app/garbage",
        component: layout,
        redirect: "/app/garbage/video",
        meta: { authCode: "hikkan_application_video" },
        children: [
            {
                path: "/app/garbage/video",
                name: "GarbageVideoList",
                component: GarbageVideoList,
                props: {
                    crumbs: ["应用中心", "垃圾丢弃监控"]
                },
                meta: { authCode: "hikkan_application_video" }
            },
            {
                path: "/app/garbage/video/detail",
                name: "GarbageVideoDetail",
                component: GarbageVideoDetail,
                props: {
                    crumbs: ["应用中心", "垃圾丢弃监控", "视频详情"]
                },
                meta: { authCode: "hikkan_application_video" }
            }
        ]
    },
    { // 垃圾投放点管理
        path: "/res/point",
        component: layout,
        redirect: "/res/point/list",
        meta: { authCode: "hikkan_application_video" },
        children: [
            {
                path: "/res/point/list",
                name: "PointList",
                component: PointList,
                props: {
                    crumbs: ["资源中心", "垃圾投放点"]
                },
                meta: { authCode: "hikkan_application_video" }
            },
            {
                path: "/res/point/add",
                name: "PointAdd",
                component: PointAdd,
                props: {
                    crumbs: ["资源中心", "垃圾投放点", "增加投放点"]
                },
                meta: { authCode: "hikkan_application_video" }
            },
            {
                path: "/res/point/edit",
                name: "PointEdit",
                component: PointEdit,
                props: {
                    crumbs: ["资源中心", "垃圾投放点", "编辑投放点"]
                },
                meta: { authCode: "hikkan_application_video" }
            }
        ]
    },
    { // 资源中心相关路由
        path: "/res",
        component: layout,
        redirect: "/res/org",
        meta: { authCode: "hikkan_res" },
        children: [
            {
                path: "/res/org",
                component: iframe,
                props: {
                    crumbs: ["资源中心", "组织管理1"]
                },
                meta: { authCode: "hikkan_res_org" }
            },
            {
                path: "/res/vdevice",
                component: iframe,
                props: {
                    crumbs: ["资源中心222", "萤石设备"]
                },
                meta: { authCode: "hikkan_res_device" }
            },
            {
                path: "/res/nbdevice",
                component: iframe,
                props: {
                    crumbs: ["资源中心", "NB设备"]
                },
                meta: { authCode: "hikkan_res_nbDevice" }
            },
            {
                path: "/res/acdevice",
                component: iframe,
                props: {
                    crumbs: ["资源中心", "门禁设备"]
                },
                meta: { authCode: "hikkan_res_acDevice" }
            },
            {
                path: "/res/live",
                name: "LiveManage",
                component: iframe,
                props: {
                    crumbs: ["资源中心", "直播设备"]
                },
                meta: { authCode: "hikkan_res_live" }
            }
        ]
    },
    { // 用户中心相关路由
        path: "/user",
        component: layout,
        redirect: "/user/management",
        meta: { authCode: "hikkan_user" },
        children: [
            {
                path: "/user/management",
                name: "userList",
                component: iframe,
                props: {
                    crumbs: ["用户中心", "用户管理"]
                },
                meta: { authCode: "hikkan_user_list" }
            },
            {
                path: "/user/department",
                name: "deptIndex",
                component: iframe,
                props: {
                    crumbs: ["用户中心", "部门管理"]
                },
                meta: { authCode: "hikkan_user_dept" }
            },
            {
                path: "/user/role",
                name: "roleList",
                component: iframe,
                props: {
                    crumbs: ["用户中心", "角色管理"]
                },
                meta: { authCode: "hikkan_user_role" }
            }
        ]
    },
    { // 数据中心相关路由
        path: "/dc",
        component: layout,
        redirect: "/dc/log",
        meta: { authCode: "hikkan_data" },
        children: [
            {
                path: "/dc/log",
                name: "log",
                component: iframe,
                props: {
                    crumbs: ["管理中心", "操作日志"]
                },
                meta: { authCode: "hikkan_data_log" }
            },
            {
                path: "/dc/ioLog",
                name: "ioLog",
                component: iframe,
                props: {
                    crumbs: ["管理中心", "批量操作记录"]
                },
                meta: { authCode: "hikkan_data_impExp" }
            },
            {
                path: "/dc/cdkey",
                name: "cdkeyList",
                component: iframe,
                props: {
                    crumbs: ["管理中心", "卡密管理"]
                },
                meta: { authCode: "hikkan_data_card" }
            },
            {
                path: "/dc/dataferry",
                name: "DataFerryList",
                component: iframe,
                props: {
                    crumbs: ["管理中心", "数据摆渡"]
                },
                meta: { authCode: "hikkan_data_ferry" }
            },
            {
                path: "/dc/service",
                name: "ServiceList",
                component: iframe,
                props: {
                    crumbs: ["管理中心", "平台服务"]
                },
                meta: { authCode: "hikkan_data_service" }
            }
        ]
    },
    { // 个人中心相关路由
        path: "/personal",
        component: layout,
        redirect: "/personal/info",
        meta: { authCode: "hikkan_personal" },
        children: [
            {
                path: "/personal/info",
                name: "personInfo",
                component: iframe,
                props: {
                    crumbs: ["个人中心", "个人资料"]
                },
                meta: { authCode: "hikkan_personal_info" }
            }
        ]
    },
    {
        path: "/open",
        component: layout,
        meta: { authCode: "hikkan_application" },
        children: [
            {
                path: "/",
                component: Open,
                props: {
                    crumbs: ["测试打开新标签页"]
                },
                meta: { authCode: "hikkan_application" }
            }
        ]
    },
    // 测试运营sso
    // {
    //     path: "/manage",
    //     component: layout,
    //     redirect: "/manage/product",
    //     meta: { authCode: "voperat_manage" },
    //     children: [
    //         {
    //             path: "/manage/product",
    //             name: "ProductIndex",
    //             component: iframe,
    //             props: {
    //                 crumbs: ["管理中心", "产品管理111"]
    //             },
    //             meta: { authCode: "voperat_manage_product" }
    //         },
    //         {
    //             path: "/manage/project",
    //             name: "ProjectIndex",
    //             component: iframe,
    //             props: {
    //                 crumbs: ["管理中心", "项目管理111"]
    //             },
    //             meta: { authCode: "voperat_manage_product" }
    //         }
    //     ]
    // },
    { path: "*", redirect: "/404" } // 不能放在固定路由中，否则全局路由守卫时会先跳转到404
];

export default new Router({
    mode: "history",
    routes: constantRouters
});
