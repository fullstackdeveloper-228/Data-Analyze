import tTree from "./src/t-tree.vue";

tTree.install = (Vue) => {
    Vue.component(tTree.name, tTree);
};

export default tTree;
