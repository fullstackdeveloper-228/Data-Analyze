<template>
    <div class="t-tree" :style="{height:tTreeHeight}">
        <div class="h-page-iobar" v-if="showIoBar" >
            <el-button type="link" @click="im" v-if="tooltipImport" title="导入">导入</el-button>
            <el-button type="link" @click="ex" v-if="tooltipExport" title="导出">导出</el-button>
        </div>
        <h-page-sidebar :class="{'h-page-sidebar__showiobar': showIoBar}" :inline-scroll="false">
            <template slot="pageSidebarAction" v-if="showToolBar">
                <h-page-button-group>
                    <el-button type="iconButton" icon="h-icon-add" @click="add" v-if="tooltipAdd" title="添加"></el-button>
                    <el-button type="iconButton" icon="h-icon-delete" @click="del" v-if="tooltipDel" title="删除"></el-button>
                    <el-button type="iconButton" icon="h-icon-edit" @click="edit" v-if="tooltipEdit" title="编辑"></el-button>
                    <el-button type="iconButton" icon="h-icon-arrow_up" @click="up" v-if="tooltipMoveUp" title="上移"></el-button>
                    <el-button type="iconButton" icon="h-icon-arrow_down" @click="down" v-if="tooltipMoveDown" title="下移"></el-button>
                    <el-button type="iconButton" icon="h-icon-refresh" @click="update" v-if="tooltipUpdate" title="更新"></el-button>
                </h-page-button-group>
            </template>

             <template slot="pageSidebarSearch" v-if="showSearchBar">
                <slot name="searchContent" class=""></slot>
            </template>

            <template>
                <slot name="sidebarTree" class="isScrollBarX"></slot>
            </template>

        </h-page-sidebar>
    </div>
</template>

<script>

export default {
    name: "tTree",
    data () {
        return {
        };
    },
    mounted () {
    },
    computed: {
        tTreeHeight () {
            return this.isScrollBarX ? "calc(100% - 12px)" : "calc(100%)";
        }
    },
    methods: {
        add () {
            this.$emit("tree-add");
        },
        del () {
            this.$emit("tree-del");
        },
        edit () {
            this.$emit("tree-edit");
        },
        up () {
            this.$emit("tree-up");
        },
        down () {
            this.$emit("tree-down");
        },
        update () {
            this.$emit("tree-update");
        },
        im () {
            this.$emit("tree-import");
        },
        ex () {
            this.$emit("tree-export");
        }
    },
    props: {
        showIoBar: {
            type: Boolean,
            default: false
        },
        showToolBar: {
            type: Boolean,
            default: false
        },
        showSearchBar: {
            type: Boolean,
            default: true
        },
        tooltipAdd: {
            type: Boolean,
            default: true
        },
        tooltipDel: {
            type: Boolean,
            default: true
        },
        tooltipEdit: {
            type: Boolean,
            default: true
        },
        tooltipMoveUp: {
            type: Boolean,
            default: true
        },
        tooltipMoveDown: {
            type: Boolean,
            default: true
        },
        tooltipUpdate: {
            type: Boolean,
            default: true
        },
        tooltipExport: {
            type: Boolean,
            default: true
        },
        tooltipImport: {
            type: Boolean,
            default: true
        },
        isScrollBarX: {
            type: Boolean,
            default: false
        }
    }
};
</script>

<style lang="scss" scoped>
    .t-tree {
        position: relative;
        width: 256px;
        .h-page-iobar {
            position: relative;
            width: 100%;
            height: 24px;
            line-height: 24px;
            padding: 0px 12px;
            border-right: 1px solid #E0E0E0;
        }
    }
</style>
