<template>
    <h-layout>
        <h-page-content ref="mainPage">
            <template>
                <h-page-action @search-collapse="triggerSearch" :search-icon="isSearchIcon" :search-icon-tips="searchIconTips" v-if="$slots.hPageAction || $slots.rightAction || isSearchIcon">
                    <slot name="hPageAction">
                    </slot>
                    <template slot="rightAction">
                        <slot name="rightAction"></slot>
                    </template>
                </h-page-action>
            </template>
            <div ref="hPageSearch">
                <slot name="hPageSearch" ref="myTable"></slot>
            </div>
            <h-page-table :scrollbar-affix="false" :style="{height: tableWrapHeight}">
                <div :style="{height: tableHeight}">
                    <slot name="hPageTable"></slot>
                </div>
                <template slot="pagination">
                    <slot name="pagination"></slot>
                </template>
            </h-page-table>
            <slot></slot>
        </h-page-content>
    </h-layout>
</template>

<script>

export default {
    name: "tPageTable",
    components: {},
    data () {
        return {
            flag: 1,
            mainHeight: 0,
            isFold: true,
            tableHeight: "",
            count: 0,
            handleResize: () => {}
        };
    },
    props: {
        isSearchIcon: {
            type: Boolean,
            default: false
        },
        searchIconTips: {
            type: String,
            default: '筛选'
        }
    },
    created () {
        this.handleResize = this.throttle(this.reCalc, 300);
    },
    mounted () {
        this.$nextTick(() => {
            this.reCalc();
        });
        window.addEventListener("resize", this.handleResize, false);
    },
    filters: {},
    computed: {
        offset () {
            return (this.$slots.hPageAction || this.$slots.rightAction || this.isSearchIcon) ? 44 : 0;
        },
        tableWrapHeight () {
            return `${this.mainHeight - this.offset}px`;
        }
    },
    watch: {
        isFold (newValue, oldValue) {
            setTimeout(() => this.reCalc(), 500);
        },
        tableHeight (newValue, oldValue) {
            this.$emit("table-height-change", newValue);
        }
    },
    methods: {
        triggerSearch (show) {
            show ? this.isFold = false : this.isFold = true;
        },
        reCalc () {
            this.mainHeight = this.$refs.mainPage.$el.clientHeight;
            // let hPageSearchHeight = this.isFold ? 0 : this.$refs.hPageSearch.clientHeight;
            let hPageSearchHeight = this.$refs.hPageSearch.clientHeight;
            this.tableHeight = `${this.tableWrapHeight.replace(/px/g, "") - hPageSearchHeight - 56}px`;
        },
        throttle (fn, delay, atleast) {
            let timer = null;
            let previous = null;
            return () => {
                let now = +new Date();
                if (!previous) previous = now;
                if (atleast && now - previous > atleast) {
                    fn();
                    previous = now;
                    clearTimeout(timer);
                } else {
                    clearTimeout(timer);
                    timer = setTimeout(() => {
                        fn();
                        previous = null;
                    }, delay);
                }
            };
        }
    },
    beforeDestroy () {
        window.removeEventListener("resize", this.handleResize, false);
    }
};

</script>
