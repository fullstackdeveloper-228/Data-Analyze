import tPageTable from "./src/t-page-table.vue";

tPageTable.install = (Vue) => {
    Vue.component(tPageTable.name, tPageTable);
};

export default tPageTable;
