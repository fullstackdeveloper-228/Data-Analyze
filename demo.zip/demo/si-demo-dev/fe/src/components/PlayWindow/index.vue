<template>
    <div class="play-window-wrapper">
        <div class="play-window-header">
            <span class="name">{{options.monitorName}}</span>
            <i class="h-icon-close icon-close" @click="closePreview" v-show="status"></i>
        </div>
        <div class="play-window-container">
            <video-window ref="minivideo" :opts="options"></video-window>
        </div>
        <div class="play-window-footer clearfix">
            <div class="button-group pull-right">
                <div class="m-button" v-show="status">
                    <i class="lidaicon-video-preview"></i>
                    <span class="text" @click="routeToDetail(options.monitorId)">视频详情</span>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
/*
 * @Author: Sixiang Le 
 * @Date:   2019-04-03 16:09:16 
 * @Last Modified by: Sixiang Le
 * @Last Modified time: 2019-05-10 12:29:46
 */
import VideoWindow from "@/components/VideoWindow/VideoWindow.vue";
export default {
    name: 'PlayWindow',
    data () {
        return { 
            status: 0, // 1：播放成功, 0:没有播放，或者已经关闭
            options: {
                id: 'video_window',
                accessToken: this.accessToken, 
                url: this.isencrypt ? `ezopen://${this.validateCode}@open.ys7.com/${this.monitorSerial}/${this.channum}.live` : `ezopen://open.ys7.com/${this.monitorSerial}/${this.channum}.live`,
                monitorName: this.monitorName,
                monitorId: this.monitorId,
                monitorSerial: this.monitorSerial,
                channum: this.channum,
                width: 640,
                height: 360,
                handleSuccess: this.handleSuccess,
                handleError: this.handleError
            }
        };
    },
    props: ['accessToken', 'monitorSerial', 'channum', 'monitorName', 'monitorId', 'validateCode', 'isencrypt'],
    computed: {
    },
    mounted () {
    },
    methods: {
        renderVideo () {
            console.log(this.options);
            this.status = 0;
            this.$refs.minivideo.render(); 
        },
        handleSuccess () {
            this.status = 1;
        },
        handleError (e) {
            this.$emit('video-close');
            this.$message.error(e.msg);
            console.log('handleError', e);
        },
        closePreview (callback) {
            let self = this;
            this.$refs.minivideo.$closeVideo(
                () => {
                    this.status = 0;
                    self.$emit('video-close');
                    if (typeof callback === 'function') {
                        callback();
                    }
                },
                () => {
                    self.$emit('video-close');
                    console.log("关闭mini视频失败");
                }
            );
        },
        routeToDetail () {
            this.$refs.minivideo.$closeVideo(
                () => {
                    this.status = 0;
                    this.$emit('video-close');
                    this.$router.push({ 
                        path: '/app/garbage/video/detail',
                        query: {
                            id: this.monitorId,
                            monitorSerial: this.monitorSerial,
                            channum: this.channum,
                            validateCode: this.validateCode,
                            isencrypt: this.isencrypt,
                            type: '1' // 预览
                        } 
                    });
                },
                () => {
                    console.log("跳转详情页前关闭视频失败");
                }
            );
        }
    },
    components: {
        VideoWindow
    },
    destroyed () {
    }
};
</script>

<style lang="scss" scoped>
.play-window-wrapper {
    position: relative;
    overflow: hidden;
    height: 100%;
    border-radius: 4px;
    font-size: 14px;
    &:hover {
        .play-window-header {
            top: 0;
        }
        .play-window-footer {
            bottom: 0;
        }
    }
    .play-window-header,
    .play-window-footer {
        position: absolute;
        z-index: 10001;
        left: 0;
        width: 100%;
        height: 40px;
        background-color: rgba(0, 0, 0, 0.5);
        color: #ffffff;
        line-height: 40px;
        transition: all 0.3s;
    }
    .play-window-header {
        top: -40px;
        padding: 0 14px 0 16px;
        cursor: move;
        .icon-close {
            margin-top: 10px;
            margin-right: 6px;
            color: #ffffff;
            cursor: pointer;
            float: right;
            font-size: 22px;
            &:hover {
                color: #2080f7;
            }
        }
    }
    .play-window-footer {
        bottom: -40px;
        .button-group {
            margin-right: 20px;
            &.right {
                margin-right: 20px;
            }
        }
        .m-button {
            font-size: 14px;
            display: flex;
            height: 40px;
            align-items: center;
            padding: 5px 8px;
            text-align: center;
            color: #ffffff;
            .icon {
                color: #ffffff;
            }
            .text {
                padding-left: 8px;
            }
            &:hover {
                cursor: pointer;
                color: #2080f7;
                .icon {
                    color: #2080f7;
                }
            }
        }
    }
}

</style>
