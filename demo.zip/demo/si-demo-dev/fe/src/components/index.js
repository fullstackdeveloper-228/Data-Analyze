import tPage from "./t-page";
import tHeader from "./t-header";
import tTree from "./t-tree";
import tPageTable from "./t-page-table";
import tPassword from "./t-password";


const components = [
    tPage,
    tHeader,
    tTree,
    tPageTable
];

const install = (Vue) => {
    components.map((component) => {
        Vue.component(component.name, component);
    });
    Vue.component(tPassword.tPasswordMod.name, tPassword.tPasswordMod);
    Vue.component(tPassword.tPasswordRank.name, tPassword.tPasswordRank);
};
export default {
    install
};
