<template>
    <div class="slider-box" :class="options.type">
        <div ref="sliderLine" class="slider-line" @mousemove="mouseMoveFn" @mousedown="mouseDownFn" @mouseover="mouseOverFn" @mouseleave="mouseLeaveFn" @dbclick="dbClickFn" @click="clickFn">
            <div class="slider-round" :style="{'left': roundLeft + 'px'}"></div>
        </div>
    </div>
</template>
<script>
/*
 * @Author: Sixiang Le 
 * @Date: 2019-07-23 11:03:56 
 * @Last Modified by:   Sixiang Le 
 * @Last Modified time: 2019-07-23 11:03:56 
 */
export default {
    name: 'ScalarLine',
    data () {
        return {
            isOver: false, // 鼠标是否悬浮在条上
            isMouseDown: false, // 鼠标是否按下
            mousePosition: null,
            oldPosition: null,
            moved: false,
            roundLeft: 0,
            hasInit: false
        };
    },
    props: {
        options: {
            type: Object,
            default: () => ({
                scalar: 100,
                type: 'transverse', // 'vertical'
                position: 0
            })
        }
    },
    computed: {
    },
    mounted () {
    },
    methods: {
        init () {
            this.nowPosition = this.options.position;
            this.mouseUpFn();
            this.$nextTick(() => {
                this.moveRound();
            });
            this.hasInit = true;
        },
        mouseUpFn () {
            document.getElementsByTagName("html")[0].addEventListener("mouseup", ()=> {
                this.isMouseDown = false;
                this.oldPosition = this.nowPosition;
                // this.$emit('change-scalar');
            });
        },
        mouseMoveFn (e) {
            if (this.isMouseDown && this.isOver) {
                let mouseOffset = this.mousePosition - e.pageX;
                this.mousePosition =
                    this.oldPosition * this.section +
                    (mouseOffset / this.$refs.sliderLine.style.width) * this.section;
                this.moved = true;
            } else {
                let { left, top } = this.$utils.getOffset(this.$refs.sliderLine);
                this.mousePosition = e.pageX - left;
            }
        },
        mouseDownFn (e) {
            this.isMouseDown = true;
            this.mousePosition = e.pageX;
            this.oldPosition = this.nowPosition;
        },
        mouseOverFn () {
            this.isOver = true;
        },
        mouseLeaveFn () {
            this.isOver = false;
        },
        dbClickFn () {
            return false;
        },
        clickFn () {
            if (this.moved) {
                this.moved = false;
            }
        },
        moveRound () {
            let width = this.$refs.sliderLine.offsetWidth;
            let height = this.$refs.sliderLine.offsetHeight;
            switch (this.options.type) {
                case 'transverse':
                    this.section = width / this.options.scalar;
                    this.transverseInit();
                    break;
                case 'vertical':
                    this.section = height / this.options.scalar;
                    this.vertical();
                    break;
                default:
                    this.section = width / this.options.scalar;
                    this.transverseInit();
                    break;
            }
            this.$emit('change-scalar', this.nowPosition);
        },
        transverseInit () {
            if (this.nowPosition === this.options.scalar) {
                this.roundLeft = this.section * this.nowPosition - 8;
            } else {
                this.roundLeft = this.section * this.nowPosition;
            }
        },
        vertical () {
            this.$refs.sliderRound.style.top = this.section * this.nowPosition;
        },
        $changeRange (type) {
            if (type) {
                if (this.nowPosition < this.options.scalar) {
                    this.nowPosition++;
                }
            } else {
                if (this.nowPosition > 0) {
                    this.nowPosition--;
                }
            }
            this.moveRound();
        }
    },
    watch: {
    },
    destroyed () {
    }
};
</script>

<style lang="scss" scoped>
.slider-box {
    user-select: none;
    .slider-line {
        position: relative;
    }
    &.vertical {}
    &.transverse {
        padding: 3px 0px;
        .slider-line {
            height: 2px;
            width: 100%;
            background: #fff;
            cursor: pointer;
            .slider-round {
                width: 8px;
                height: 8px;
                position: absolute;
                top: -3px;
                left: 0px;
                background: #fff;
                border-radius: 100%;
            }
        }
    }
}
</style>
