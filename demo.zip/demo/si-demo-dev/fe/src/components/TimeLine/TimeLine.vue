<template>
    <div ref="drawPanal" class="draw-panal" :style="{'width':options.width + 'px;'}" @mousemove="mousemove" @mousedown="mousedown" @mouseover="mouseover" @mouseleave="mouseleave" @dbclick="dbclick">
        <canvas :id="'canvas_'+ randomNum" :ref="'canvas_'+ randomNum" class="time-line-body" :width="options.width+'px'" height="48px">
            该浏览器不支持canvas
        </canvas>
        <div class="hover-panal" v-show="timeTipShow" :style="{'left': hoverLeft + 'px'}">
            <p class="hover-time">{{hoverTime}}</p>
            <span class="down-angle"></span>
        </div>
    </div>
</template>
<script>
/*
 * @Author: Sixiang Le 
 * @Date: 2019-07-23 10:58:49 
 * @Last Modified by:   Sixiang Le 
 * @Last Modified time: 2019-07-23 10:58:49 
 */
export default {
    name: 'TimeLine',
    data () {
        return {
            isMouseDown: false, // 鼠标是否按下
            isOver: false, // 鼠标是否悬浮在进度条上
            mousePosition: null,
            oldTime: null,
            nowTime: null,
            moved: null,
            hoverTime: '2018-12-07 12:00:00',
            hoverLeft: 0,
            timeTipShow: false,
            randomNum: 123,
            timeWidthTbls: [60, 1800, 3600, 86400, 259200], // 时间宽度单位（秒）
            timeUnits: [
                '范围: 1分钟; 单位: 秒',
                '范围: 30分钟; 单位: 分钟',
                '范围: 1小时; 单位: 分钟',
                '范围: 1天; 单位: 小时',
                '范围: 3天; 单位: 小时'
            ], // 时间单位
            drawPen: null,
            timeSection: [],
            canvasWidth: null,
            canvasHeight: null,
            timeTips: null
        };
    },
    props: {
        options: {
            type: Object,
            default: () => ({
                width: 500,
                height: 48,
                time: new Date().getTime(),
                timeSection: [],
                timeWidth: 2 // 0-4
            })
        }
    },
    computed: {
    },
    mounted () {
        // this.init();
        
    },
    methods: {
        subTime (time) {
            if (time < 10) {
                return '0' + time;
            } else {
                return time;
            }
        },
        tranTime (time) {
            let stringTime = time;
            if (time) {
                let newDate = new Date(time);
                stringTime =
                    newDate.getFullYear() +
                    '/' +
                    (newDate.getMonth() + 1) +
                    '/' +
                    newDate.getDate() +
                    ' ' +
                    this.subTime(newDate.getHours()) +
                    ':' +
                    this.subTime(newDate.getMinutes()) +
                    ':' +
                    this.subTime(newDate.getSeconds());
            }
            return stringTime;
        },
        init () {
            document.getElementsByTagName("html")[0].addEventListener("mouseup", this.mouseUpFn);
            const that = this;
            const opts = this.options;
            that.randomNum = (Math.random() + '').split('.').join('');
            that.timeWidthTblIndex = opts.timeWidth; // 当前使用时间宽度索引

            that.drawPanal = this.$refs.drawPanal;
            const canvas = document.querySelector('.time-line-body');
            that.drawPen = canvas.getContext('2d');
            that.nowTime = opts.time || Date.now(); // 当前时间点
            that.timeSection = opts.timeSection || []; // 时间段记录区间
            that.canvasWidth = canvas.offsetWidth;
            that.canvasHeight = canvas.offsetHeight;
            that.updata(); // 展示进度条
        },
        // event鼠标事件
        mousemove (e) {
            if (this.isMouseDown && this.isOver) {
                let mouseOffset = this.mousePosition - e.pageX;
                // fix点击引起mousemove的问题
                if (mouseOffset === 0) {
                    return;
                }
                let currentTime =
                    this.oldTime +
                    (mouseOffset / this.canvasWidth) *
                        this.timeWidth *
                        1000;
                this.updata({ time: currentTime });
                this.moved = true;
            } else {
                let { left, top } = this.$utils.getOffset(this.$refs.drawPanal);
                this.mousePosition = e.pageX - left;
                this.updata(); // 更新画面
            }
        },
        mousedown (e) {
            this.isMouseDown = true;
            this.mousePosition = e.pageX;
            this.oldTime = this.nowTime;
            // this.$emit('drag', true);
        },
        mouseover () {
            this.isOver = true;
        },
        mouseleave () {
            this.isOver = false;
            this.updata();
        },
        dbclick () {
            return false;
        },
        mouseUpFn () {
            if (this.isMouseDown) {
                this.isMouseDown = false;
                if (this.moved) {
                    this.moved = false;
                    this.$emit('change', [
                        parseInt(this.nowTime),
                        parseInt(this.oldTime)
                    ]);
                    this.updata({ time: this.nowTime });
                    this.oldTime = this.nowTime;
                } else {
                    // 鼠标单击
                    this.$emit('change', [parseInt(this.mouseTime), 1]);
                    this.updata({ time: this.mouseTime });
                    this.oldTime = this.mouseTime;
                }
            }
        },
        // 输入新参数更新进度条
        $run (data) {
            if (!this.isMouseDown) {
                this.updata(data);
            }
        },
        // 刷新进度条(内部调用)
        updata (data) {
            const that = this;
            data = data || {};
            that.nowTime = data.time || that.nowTime;
            that.timeSection = data.timeSection || that.timeSection;
            that.timeWidthTblIndex = data.timeWidth || that.timeWidthTblIndex;
            that.timeWidth = that.timeWidthTbls[data.timeWidth || that.timeWidthTblIndex];
            that.timeUnit = that.timeUnits[data.timeWidth || that.timeWidthTblIndex];
            if (data.timeWidth === 0) {
                that.timeWidthTblIndex = 0;
                that.timeWidth = that.timeWidthTbls[0];
                that.timeUnit = that.timeUnits[0];
            }
            that.drawPen.fillStyle = '#333333';
            that.drawPen.fillRect(0, 0, that.canvasWidth, that.canvasHeight);
            that.drawScale(); // 画刻度
            that.drawRecord(); // 画录像区间
            that.drawOtherMsg(); // 画录像的其他信息
            that.$emit('update-time', that.nowTime);
        },
        // 改变进度条大小
        $changeSize (w, h) {
            if (w) {
                this.options.width = w;
                this.canvasWidth = w;
            }
            if (h) {
                this.options.hieght = h;
                this.canvasHeight = h;
            }
            this.$nextTick(() => {
                this.updata();
            });
        },
        // 画线
        drawSolidLine (startX, startY, endX, endY, lineWidth, color) {
            this.drawPen.save();
            this.drawPen.strokeStyle = color;
            this.drawPen.lineWidth = lineWidth;
            this.drawPen.beginPath();
            this.drawPen.moveTo(startX, startY);
            this.drawPen.lineTo(endX, endY);
            this.drawPen.stroke();
            this.drawPen.restore();
        },
        // 写文字
        drawString (text, x, y, aling, color) {
            this.drawPen.font = '12px serif';
            this.drawPen.fillStyle = color || '#ffffff';
            this.drawPen.textAlign = aling || 'left';
            this.drawPen.fillText(text, x, y);
        },
        // 画刻度线和时间（内部调用）
        drawScale () {
            const that = this;
            const lineColor = 'rgba(255,255,255,0.3)';
            let startDate = new Date(that.nowTime); // 开始时间
            let starSecond = startDate.getSeconds(); // 起始的秒数
            let starMin = startDate.getMinutes(); // 起始的分钟数
            let startHours = startDate.getHours(); // 起始的小时
            let OffsetLeft = starMin * 60 + starSecond; // 偏移量
            let curScale = 0; // 计算时间点
            switch (that.timeWidth) {
                case 60: {
                    startDate.setSeconds(startDate.getSeconds() - 30); // 从现在时间的一半开始画起
                    starSecond = startDate.getSeconds();
                    for (let i = 0; i < 60; i++) {
                        curScale = starSecond + i;
                        if (curScale > 60) {
                            curScale = curScale - 60;
                        }
                        startDate.setSeconds(curScale);
                        // 每一个整10秒画一次线和文字
                        if (curScale % 10 === 0) {
                            that.drawSolidLine(
                                (i * that.canvasWidth) / 60,
                                0,
                                (i * that.canvasWidth) / 60,
                                (that.canvasHeight / 5) * 1.5,
                                1,
                                lineColor
                            );
                            let timeString =
                                this.subTime(startDate.getHours()) +
                                ':' +
                                this.subTime(startDate.getMinutes()) +
                                ':' +
                                this.subTime(startDate.getSeconds());
                            that.drawString(
                                timeString,
                                (i * that.canvasWidth) / 60,
                                (that.canvasHeight / 5) * 2.5,
                                'center',
                                'rgba(255,255,255,0.3)'
                            );
                        } else {
                            // 只画一次线
                            that.drawSolidLine(
                                (i * that.canvasWidth) / 60,
                                0,
                                (i * that.canvasWidth) / 60,
                                (that.canvasHeight / 5) * 0.5,
                                1,
                                lineColor
                            );
                        }
                    }
                    break;
                }
                case 1800: {
                    // 30分钟
                    startDate.setMinutes(startDate.getMinutes() - 15);
                    starMin = startDate.getMinutes();
                    for (let i = 0; i <= 30; i++) {
                        curScale = starMin + i;
                        if (curScale > 60) {
                            curScale = curScale - 60;
                        }
                        startDate.setMinutes(curScale);
                        if (curScale % 5 === 0) {
                            that.drawSolidLine(
                                ((i * 60 - starSecond) * that.canvasWidth) / 1800,
                                0,
                                ((i * 60 - starSecond) * that.canvasWidth) / 1800,
                                (that.canvasHeight / 5) * 1.5,
                                1,
                                lineColor
                            );

                            let timeString =
                                this.subTime(startDate.getHours()) +
                                ':' +
                                this.subTime(startDate.getMinutes());
                            that.drawString(
                                timeString,
                                ((i * 60 - starSecond) * that.canvasWidth) / 1800,
                                (that.canvasHeight / 5) * 2.5,
                                'center',
                                'rgba(255,255,255,0.3)'
                            );
                        } else {
                            that.drawSolidLine(
                                ((i * 60 - starSecond) * that.canvasWidth) / 1800,
                                0,
                                ((i * 60 - starSecond) * that.canvasWidth) / 1800,
                                (that.canvasHeight / 5) * 0.5,
                                1,
                                lineColor
                            );
                        }
                    }
                    break;
                }
                case 3600: {
                    // 60分钟
                    startDate.setMinutes(startDate.getMinutes() - 30);
                    starSecond = startDate.getSeconds();
                    starMin = startDate.getMinutes();
                    for (let i = 0; i <= 60; i++) {
                        curScale = starMin + i;
                        if (curScale > 60) {
                            curScale = curScale - 60;
                        }
                        startDate.setMinutes(curScale);
                        if (curScale % 10 === 0) {
                            that.drawSolidLine(
                                ((i * 60 - starSecond) * that.canvasWidth) / 3600,
                                0,
                                ((i * 60 - starSecond) * that.canvasWidth) / 3600,
                                (that.canvasHeight / 5) * 1.5,
                                1,
                                lineColor
                            );

                            let timeString =
                                this.subTime(startDate.getHours()) +
                                ':' +
                                this.subTime(startDate.getMinutes());
                            that.drawString(
                                timeString,
                                ((i * 60 - starSecond) * that.canvasWidth) / 3600,
                                (that.canvasHeight / 5) * 2.5,
                                'center',
                                'rgba(255,255,255,0.3)'
                            );
                        } else {
                            that.drawSolidLine(
                                ((i * 60 - starSecond) * that.canvasWidth) / 3600,
                                0,
                                ((i * 60 - starSecond) * that.canvasWidth) / 3600,
                                (that.canvasHeight / 5) * 0.5,
                                1,
                                lineColor
                            );
                        }
                    }
                    break;
                }
                case 86400: {
                    // 1天，24小时 
                    startDate.setHours(startDate.getHours() - 12);
                    starSecond = startDate.getSeconds();
                    starMin = startDate.getMinutes();
                    startHours = startDate.getHours();
                    for (let i = 0; i <= 24; i++) {
                        curScale = startHours + i;
                        if (curScale >= 24) {
                            curScale = curScale - 24;
                        }
                        startDate.setHours(curScale);
                        let timeString;
                        // 不等于24的时候，画短线
                        if (curScale) {
                            timeString = this.subTime(startDate.getHours());
                            that.drawSolidLine(
                                ((i * 3600 - OffsetLeft) * that.canvasWidth) /
                                    86400,
                                0,
                                ((i * 3600 - OffsetLeft) * that.canvasWidth) /
                                    86400,
                                (that.canvasHeight / 5) * 0.5,
                                1,
                                lineColor
                            );
                        } else {
                            // 不等于24的时候，画长线
                            timeString = startDate.toLocaleDateString();
                            that.drawSolidLine(
                                ((i * 3600 - OffsetLeft) * that.canvasWidth) /
                                    86400,
                                0,
                                ((i * 3600 - OffsetLeft) * that.canvasWidth) /
                                    86400,
                                (that.canvasHeight / 5) * 1,
                                1,
                                lineColor
                            );
                        }
                        // 每2个小时一个时间文字
                        if (curScale % 2 === 0) {
                            that.drawString(
                                timeString,
                                ((i * 3600 - OffsetLeft) * that.canvasWidth) /
                                    86400,
                                (that.canvasHeight / 5) * 2,
                                'center',
                                'rgba(255,255,255,0.3)'
                            );
                        }
                    }
                    break;
                }
                case 259200: {
                    // 3天
                    startDate.setHours(startDate.getHours() - 36);
                    starSecond = startDate.getSeconds();
                    starMin = startDate.getMinutes();
                    startHours = startDate.getHours();
                    OffsetLeft = starMin * 60 + starSecond;
                    for (let i = 0; i <= 72; i++) {
                        curScale = startHours + i;
                        if (curScale >= 24) {
                            curScale = curScale % 24;
                        }
                        if (curScale === 0) {
                            startDate.setHours(24);
                        } else {
                            startDate.setHours(curScale);
                        }

                        let timeString = this.subTime(startDate.getHours());

                        if (curScale % 3 === 0) {
                            // 每3天一个时间文字和刻度
                            if (!curScale) {
                                timeString = startDate.toLocaleDateString();
                            }
                            that.drawString(
                                timeString,
                                ((i * 3600 - OffsetLeft) * that.canvasWidth) /
                                    259200,
                                (that.canvasHeight / 5) * 2.5,
                                'center',
                                'rgba(255,255,255,0.3)'
                            );

                            that.drawSolidLine(
                                ((i * 3600 - OffsetLeft) * that.canvasWidth) /
                                    259200,
                                0,
                                ((i * 3600 - OffsetLeft) * that.canvasWidth) /
                                    259200,
                                (that.canvasHeight / 5) * 1,
                                1,
                                lineColor
                            );
                        } else {
                            that.drawSolidLine(
                                ((i * 3600 - OffsetLeft) * that.canvasWidth) /
                                    259200,
                                0,
                                ((i * 3600 - OffsetLeft) * that.canvasWidth) /
                                    259200,
                                (that.canvasHeight / 5) * 0.5,
                                1,
                                lineColor
                            );
                        }
                    }
                    break;
                }
            }
        },
        // 录像区间（内部调用）
        drawRecord () {
            const that = this;
            const drawPen = that.drawPen;
            let startDate = new Date(that.nowTime);
            let timeScale = that.canvasWidth / that.timeWidth;
            switch (that.timeWidth) {
                case 60: {
                    startDate.setSeconds(startDate.getSeconds() - 30);
                    break;
                }
                case 1800: {
                    startDate.setMinutes(startDate.getMinutes() - 15);
                    break;
                }
                case 3600: {
                    startDate.setMinutes(startDate.getMinutes() - 30);
                    break;
                }
                case 86400: {
                    startDate.setHours(startDate.getHours() - 12);
                    break;
                }
                case 259200: {
                    startDate.setHours(startDate.getHours() - 36);
                    break;
                }
            }
            that.timeSection.forEach(function (item, i) {
                // 蓝色片段条
                drawPen.fillStyle = '#4E6FAE';
                let x = ((item.time[0] - startDate.getTime()) * timeScale) / 1000;
                let w = ((item.time[1] - item.time[0]) * timeScale) / 1000;
                drawPen.fillRect(
                    x,
                    (that.canvasHeight / 5) * 3,
                    w,
                    (that.canvasHeight / 5) * 1.5
                );
            });
        },
        // 画中心线等内容
        drawOtherMsg () {
            // 画中心线阴影
            this.drawPen.shadowColor = '#ffffff';
            this.drawPen.shadowOffsetX = 0;
            this.drawPen.shadowOffsetY = 0;
            this.drawPen.shadowBlur = 10;
            // 绘制中心线上方的三角形
            this.drawPen.beginPath();
            this.drawPen.moveTo(this.canvasWidth / 2 - 4.5, 0);
            this.drawPen.lineTo(this.canvasWidth / 2 + 4.5, 0);
            this.drawPen.lineTo(this.canvasWidth / 2, 4.5);
            this.drawPen.fillStyle = '#fff';
            this.drawPen.closePath();
            this.drawPen.fill();

            // 绘制中心线下方的三角形
            this.drawPen.beginPath();
            this.drawPen.moveTo(this.canvasWidth / 2 - 4.5, this.canvasHeight);
            this.drawPen.lineTo(this.canvasWidth / 2 + 4.5, this.canvasHeight);
            this.drawPen.lineTo(this.canvasWidth / 2, this.canvasHeight - 4.5);
            this.drawPen.fillStyle = '#fff';
            this.drawPen.closePath();
            this.drawPen.fill();

            // 画中心线
            this.drawSolidLine(
                this.canvasWidth / 2,
                0,
                this.canvasWidth / 2,
                this.canvasHeight,
                2,
                '#ffffff'
            ); 
            
            this.drawPen.shadowBlur = 0;

            if (this.isOver && !this.isMouseDown) {
                this.mouseTime =
                    (this.mousePosition / this.canvasWidth) *
                        this.timeWidth *
                        1000 +
                    this.nowTime -
                    (this.timeWidth / 2) * 1000; // 鼠标的悬浮点对应的时间
                
                this.mouseString = this.tranTime(this.mouseTime); // 鼠标悬浮点显示的文字
                this.hoverTime = this.mouseString;
                this.hoverLeft = this.mousePosition - 60;
                this.timeTipShow = true;

            } else {
                this.timeTipShow = false;
            }
        }
    },
    components: {
    },
    destroyed () {
    }
};
</script>
<style lang="scss" scoped>
.draw-panal {
    height: 48px;
    position: relative;
    user-select: none;
    .time-line-body {
        background: transparent;
    }
    .hover-panal {
        // display: none;
        position: absolute;
        height: 36px;
        top: -36px;
        width: 136px;
        .hover-time {
            text-align: center;
            background: #333;
            height: 28px;
            line-height: 28px;
            color: #ffffff;
            font-size: 12px;
            border-radius: 2px;
            position: relative;
            z-index: 2;
        }
        .down-angle {
            width: 12px;
            height: 10px;
            background: #333;
            position: absolute;
            bottom: 5px;
            left: 54px;
            transform: rotate(60deg) skew(30deg);
            z-index: 1;
        }
    }
}
</style>
