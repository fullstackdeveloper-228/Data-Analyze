<template>
    <div class="ptz-panel">
        <div class="ptz-angel-ctrl">
            <div class="ptz-title">云台控制</div>
            <div class="center">
                <div class="circle"></div>
                <i data-key="up" title="向上旋转" class="icon hover-btn angle-up" @mousedown="mouseDownFn(0)" @mouseover="mouseOverFn" @mouseup="mouseUpFn" @mouseleave="mouseLeaveFn"></i>
                <i data-key="right" title="向右旋转" class="icon hover-btn angle-right" @mousedown="mouseDownFn(3)" @mouseover="mouseOverFn" @mouseup="mouseUpFn" @mouseleave="mouseLeaveFn"></i>
                <i data-key="down" title="向下旋转" class="icon hover-btn angle-down" @mousedown="mouseDownFn(1)" @mouseover="mouseOverFn" @mouseup="mouseUpFn" @mouseleave="mouseLeaveFn"></i>
                <i data-key="left" title="向左旋转" class="icon hover-btn angle-left" @mousedown="mouseDownFn(2)" @mouseover="mouseOverFn" @mouseup="mouseUpFn" @mouseleave="mouseLeaveFn"></i>
                <i data-key="right-up" title="右上旋转" class="icon hover-btn angle-sm-up" @mousedown="mouseDownFn(6)" @mouseover="mouseOverFn" @mouseup="mouseUpFn" @mouseleave="mouseLeaveFn"></i>
                <i data-key="right-down" title="右下旋转" class="icon hover-btn angle-sm-right" @mousedown="mouseDownFn(7)" @mouseover="mouseOverFn" @mouseup="mouseUpFn" @mouseleave="mouseLeaveFn"></i>
                <i data-key="left-down" title="左下旋转" class="icon hover-btn angle-sm-down" @mousedown="mouseDownFn(5)" @mouseover="mouseOverFn" @mouseup="mouseUpFn" @mouseleave="mouseLeaveFn"></i>
                <i data-key="left-up" title="左上旋转" class="icon hover-btn angle-sm-left" @mousedown="mouseDownFn(4)" @mouseover="mouseOverFn" @mouseup="mouseUpFn" @mouseleave="mouseLeaveFn"></i>
                <button data-key="round" class="click-btn" type="button">
                    <!-- <i title="水平扫描" class="icon lidaicon-reset"></i> -->
                </button>
            </div>
        </div>
        <div class="ptz-center-ctrl">
            <div class="first-line">
                <div class="speed-con">
                    <div class="dash-line"></div>
                    <div class="speed-point point1" :class="{active: actionParam.speed== 0}" @click="actionParam.speed=0"></div>
                    <div class="speed-point point2" :class="{active: actionParam.speed== 1}" @click="actionParam.speed=1"></div>
                    <div class="speed-point point3" :class="{active: actionParam.speed== 2}" @click="actionParam.speed=2"></div>
                </div>
                <div class="speed-txt">
                    <div>慢</div>
                    <div>中</div>
                    <div>快</div>
                </div>
            </div>
            <div class="second-line">
                <div class="btn-double">
                    <span class="pull-left">
                        <i data-key="zoom-elc" title="放大" class="icon hover-btn lidaicon-video-zoom-elc" @mousedown="mouseDownFn(8)" @mouseover="mouseOverFn" @mouseup="mouseUpFn" @mouseleave="mouseLeaveFn"></i>
                    </span>
                    <span class="pull-right">
                        <i data-key="zoom-out" title="缩小" class="icon hover-btn lidaicon-video-zoom-out" @mousedown="mouseDownFn(9)" @mouseover="mouseOverFn" @mouseup="mouseUpFn" @mouseleave="mouseLeaveFn"></i>
                    </span>
                </div>
                <div class="btn-double">
                    <span class="pull-left">
                        <i title="近焦距" class="icon hover-btn lidaicon-video-aperture-reduce" @mousedown="mouseDownFn(10)" @mouseover="mouseOverFn" @mouseup="mouseUpFn" @mouseleave="mouseLeaveFn"></i>
                    </span>
                    <span class="pull-right">
                        <i title="远焦距" class="icon hover-btn lidaicon-video-aperture-enlarge" @mousedown="mouseDownFn(11)" @mouseover="mouseOverFn" @mouseup="mouseUpFn" @mouseleave="mouseLeaveFn"></i>
                    </span>
                </div>
            </div>
        </div>
        <!-- <div class="positions-list">
            <div class="list-header">
                <div class="tab-item" :class="{active: curTab== 1}" @click="curTab=1">预置点</div>
                <div class="tab-item" :class="{active: curTab== 2}" @click="curTab=2">巡航</div>
            </div>
            <div class="list-tab-con list-content">
                <div class="presets-list list" :class="{active: curTab== 1}">
                    <div class="list-item">
                        <span class="num">1</span>
                        <span class="point-title">点击添加预置点</span>
                        <span class="edit"><i class="icon lidaicon-map-stroke"></i></span>
                    </div>
                </div>
                <div class="cruise-list list" :class="{active: curTab== 2}">
                    <div class="list-item">
                        <span class="num">1</span>
                        <span class="point-title">点击添加巡航</span>
                        <span class="edit"><i class="icon lidaicon-map-stroke"></i></span>
                    </div>
                </div>
            </div>
        </div> -->
    </div>
</template>
<script>
/*
 * @Author: Sixiang Le
 * @Date:   2019-04-03 16:09:16
 * @Last Modified by: Sixiang Le
 * @Last Modified time: 2019-05-06 17:42:49
 */
export default {
    name: 'PTZ',
    data () {
        return {
            curTab: 1,
            isDone: false,
            isOver: false,
            actionParam: {
                type: 0, // 0: 开始云台控制，1： 结束云台控制
                channelNo: null,
                deviceSerial: null,
                direction: null,
                speed: 1
            }
        };
    },
    props: {
        info: {
            type: Object,
            default: () => {}
        }
    },
    computed: {
    },
    mounted () {
        document.getElementsByTagName("html")[0].addEventListener("mouseup", ()=> {
            if (this.isDone && !this.isOver) {
                this.isDone = false;
                this.actionParam.type = 1;
                this.ptzControl();
            }
        });
    },
    methods: {
        mouseDownFn (direction) {
            this.actionParam.channelNo = this.info.channelNo;
            this.actionParam.deviceSerial = this.info.deviceSerial;
            this.isDone = true;
            this.actionParam.type = 0;
            this.actionParam.direction = parseInt(direction);
            this.ptzControl();
        },
        mouseUpFn () {
            this.actionParam.type = 1;
            this.isDone = false;
            this.ptzControl();
        },
        mouseOverFn () {
            this.isOver = true;
        },
        mouseLeaveFn () {
            this.isOver = false;
        },
        ptzControl () {
            this.$http({
                method: "post",
                url: this.$api.PTZ_CONTROL,
                data: this.actionParam
            }).then(() => {
            }).catch((err) => {
                console.log("云台控制失败：" + err);
            });
        }
    },
    watch: {
    },
    destroyed () {
    }
};
</script>

<style lang="scss" scoped>
.ptz-panel {
    $panel-main-color: #7f7f7f;
    width: 248px;
    height: 100%;
    position: relative;
    background: #3d3d3d;
    color: #e5e5e5;
    .icon {
        color: $panel-main-color;
        &:hover {
            color: #fff;
            cursor: pointer;
        }
        &.active {
            color: #1c72dd;
        }
        &.disabled {
            color: #4c4c4c;
            cursor: not-allowed;
        }
    }
    .ptz-angel-ctrl {
        width: 200px;
        height: 220px;
        margin: 0 auto;
        position: relative;
        .center {
            width: 40px;
            height: 40px;
            position: absolute;
            top: 100px;
            left: 80px;
            .icon {
                position: absolute;
                color: #ffffff;
                border-right: 2px solid #fff;
                border-bottom: 2px solid #fff;
                border-bottom-right-radius: 5px;
                &.disabled {
                    border-color: #4c4c4c;
                }
            }
            .angle-up {
                top: -31px;
                left: 10px;
                width: 18px;
                height: 18px;
                transform: rotate(-135deg);
            }
            .angle-right {
                top: 9px;
                left: 51px;
                width: 18px;
                height: 18px;
                transform: rotate(-45deg);
            }
            .angle-down {
                top: 47px;
                left: 10px;
                width: 18px;
                height: 18px;
                transform: rotate(45deg);
            }
            .angle-left {
                top: 9px;
                left: -30px;
                width: 18px;
                height: 18px;
                transform: rotate(135deg);
            }
            .angle-sm-up {
                top: -15px;
                left: 42px;
                width: 10px;
                height: 10px;
                transform: rotate(-90deg);
                border-width: 1px;
                border-bottom-right-radius: 3px;
            }
            .angle-sm-right {
                top: 38px;
                left: 42px;
                width: 10px;
                height: 10px;
                border-width: 1px;
                border-bottom-right-radius: 3px;
            }
            .angle-sm-down {
                top: 38px;
                left: -15px;
                width: 10px;
                height: 10px;
                transform: rotate(90deg);
                border-width: 1px;
                border-bottom-right-radius: 3px;
            }
            .angle-sm-left {
                top: -15px;
                left: -15px;
                width: 10px;
                height: 10px;
                transform: rotate(180deg);
                border-width: 1px;
                border-bottom-right-radius: 3px;
            }
            .lidaicon-reset {
                top: 9px;
                left: 10px;
                color: #7f7f7f;
                font-size: 22px;
                border: none;
            }
            .click-btn {
                width: 40px;
                height: 40px;
                border-radius: 100%;
                background-color: #fff;
                cursor: pointer;
                &.disabled {
                    background-color: #bfbfbf;
                    cursor: not-allowed;
                    .icon {
                        cursor: not-allowed;
                    }
                }
                &.active {
                    background-color: #1c72dd;
                    .icon {
                        color: #fff;
                    }
                }
            }
        }
        .ptz-title {
            position: relative;
            top: 10px;
        }
        .circle {
            width: 160px;
            height: 160px;
            border-radius: 100%;
            border: 2px solid #999;
            left: -60px;
            position: absolute;
            top: -60px;
        }
    }
    .ptz-center-ctrl {
        margin-top: 10px;
        .first-line {
            width: 180px;
            margin: 0 auto;
            padding: 0 0 20px;
            .speed-con {
                width: 180px;
                position: relative;
                display: flex;
                justify-content: space-between;
                align-items: center;
                .dash-line {
                    height: 1px;
                    width: 168px;
                    border-bottom: 1px dashed #999;
                    position: absolute;
                    top: 10px;
                    left: 6px;
                }
                .speed-point {
                   background-color: #e8e8e8;
                   width: 12px;
                   height: 12px;
                   border-radius: 6px;
                   cursor: pointer;
                   z-index: 2;
                }
                .point1 {
                    &.active {
                        width: 20px;
                        height: 20px;
                        background-image: url("~@/assets/icon/speed-active.png");
                        border-radius: 16px;
                        background-color: transparent;
                        background-position: 0 0;
                        background-size: 100% 100%;
                        margin-left: -8px;
                    }
                }
                .point2 {
                    &.active {
                        width: 20px;
                        height: 20px;
                        background-image: url("~@/assets/icon/speed-active.png");
                        border-radius: 16px;
                        background-color: transparent;
                        background-position: 0 0;
                        background-size: 100% 100%;
                    }
                }
                .point3 {
                    &.active {
                       width: 20px;
                        height: 20px;
                        background-image: url("~@/assets/icon/speed-active.png");
                        border-radius: 16px;
                        background-color: transparent;
                        background-position: 0 0;
                        background-size: 100% 100%;
                        margin-right: -8px;
                    }
                }
            }
            .speed-txt {
                padding: 5px 0;
                width: 180px;
                position: relative;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
        }
        .second-line {
            overflow: hidden;
            width: 220px;
            margin: 0 auto;
            display: flex;
            justify-content: space-around;
            font-size: 16px;
            .btn-double {
                width: 67px;
                height: 32px;
                line-height: 32px;
                border: 1px solid $panel-main-color;
                border-radius: 32px;
                margin-left: 6px;
                &:first-child {
                    margin: 0;
                }
                span {
                    text-align: center;
                    width: 32px;
                    &.pull-left {
                        border-right: 1px dashed $panel-main-color;
                    }
                    .icon {
                        position: relative;
                    }
                }
            }
        }
        .btn-single {
            width: 32px;
            height: 32px;
            line-height: 32px;
            border: 1px solid $panel-main-color;
            border-radius: 32px;
            margin-left: 6px;
            span {
                text-align: center;
                width: 32px;
            .icon {
                position: relative;
            }
        }
        }
    }
    .positions-list {
        width: 219px;
        margin: 0 auto;
        border: 1px solid $panel-main-color;
        margin-top: 20px;
        min-height: 100px;
        .list-header {
            overflow: hidden;
            background-color: #ccc;
            .tab-item {
                cursor: pointer;
                display: inline-block;
                width: 106px;
                height: 26px;
                line-height: 26px;
                text-align: center;
                color: #3d3d3d;
                border: none;
                margin-bottom: 0;
                &.active {
                    background-color: #3d3d3d;
                    color: #f5f5f5;
                }
            }
        }
        .list-content {
            padding-top: 20px;
            overflow: auto;
            border: none;
            .list {
                display: none;
                &.active {
                    display: block;
                }
            }
            .list-item {
                padding-left: 10px;
                span {
                    display: inline-block;
                    text-align: center;
                }
                .num {
                    width: 20px;
                    line-height: 26px;
                    vertical-align: top;
                }
                .point-title {
                    width: 150px;
                    line-height: 24px;
                    border: 1px solid #f5f5f5;
                    border-radius: 2px;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                    cursor: pointer;
                }
                .edit {
                    line-height: 26px;
                    vertical-align: top;
                    margin-left: 12px;
                }
                &.disabled,&.not-allow {
                    .point-title {
                        color: #7f7f7f;
                        border-color: #7f7f7f;
                    }
                    .edit {
                        .icon {
                            cursor: not-allowed;
                        }
                    }
                }
                &.not-allow {
                    .point-title {
                        cursor: not-allowed;
                    }
                }
                &.active {
                    .point-title {
                        color: #1c72dd;
                        border-color: #1c72dd;
                    }
                }
            }
        }
    }
}
.edit-presets {
    width: 378px;
    margin: 0  auto;
    .icon {
        position: relative;
        top: 2px;
        margin-right: 8px;
        cursor: pointer;
    }
    .lidaicon-checkbox-sel {
        color: #2b89eb;
    }
    &.vui-form {
        .form-line {
            font-size: 12px;
            .input-block {
                .input-text {
                    margin-left: 40px;
                    .watch-time {
                        display: inline-block;
                        margin-left: 12px;
                        margin-right: 12px;
                        width: 60px;
                        &.disabled {
                            color: #ccc;
                        }
                    }
                }
            }
            .choose-angle {
                &.disabled {
                    .icon {
                        color: #a5ccfb;
                        cursor: not-allowed;
                    }
                }
            }
            .use-watch {
                &.disabled {
                    .icon {
                        cursor: not-allowed;
                        color: #ccc;
                    }
                }
            }
        }
    }
}
.cruise-dialog {
    color: #666666;
    font-size: 12px;
    .name-title {
        margin-bottom: 4px;
        margin-top: 10px;
        .red {
            position: relative;
            top: -2px;
            color: #fe5a3a;
        }
    }
    .btn-list {
        margin-bottom: 4px;
        .icon {
            font-size: 16px;
        }
        .vui-button-text {
            padding: 0px;
            width: 32px;
            &:hover {
                background-color: #e6e6e6;
            }
        }
    }
    .road-name {
        width: 304px;
        margin-bottom: 24px;
    }
    .preset-table {
        border: 1px solid #e5e5e5;
        .table-header {
            background-color: #f5f5f5;
            overflow: hidden;
            line-height: 35px;
            border: 1px solid #e6e6e6;
            .inline-block {
                width: 100px;
                text-align: center;
               margin: 0 auto;
            }
            .pull-left {
                margin-left: 70px;
            }
            .pull-right {
                margin-right: 70px;
            }
        }
        .table-body {
            height: 300px;
            overflow: auto;
            .list-item {
                padding: 4px 0px;
                .clear {
                    clear: both;
                }
                &:hover {
                    background-color: #e9f2fe;
                }
                &.active {
                    background-color: #f5f5f5;
                }
                .vui-select {
                    font-size: 12px;
                    margin-left: 15px;
                    .select-pad {
                        height: 24px;
                        .select-button {
                            font-size: 12px;
                            height: 24px;
                            line-height: 24px;
                        }
                        .select-button-right {
                            height: 24px;
                            line-height: 24px;
                        }
                    }
                    .select-list {
                        &.down {
                            top: 30px;
                        }
                        li {
                            line-height: 24px;
                            font-size: 12px;
                        }
                    }
                }
            }
        }
    }
}
.width-1280 {
    .ptz-panel {
        .positions-list {
            .list-content {
                height: 135px;
            }
        }
    }
}
</style>
