import tHeader from "./src/t-header.vue";

tHeader.install = (Vue) => {
    Vue.component(tHeader.name, tHeader);
};

export default tHeader;
