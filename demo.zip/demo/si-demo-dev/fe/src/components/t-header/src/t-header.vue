<template>
    <div class="page-logo"  v-if="menu && menu.length && menuShow">
        <div class="m-left">
            <div class="logo"><img :src="projectData.logo" /></div>
            <div class="title">{{projectData.title}}</div>
            <div class="sub-title">租户管理平台</div>
        </div>
        <div class="m-right">
            <div class="info" v-if="$store.state.info.expireInfo">
                <i class="h-icon-tip_atten"></i>
                <span>{{$store.state.info.expireInfo}}</span>
            </div>
            <div class="download" @click="toDownloadPage"><img src="../../../assets/icon/download.png" /></div>
            <!-- <div class="msg"><img src="../../../assets/msg.png"></div>
            <div class="opt"><img src="../../../assets/opt.png"></div> -->
            <div class="usr">
                <div class="usr-down">
                    <el-dropdown>
                        <span class="el-dropdown-link">
                            <div class="usr-name">
                                {{userName}}
                            </div>
                            <i class="h-icon-angle_down_sm el-icon--right el-icon--right--h"></i>
                        </span>
                        <el-dropdown-menu slot="dropdown">
                            <el-dropdown-item @click.native="toUserPage" v-if="isPersonal">个人中心</el-dropdown-item>
                            <el-dropdown-item @click.native="updatePwd" v-if="isPassword">修改密码</el-dropdown-item>
                            <el-dropdown-item @click.native="loginOut" v-if="isExit">退出登录</el-dropdown-item>
                        </el-dropdown-menu>
                    </el-dropdown>
                </div>
            </div>
        </div>
        <t-password-mod :pwdDialogVisible="pwdDialogVisible" :title="title" :userName="userName" :type=0 @closeDialog="closeDialog"></t-password-mod>
    </div>
</template>
<script>
export default {
    name: "tHeader",
    props: {
        isPersonal: {
            type: Boolean,
            default: true
        },
        isPassword: {
            type: Boolean,
            default: true
        },
        isExit: {
            type: Boolean,
            default: true
        },
        menu: Array,
        menuTheme: {
            type: String,
            default: "dark"
        },
        menuShow: {
            type: Boolean,
            default: true
        },
        projectData: {
            type: Object,
            default: () => {
                let obj = {
                    logo: require("../../../assets/logo.png"),
                    title: "海康云曜"
                };
                return obj;
            }
        }
    },
    data () {
        return {
            pwdDialogVisible: false,
            title: "修改密码",
            userName: this.$store.getters.userInfo.userName
        };
    },
    computed: {
    },
    watch: {
    },
    methods: {
        updatePwd () {
            this.pwdDialogVisible = true;
        },
        closeDialog () {
            this.pwdDialogVisible = false;
        },
        // 下载中心
        toDownloadPage () {
            this.$router.push({path: "/download"});
        },
        // 个人中心
        toUserPage (){
            this.$router.push({path: "/personal/info"});
        },
        // 退出登录
        loginOut (){
            this.$store.dispatch("LogOut").then(() => {
                location.reload();// In order to re-instantiate the vue-router object to avoid bugs
            });
        }
    },
    created () {
    },
    mounted () {
    }
};
</script>

<style lang="scss" scoped>
.page-logo {
  position: fixed;
  width: 100%;
  height: 36px;
  line-height: 36px;
  background: #1B1F22;
  z-index: 1000;
  display: flex;
  align-items: center;
  justify-content: space-between;
  .m-left {
    display: flex;
    align-items: center;
    margin-left: 8px;
  }
  .m-right {
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 8px;
  }
  .logo {
      position: relative;
      width: auto;
      display: inline-block;
      vertical-align: middle;
      height: 28px;
      img {
          width: auto;
          height: 28px;
      }
  }
  .title {
      position: relative;
      height: 28px;
      width: auto;
      display: inline-block;
      vertical-align: middle;
      margin-left: 12px;
      line-height: 28px;
      font-size: 16px;
      color: #FFFFFF;
  }
  .sub-title {
      position: relative;
      height: 20px;
      width: auto;
      display: inline-block;
      vertical-align: middle;
      margin-left: 12px;
      line-height: 20px;
      font-size: 12px;
      color: #FFFFFF;
  }
  .info {
      padding: 0 24px;
      color: #FE5332;
      background: rgba(254,83,50,0.2);
      font-family: "PingFangSC-Regular";
      i {
          font-size: 12px;
          margin-right: 8px;
      }
      span {
          font-size: 14px;
      }
  }
  .download, .msg, .opt {
    padding-right: 10px;
    img {
      width: 14px;
      height: 14px;
      display: block;
      cursor: pointer;
    }
  }
  .usr {
      position: relative;
      cursor: pointer;
      .usr-name {
          position: relative;
          max-width: 150px;
          // min-width: 60px;
          height: 22px;
          line-height: 20px;
          font-size: 12px;
          color: #FFFFFF;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
      }
      .usr-down {
          line-height: 20px;
          z-index: 100;
          display: flex;
          .el-dropdown {
              .el-dropdown-link {
                  display: flex;
                  flex-direction: row;
                  justify-content: space-between;
                  align-items: center;
                  .el-icon--right--h {
                      color: #FFFFFF;
                      margin-left: 5px;
                  }
              }
          }
      }
  }
}
</style>

