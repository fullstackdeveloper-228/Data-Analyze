<template>
    <el-dialog title="选择回放时间" :visible="visible" :area="[480,300]" top="middle" no-scrollbar :close-on-click-modal="false" :before-close="cancelFunc">
        <el-form :model="timeForm" ref="timeForm" class="timeForm">
            <el-form-item label="开始时间" prop="startTime" label-width="80px">
                <el-date-picker
                    v-model="timeForm.startTime"
                    type="datetime"
                    :clearable="false"
                    style="width: 100%;"
                >
                </el-date-picker>
            </el-form-item>
            <el-form-item label="结束时间" prop="endTime" label-width="80px">
                <el-date-picker
                    v-model="timeForm.endTime"
                    type="datetime"
                    :clearable="false"
                    style="width: 100%;"
                >
                </el-date-picker>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
            <el-button type="primary" @click="checkFunc">确 定</el-button>
            <el-button @click="cancelFunc">取 消</el-button>
        </div>
    </el-dialog>
</template>
<script>
/*
 * @Author: Sixiang Le 
 * @Date:   2019-04-03 16:09:16 
 * @Last Modified by: Sixiang Le
 * @Last Modified time: 2019-05-16 16:18:04
 */
import { subDays, format } from 'date-fns';
export default {
    name: 'ReplayTimePicker',
    data () {
        return {
            timeForm: {
                startTime: subDays(new Date(), 1),
                endTime: new Date()
            }
        };
    },
    props: {
        visible: {
            type: Boolean,
            default: true
        },
        item: {
            type: Object,
            default: () => {}
        } 
    },
    computed: {
    },
    created () {
    },
    methods: {
        // 获取录像片段
        getRecordList (start, end) {
            let videoInfo = {
                deviceSerial: this.item.monitorSerial,
                channelNo: this.item.channum,
                startTime: start,
                endTime: end,
                recType: 0
            };
            this.$store.dispatch("GetRecordList", videoInfo).then((res) => {
                if (res.data && res.data.length) {
                    this.$emit('check-func', {
                        startTime: start,
                        endTime: end
                    });
                } else {
                    this.$alert('', '该时间段没有录像片段', {
                        confirmButtonText: '确定',
                        callback: () => {}
                    }); 
                }
            }).catch((err) => {
            });
        },
        checkFunc () {
            let start = this.timeForm.startTime.getTime();
            let end = this.timeForm.endTime.getTime();
            if (start > end) {
                this.$alert('', '结束时间不能早于开始时间', {
                    confirmButtonText: '确定',
                    callback: () => {}
                });
            } else if (end - start > 3600 * 1000 * 24 * 7){
                this.$alert('', '回放时间不能大于7天', {
                    confirmButtonText: '确定',
                    callback: () => {}
                });
            } else {
                this.getRecordList(start, end);
            }
        },
        cancelFunc () {
            // 触发:visible.sync语法
            this.$emit('update:visible', false); 
            // this.$emit('cancelFunc');
            this.$refs['timeForm'].resetFields();
        }
    },
    components: {
    },
    watch: {
        // visible (val) {
        //     if (val) {
        //         this.timeForm.startTime = subDays(new Date(), 1);
        //         this.timeForm.endTime = new Date();
        //     }
        // }
    },
    destroyed () {
    }
};
</script>

<style lang="scss" scoped>
.timeForm {
    width: 400px;
    margin: 40px auto;
}
</style>
