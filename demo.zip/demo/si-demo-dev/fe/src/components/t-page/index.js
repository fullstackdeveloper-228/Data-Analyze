import tPage from "./src/t-page.vue";

tPage.install = (Vue) => {
    Vue.component(tPage.name, tPage);
};

export default tPage;
