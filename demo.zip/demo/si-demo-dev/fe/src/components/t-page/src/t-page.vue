<template>
    <div class=""></div>
</template>

<script>

export default {
    name: "test",
    components: {},
    data () {
        return {};
    },
    props: {},
    created () {},
    mounted () {},
    filters: {},
    computed: {},
    methods: {}
};

</script>

<style scoped lang="scss">
</style>

<style>
</style>
