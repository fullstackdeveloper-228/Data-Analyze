import { Loading } from 'hui';
const loadOption = {
    target: '#video_window',
    text: '正在缓冲...',
    spinner: 'el-icon-loading',
    customClass: 'loading-class'
};
let loadingInstance;
export default class loadEvents {
    constructor (vueThis) {
        this.vm = vueThis;
    }
    open () {
        loadingInstance = Loading.service(loadOption);
    }
    close () {
        loadingInstance.close();
    }
};