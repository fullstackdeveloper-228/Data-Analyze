<template>
    <div id="video_window" :style="{width: opts.width +'px',height: opts.height +'px'}" class="video-window-wrapper"></div>
</template>
<script>
/*
 * @Author: Sixiang Le 
 * @Date:   2019-04-03 16:09:16 
 * @Last Modified by: Sixiang Le
 * @Last Modified time: 2019-05-10 14:35:45
 */
import { format } from 'date-fns';
export default {
    name: 'VideoWindow',
    data () {
        return {
            iWind: 0,
            status: null,
            vWindow: null
        };
    },
    props: {
        opts: {
            type: Object,
            default: () => ({
                width: 1142,
                height: 614   
            })
        }
    },
    computed: {
        
    },
    mounted () {
    },
    methods: {
        render () {
            let self = this;
            // console.log(this.opts);
            this.vWindow = new EZUIKit.EZUIPlayer({
                id: 'video_window',
                autoplay: true,
                url: this.opts.url,
                accessToken: this.opts.accessToken,
                decoderPath: __dirname + 'static/ezuikit',
                width: this.opts.width || 1075,
                height: this.opts.height || 400,
                handleError: this.opts.handleError || this.handleError,
                handleSuccess: this.opts.handleSuccess || this.handleSuccess
            });
            
            // window.onresize = function () {
            //     if (self.resizeFun) {
            //         self.resizeFun();
            //     } else {
            //         self.resizeWin(self.opts.width, self.opts.height);
            //     }
            // };
        },
        resizeWin (w, h) {
            this.vWindow.resizeVideo(
                w || this.options.width,
                h || this.options.height
            );
        },
        handleError (e) {
            this.$message.error(e.msg);
            console.log('handleError', e);
        },
        handleSuccess () {
            // this.$message.success('播放成功');
            this.status = 'success';
        },
        // 全屏
        fullScreen () {
            this.vWindow.fullScreen();
        },
        // 获取当前播放时间
        $getOSDTime (wNum, cb1, cb2) {
            this.vWindow.getOSDTime1(wNum, cb1, cb2);
        },
        // 截屏
        $screenShot (wNum) {
            this.vWindow.capturePicture(wNum || 0, 'img_' + format(Date.now(), "YYYY-MM-DD_HH_mm_ss"));
        },
        // 开始录像 
        $startRecord (wNum) {
            return this.vWindow.startSave(wNum || 0, '录像_' + format(Date.now(), "YYYY-MM-DD_HH_mm_ss"));
        },
        // 停止录像
        $stopRecord (wNum) {
            return this.vWindow.stopSave(wNum || 0);
        },
        // 开启电子放大 
        $enableZoom () {
            this.vWindow.enableZoom();
        },
        // 关闭电子放大
        $stopZoom () {
            this.vWindow.closeZoom();
        },
        // todo 暂停
        $pause () {
            this.vWindow.pauseVideo();
        },
        // todo 播放
        $resume () {
            this.vWindow.resumeVideo();
        },
        // todo 播放视频
        $playVideo () {
            // console.log("尝试播放");
            const that = this;
            const playVideo = () => {
                if (that.status === 'playing' || that.status === 'closing') {
                    return;
                }
                that.status = 'playing';
                try {
                    this.vWindow = new EZUIKit.EZUIPlayer({
                        id: 'video_window',
                        autoplay: true,
                        url: this.opts.url,
                        accessToken: this.opts.accessToken,
                        decoderPath: __dirname + 'static/ezuikit',
                        width: this.opts.width || 1075,
                        height: this.opts.height || 400,
                        handleError: this.opts.handleError || this.handleError,
                        handleSuccess: this.opts.handleSuccess || this.handleSuccess
                    });
                    // that.vWindow.play({
                    //     handleError: that.handleError,
                    //     handleSuccess: opts.handleSuccess
                    // });
                } catch (err) {
                    console.log(err);
                }
            };
            if (that.status === 'success' || that.status === 'closing') {
                that.$closeVideo(
                    () => {
                        playVideo();
                    },
                    () => {
                        playVideo();
                    }
                );
            } else {
                playVideo();
            }
        },
        // todo 关闭视频播放
        $closeVideo (success, fail) {
            const that = this;
            if (!that.vWindow) {
                if (success) {
                    success();
                }
                return;
            }
            // console.log("正在关闭中");
            that.status = 'closing';
            that.vWindow.JS_Stop(
                0,
                ()=> {
                    // this.vWindow= null;
                    that.status = 'closed';
                    if (success) {
                        success();
                    }
                },
                () => {
                    that.status = 'closed';
                    if (fail) {
                        fail();
                    }
                }
            );
        },
        $destroyWorker () {
            this.vWindow.JS_DestroyWorker();
        }
    },
    beforeDestroy () {
    }
};
</script>

<style lang="scss" scoped>
/* 播放面板控件样式 */
.video-window-wrapper {
    position: relative;
    .playTool {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        box-sizing: border-box;
        border: 1px solid transparent;
        /* 提示文字 */
        .tipMsg {
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            width: 80%;
            height: 20%;
            margin: auto;
            p {
                color: #FFF;
                font-size: 2rem;
                text-align: center;
            }
        }
    }
    .tag-info {
        position: absolute;
        width: 250px;
        height: 60px;
        left: 10px;
        bottom: 10px;
        color: #FFF;
        font-size: 18px;
        p {
            span {
                display: inline-block;
                width: 80px;
                text-align: right;
            }
        }
    }
}
</style>
