<template>
    <el-dialog
        :title="title"
        :visible.sync="pwdDialogVisible"
        :close-on-click-modal="false"
        :area="480"
        :before-close="closeDialog">
        <div class="dialog_style__one">
            <eits-mod-pwd :isConfirmBtn="false" :token="token" :user="userName" :productCode="productCode" @change-back="changeBack" :changePwdUrl="changePwdUrl" :challengeCodeUrl="challengeCodeUrl" ref="eitsModPwd"></eits-mod-pwd>
        </div>
        <div slot="footer">
            <el-button type="primary" @click="handleSave">确 定</el-button>
            <el-button @click="closeDialog">取 消</el-button>
        </div>
    </el-dialog>
</template>
<script>
// 点击忘记密码验证过手机号之后进入的重置密码页面
import Token from "@/utils/token";
export default {
    name: "tPasswordMod",
    props: {
        title: {
            type: String,
            default: "密码重置"
        },
        userName: {
            type: String,
            default: ""
        },
        userId: {
            type: String,
            default: ""
        },
        pwdDialogVisible: {
            type: Boolean,
            default: false
        },
        type: {
            type: Number,
            default: 1
        }
    },
    data () {
        return {
            token: Token.getToken(),
            productCode: this.$store.getters.userInfo.productCode,
            changePwdUrl: this.$api.UPDATE_PWD_SDK,
            challengeCodeUrl: this.$api.CHALLENGE_CODE_SDK
        };
    },
    created () {
    },
    computed: {
    },
    methods: {
        changeBack (payload) {
            if (payload.type === "success") {
                this.$store.dispatch("FedLogOut").then(() => {
                    this.$router.push("/login");
                    this.$message.success("密码修改成功,请重新登录");
                });
            }
        },
        closeDialog () {
            this.$emit("closeDialog");
        },
        handleSave () {
            this.$refs.eitsModPwd.beforeMod();
        }
    }
};
</script>
<style rel="stylesheet/scss" lang="scss">
    .el-popover.newpwd-tip {
        line-height: 20px;
        background: rgba(85, 85, 85, 0.9);
        color: #FFF;
        padding: 10px 10px 10px 30px;
        border: none;
        border-radius: 2px;
        div {
            margin-bottom: 5px;
            color: #989A9C;
        }
        .dissatisfy {
            color: #FFF;
        }
        i {
            float: left;
            margin-left: -18px;
        }
        &.el-popover[x-placement^=top] .popper__arrow {
            bottom: -11px;
            border-right-color: #666;
            border-bottom-color: #666;
        }
    }
</style>


