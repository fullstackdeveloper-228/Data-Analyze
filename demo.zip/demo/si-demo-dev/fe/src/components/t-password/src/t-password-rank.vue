<template>
    <div class="check-bar">
        <div class="check-tip" :style="{color: tipColor}">{{tipText}}</div>
        <ul class="bar">
            <li :class="{'progresst': true, 'barsuccess': isSuccess, 'barok': isOk, 'barwarning': isWarning, 'bardanger': isDanger}"></li>
            <li :class="{'progresst': true, 'barsuccess': isSuccess, 'barok': isOk, 'barwarning': isWarning }"></li>
            <li :class="{'progresst': true, 'barsuccess': isSuccess, 'barok': isOk  }"></li>
            <li :class="{'progresst': true, 'barsuccess': isSuccess }"></li>
        </ul>
    </div>
</template>
<script>
export default {
    name: "tPasswordRank",
    props: {
        status: {
            type: Number,
            default: 0
        }
    },
    data () {
        return {
        };
    },
    computed: {
        isSuccess () {
            return this.status === 3 ? true : false;
        },
        isOk () {
            return this.status === 2 ? true : false;
        },
        isWarning () {
            return this.status === 1 ? true : false;
        },
        isDanger () {
            return this.status === 0 ? true : false;
        },
        tipText () {
            let text = "";
            switch (this.status) {
                case 0: text = "危险"; break;
                case 1: text = "弱"; break;
                case 2: text = "中"; break;
                case 3: text = "强"; break;
            }
            return text;
        },
        tipColor () {
            let color = "";
            switch (this.status) {
                case 0: color = "#FE5332"; break;
                case 1: color = "#FF952C"; break;
                case 2: color = "#FFCC00"; break;
                case 3: color = "#3BCD8D"; break;
            }
            return color;
        }
    }
};
</script>
<style scope>
    .check-bar {
        width: 100%;
        height: 20px;
        margin: 0 auto;
    }
    .check-tip {
        width: 24px;
        float: right;
        font-size: 12px;
        line-height: 20px;
        text-align: left;
    }
    .bar {
        padding-top: 8px;
        width: 100%;
    }
    .progresst {
        width: 22.5%;
        height: 4px;
        margin-left: 1px;
        background: #EDEFF4;
        float: left;
    }
    .progresst:first-child {
        border-radius: 4px 0 0 4px;
     }
    .progresst:last-child {
        border-radius: 0 4px 4px 0;
    }

    .bardanger {
        background: #FE5332;
    }
    .barwarning {
        background: #FF952C;
    }
    .barok {
        background: #FFCC00;
    }
    .barsuccess {
        background: #3BCD8D;
    }
</style>


