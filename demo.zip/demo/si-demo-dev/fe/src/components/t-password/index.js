import tPasswordMod from "./src/t-password-mod.vue";
import tPasswordRank from "./src/t-password-rank.vue";

tPasswordMod.install = (Vue) => {
    Vue.component(tPasswordMod.name, tPasswordMod);
};

tPasswordRank.install = (Vue) => {
    Vue.component(tPasswordRank.name, tPasswordRank);
};

export default {
    tPasswordMod,
    tPasswordRank
};
