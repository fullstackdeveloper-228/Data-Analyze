// https://eslint.org/docs/user-guide/configuring

module.exports = {
  	root: true,
  	parserOptions: {
    	parser: "babel-eslint"
  	},
  	env: {
    	browser: true,
  	},
  	// https://github.com/vuejs/eslint-plugin-vue#priority-a-essential-error-prevention
  	// consider switching to `plugin:vue/strongly-recommended` or `plugin:vue/recommended` for stricter rules.
  	extends: ["plugin:vue/essential"],
  	// required to lint *.vue files
  	plugins: [
    	"vue"
  	],
  	// add your custom rules here
  	rules: {
    	// allow debugger during development
    	"no-debugger": process.env.NODE_ENV === "production" ? "error" : "off",
        "no-console": process.env.NODE_ENV === "production" ? 0 : 0,
    	// 禁止在条件中使用常量表达式
    	"no-constant-condition": 2,
    	// 对象、数组末尾元素禁止带逗号
    	"comma-dangle": [2, "never"],
    	// 使用 === 替代 == allow-null允许null和undefined==
        "eqeqeq": [2, "allow-null"],
        // 禁止使用多个空格
        "no-multi-spaces": 2,
        // 指定数组的元素之间要以空格隔开(, 后面), [ 之前和 ] 之后不能带空格
        "array-bracket-spacing": [2, "never"],
        //强制使用一致的缩进 第二个参数为 "tab" 时，会使用tab
     // if while function 后面的{必须与if在同一行，java风格。
     "brace-style": [2, "1tbs", { "allowSingleLine": true  }],
     // 双峰驼命名格式
     "camelcase": 0,
     // 控制逗号前后的空格
     "comma-spacing": [2, { "before": false, "after": true }],
        //以方括号取对象属性时，[ 后面和 ] 前面是否需要空格, 可选参数 never, always
        "computed-property-spacing": [2, "never"],
        "indent": [2, 4, { "SwitchCase": 1 }],
     // 强制在对象字面量的属性中键和值之间使用一致的间距
     "key-spacing": [2, {  "beforeColon": false, "afterColon": true }],
		// 要求在注释周围有空行 ( 要求在块级注释之前有一空行)
        "lines-around-comment": [0, { "beforeBlockComment": true }],
        // 不允许多个空行
        "no-multiple-empty-lines": [2, { "max": 2  }],
        // 禁止 function 标识符和括号之间出现空格
        "no-spaced-func": 2,
         // 要求或禁止使用分号而不是 ASI（这个才是控制行尾部分号的，）
        "semi": [2, "always"],
        // 强制在 function的左括号之前使用一致的空格
        "space-before-function-paren": [2, "always"],
        // 强制在圆括号内使用一致的空格
        "space-in-parens": [2, "never"],
        // 要求操作符周围有空格
        "space-infix-ops": 2,
        // 强制在一元操作符前后使用一致的空格
        "space-unary-ops": [2, { "words": true, "nonwords": false }],
        // 强制在注释中 // 或 /* 使用一致的空格
        "spaced-comment": [2, "always", {"markers": ["global", "globals", "eslint", "eslint-disable",   "*package", "!"]}],
		// 要求箭头函数体使用大括号
		"arrow-body-style": 2,
		// 要求箭头函数的参数使用圆括号
		"arrow-parens": 2,
		// 要求使用 let 或 const 而不是 var
		"no-var": 2,
		// 分号前后空格
		"semi-spacing": [2, {"before": false, "after": true}],
		// 引号类型 `` "" ""
		"quotes": [0, "double",{"allowTemplateLiterals": true}],
		// 关键字后面是否要空一格
		"keyword-spacing": [2, {"before": true, "after": true}],
		// 方法名后面是否有空格
		"space-before-function-paren": [2, "always"]
  	}
}
