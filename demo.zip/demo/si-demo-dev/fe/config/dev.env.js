'use strict'

module.exports = {
  NODE_ENV: '"development"',
  SSOURL: '"https://zh-pre.hikyun.com/sso"',
  LOGINURL: '"https://demo-pre.hikyun.com/login"'
  // SSOURL: '"https://10.17.82.14:2019/sso"',
  // LOGINURL: '"https://10.17.82.14:2019/login"'
}
