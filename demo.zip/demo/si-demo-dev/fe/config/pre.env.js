// 开发环境配置
module.exports = {
    NODE_ENV: '"production"',
    HOST: '"https://demo-dev.hikyun.com"',
    SSOURL: '"https://zh-dev.hikyun.com/sso"',
    LOGINURL: '"https://demo-dev.hikyun.com/login"'
}
