'use strict'
// 正式线上环境配置
module.exports = {
  NODE_ENV: '"production"',
  HOST: '"https://demo.hikyun.com"',
  SSOURL: '"https://zh.hikyun.com/sso"',
  LOGINURL: '"https://demo.hikyun.com/login"'
}
