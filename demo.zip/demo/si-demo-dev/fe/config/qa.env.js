// 预发布环境配置
module.exports = {
    NODE_ENV: '"production"',
    HOST: '"https://demo-pre.hikyun.com"',
    SSOURL: '"https://zh-pre.hikyun.com/sso"',
    LOGINURL: '"https://demo-pre.hikyun.com/login"',
}
