package com.hikvision.etis.demo.sdk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SdkDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SdkDemoApplication.class, args);
    }

}
