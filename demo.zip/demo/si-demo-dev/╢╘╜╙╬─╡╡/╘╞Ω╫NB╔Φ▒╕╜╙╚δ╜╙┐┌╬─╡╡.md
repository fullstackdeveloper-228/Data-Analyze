

## 一、概述
第三方接入云曜云开发平台，需要首先申请开放平台appkey和secret，然后通过appkey和secret获取接入云曜云权限。


## 二、接口

    说明：
    1. 请求参数凡是必填项以“*”进行了标识。

    2. 新建接口需要使用特殊权限appkey和secret获取的token才能调用，成功新建产品后，接口会返回产品级别appkey和secret，后续提供接口无说明情况下默认使用该产品级别账号生成的token。


### 1. 获取全局token
- 请求路径：/api/eits/v1/global/jwt

- 请求参数

  productCode: 产品code

  apiKey*：开放平台key

  apiSecret: 开放平台secret

- 请求Json

```
{
    "productCode": "LAKERS",
    "apiKey": "23889821"
}
```


### 2. 新建产品接口

- 说明：该接口需要通过云曜云特殊权限appkey和secret生成的token才能调用

- 请求路径： ybase/global/v1/productService/products

- 请求参数：

    Authorization*: 通过云曜云特殊权限appkey和secret调用接口获取的token

    name*: 产品名称，产品名称不能重复

    type*：产品类型，云曜云申请


- 返回参数：

  code: 错误码 成功200 失败400 

  msg: 描述信息
  
  data: 数据结构体

        productCode： 产品编码
        name: 产品名称
        type：产品类型
        productKey：开放平台appkey
        productSecret：开放平台appsecret


- 请求Json格式
```
{
  "name": "string",
  "type": "string"
}
```



### 3 新建/编辑项目
- 请求路径： ybase/global/v1/projectService/projects

- 说明：

- 请求参数：

    Authorization: 通过开放平台产品级别appkey和secret获取token

    id: 项目id，传入该参数表示编辑项目，不传入表示新建项目

    name: 项目名称

    productCode*: 产品code

    ysKey: 萤石key，允许为空, 后续修改

    ysSecret：萤石秘钥，允许为空, 后续修改


- 返回参数：

  code:错误码 成功200 失败400 

  msg: 描述信息
  
  data: 数据结构体

        id: 项目标识
        name: 项目名称
        productCode: 产品code
        productType： 产品类型


- 请求Json格式
```
{
  "id": 0,
  "name": "string",
  "productCode": "string",
  "ysKey": "string",
  "ysSecret": "string"
}
```

### 4 添加订阅消息

- 请求路径：/ymsg/global/v1/sub/add

- 请求参数：

    name*：消息订阅名称

    productType*：产品类型

    productCode*：产品编码

    type*：消息订阅类型
    
        common.subtype.nbiot：NB事件报警 
        common.subtype.alarm：报警
        common.subtype.permissionchange：权限变更
        common.subtype.onoffline: 设备上下线
    
    subUrl*：订阅地址，必填，必须是可用的地址

    pushType*：推送类型 1加密/0不加密

    password：加密秘钥（16位字母数字组成的字符串）
    
    remark：备注

- 返回参数：

  code:错误码 成功200 失败400 

  msg: 描述信息
  
  data: 数据结构体

        id：返回订阅消息标识



- 请求Json格式

    ```
    {
    "name": "string",
    "password": "string",
    "productCode": "string",
    "productType": "string",
    "pushType": 0,
    "remark": "string",
    "subUrl": "string",
    "type": "string"
    }
    ```


### 5.删除订阅消息

- 请求路径：/ymsg/global/v1/sub/deletion

- 请求参数：

    productCode*：产品编码

    id*：订阅消息id

- 请求Json格式
    ```
    {
    "id": "string"
    }
    ```
    
### 6.添加NB设备

- 请求路径：/yres/global/v1/device/nb/save

- 请求参数：

    projectId*: 项目id

    deviceSerial*：设备序列号

    deviceName*：设备名称
    
    modelType*：设备类型，参数如何获取：调用 9.分页获取数据字典信息 接口，id值为common.nbModelType，获取返回值中的key或value值作为设备类型

    manufacturer: 厂商类型，参数获取同上，id值为：common.manufacturer
    
    operatorType*：运营商类型，参数类型：CMCC 中国移动, 中国电信 CTCC, CUCC中国联通（目前尚不支持）

- 请求Json格式
    ```
    {
    "projectId":0,
    "deviceSerial": "string",
    "deviceName": "string",
    "modelType": "string",
    "manufacturer": "string",
    "operatorType": "string"
    }
    ```
    
### 7.注册NB设备
- 注：添加完成后，可通过注册接口，对项目下所有添加失败的设备尝试重新添加
- 请求路径：/yres/global/v1/device/nb/batch/registe

- 请求参数：

    projectId*: 项目id

- 请求Json格式
    ```
    {
    "projectId":0
    }
    ```
    
### 8.删除NB设备
- 请求路径：/yres/global/v1/device/nb/delete

- 请求参数：

    ids*: 设备id数组
    
    projectId*: 项目id

- 请求Json格式
    ```
    {
      "projectId":0,
      "ids": [
        0
      ]
    }
    ```
    
### 9.分页获取数据字典信息
- 请求路径：/ydic/global/v1/dict/list

- 请求参数：

    id*: 字典类型
    
    pageNo*: 页码
    
    pageSize*: 每页记录数

- 请求Json格式
    ```
    {
      "id": "string",
      "pageNo": 0,
      "pageSize": 0
    }
    ```