package com.hikvision.hikkan.ymsg.encrypt.web;

import com.hikvision.hikkan.ymsg.encrypt.bean.ObjectResult;
import com.hikvision.hikkan.ymsg.encrypt.util.AesUtil;
import com.hikvision.hikkan.ymsg.encrypt.util.Sha256Utils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

/**
 * 加密控制层 提供接口
 * <p>
 * 方便测试人员加密测试
 *
 * @author heqian7
 */
@Slf4j
@RestController
@RequestMapping("/encrypt")
public class EncryptController {

    @GetMapping(value = "/sha256", produces = "application/json; charset=utf-8")
    public Mono<Object> sha256(@RequestParam String pwd, @RequestParam String salt, @RequestParam String vCode) {
        return Mono.create(s -> {
            String result = Sha256Utils.getSHA256StrJava(Sha256Utils.getSHA256StrJava(pwd + salt) + vCode);
            s.success(new ObjectResult("200", null, result));
        }).subscribeOn(Schedulers.elastic());
    }

    @GetMapping(value = "/aes", produces = "application/json; charset=utf-8")
    public Mono<Object> aes(@RequestParam String pwd, @RequestParam String salt, @RequestParam String vCode) {
        return Mono.create(s -> {
            String result = null;
            try {
                result = AesUtil.aesEncrypt(Sha256Utils.getSHA256StrJava(pwd + salt) ,vCode);
            } catch (Exception e) {
                e.printStackTrace();
            }
            s.success(new ObjectResult("200", null, result));
        }).subscribeOn(Schedulers.elastic());
    }
}
